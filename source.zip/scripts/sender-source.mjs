import { readFile } from 'node:fs/promises';

export const SENDER_CLUBS = [
  { id: 'swl', prefix: 'Swl', menu: 'SWL', name: 'SWL Gymnastics' },
  { id: 'fulham', prefix: 'Fulham', menu: 'Fulham', name: 'Fulham Gymnastics' },
  { id: 'apex', prefix: 'Apex', menu: 'Apex', name: 'Apex Gymnastics' },
  { id: 'apexdance', prefix: 'ApexDance', menu: 'Apex Dance', name: 'Apex Dance Club' }
];

export async function applyEmailSender(source, id) {
  const club = SENDER_CLUBS.find(club => club.id === id);
  if (!club) throw new Error('Unknown sender club: ' + id);
  let sender = await readFile(new URL('./selected-row-sender.gs', import.meta.url), 'utf8');
  for (const [key, value] of Object.entries({ ID: club.id, PREFIX: club.prefix, MENU: club.menu, NAME: club.name })) sender = sender.replaceAll(`__${key}__`, value);
  const start = source.indexOf('function onOpen()');
  const end = source.indexOf('// ==========================================\n// EMAIL DESIGN — LEAVE IN PLACE', start);
  if (start < 0 || end < 0) throw new Error('Could not locate the sender section for ' + id);
  return (source.slice(0, start) + sender + '\n\n' + source.slice(end))
    .replace('Row 1 headings (any column order):', 'Headings in the first 20 rows (any column order):')
    .replace('Childs Name | Parents Name | Email | Email Status | Review', 'Childs Name | Parents Name | Email. Common heading variations are accepted.\n * Email Status is added when sending if absent; Review is optional.')
    .replace('Nonblank Email Status or Review rows are skipped.', 'Nonblank Review rows are skipped; Email Status never blocks sending.')
    .replace('Nonblank Email Status or existing Review rows are skipped.', 'Nonblank Review rows are skipped; Email Status never blocks sending.')
    .replace('Use a fresh sheet/copy with blank statuses for each new message.', 'Each manual send emails the selected eligible rows again, regardless of Email Status.');
}
