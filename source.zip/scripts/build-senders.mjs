// Refresh the shared selected-row sender without changing any email design.
import { readFile, writeFile } from 'node:fs/promises';
import { applyEmailSender, SENDER_CLUBS } from './sender-source.mjs';
for (const club of SENDER_CLUBS) {
  const destination = new URL(`../dist/templates/${club.id}.gs`, import.meta.url);
  await writeFile(destination, await applyEmailSender(await readFile(destination, 'utf8'), club.id));
}
console.log('Updated all four template senders.');
