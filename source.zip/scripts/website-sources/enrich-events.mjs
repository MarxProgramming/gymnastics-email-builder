export function enrichEvents(t){
 if(t.id!=='swl-in-club-competition-1')return;
 const s=t.originalCode;
 const field=(id,label,type,value,extra={})=>{t.fields.push({id,label,type,defaultValue:value,group:'Dates & deadlines',...extra});return id;};
 const bind=(fieldId,start,end,encoding='html-text',extra={})=>{t.bindings=t.bindings.filter(b=>!(start<b.end&&end>b.start));t.bindings.push({fieldId,start,end,original:s.slice(start,end),encoding,...extra});};
 const date=field('entryDeadline','Entry deadline (11:59pm UK time)','date','2026-11-15',{required:true,help:'Updates visible deadlines and the live booking cutoff, including UK daylight saving time. Separate from renewal dates.'});
 for(const m of s.matchAll(/15 November 2026/g))bind(date,m.index,m.index+m[0].length,'html-text',{format:'date-long'});
 for(const m of s.matchAll(/datetime="(2026-11-15)"/g)){const at=m.index+m[0].indexOf(m[1]);bind(date,at,at+m[1].length,'html-attribute');}
 const cutoff=/Date\.parse\("2026-11-16T00:00:00Z"\)/.exec(s);if(!cutoff)throw Error('Competition cutoff not found');bind(date,cutoff.index,cutoff.index+cutoff[0].length,'js-date',{dateConstructor:'uk-end-day'});
 for(const [key,label,iso]of [['intermediate','Intermediate competition date','2026-11-29'],['beginner-advanced','Beginners / Advanced competition date','2026-12-06']]){
  const id=field('competition_'+key,label,'date',iso,{required:true});const card=new RegExp('<article class="sc-date" aria-labelledby="sc26-'+key+'-title">[\\s\\S]*?<\\/article>').exec(s);if(!card)throw Error('Competition date card missing');
  const datetime=/datetime="([^"]+)"/.exec(card[0]),at=card.index+datetime.index+datetime[0].indexOf(datetime[1]);bind(id,at,at+datetime[1].length,'html-attribute');
  const patterns=[[/<span>(2026)<\/span>/,'YYYY'],[/<span class="sc-day">(\d+)<\/span>/,'D'],[/<span class="sc-month">([^<]+)<\/span>/,'MMMM'],[/<span>(Sunday)<\/span>/,'dddd']];
  for(const [pattern,datePattern]of patterns){const m=pattern.exec(card[0]);if(m){const at=card.index+m.index+m[0].indexOf(m[1]);bind(id,at,at+m[1].length,'html-text',{format:'date-custom',datePattern});}}
 }
 const booking=field('competitionBooking','Competition booking link','url','https://square.link/u/Li9VJeOv',{required:true,help:'Updates both booking buttons and their live JavaScript destination.'});
 for(const m of s.matchAll(/https:\/\/square\.link\/u\/Li9VJeOv/g)){const inScript=m.index>s.indexOf('<script');if(inScript)bind(booking,m.index-1,m.index+m[0].length+1,'js-string');else bind(booking,m.index,m.index+m[0].length,'html-attribute');}
 const ticket=field('spectatorTicket','Spectator ticket price (£)','number',5,{min:0,max:1000});for(const m of s.matchAll(/£5\b/g))bind(ticket,m.index+1,m.index+2,'number');
 t.fields=t.fields.filter(f=>t.bindings.some(b=>b.fieldId===f.id));
}
