// Explicit reviewed calendar and class-time ranges; never modifies an original.
export function enrichTerms(t){
 if(!t.fields.some(f=>f.id==='termStart'))return;
 const source=t.originalCode;
 const replace=(fieldId,start,end,encoding,extra={})=>{t.bindings=t.bindings.filter(b=>!(start<b.end&&end>b.start));t.bindings.push({fieldId,start,end,original:source.slice(start,end),encoding,...extra});};
 const excluded={id:'excludedDates',label:'Cancelled class dates',type:'list',group:'Term',defaultValue:t.clubId==='fulham'?[{date:'2026-10-26'}]:[],settingsPath:'term.excludedDates',settingsTransform:'date-records',itemLabel:'cancelled date',maxItems:100,itemFields:[{id:'date',label:'Date',type:'date',defaultValue:'',required:true}],help:'List each cancelled class date. Teaching-week trackers skip weeks with no remaining classes.'};t.fields.push(excluded);
 if(t.clubId==='fulham'){
   const m=/<p(?:\s+class="fh-half-term")?>\s*<strong>Half-term break<\/strong>[\s\S]*?<\/p>/.exec(source);
   if(!m)throw Error('Fulham break paragraph missing: '+t.id);
   const start=m.index+m[0].indexOf('>')+1,end=m.index+m[0].lastIndexOf('</p>');replace(excluded.id,start,end,'break-summary');
 }else if(t.clubId==='apex'){
   const phrase='Classes continue through half term',start=source.indexOf(phrase);if(start<0)throw Error('Apex break message missing');replace(excluded.id,start,start+phrase.length,'break-summary');
 }else{
   const phrase=t.id==='apex-dance-home-2'?'programme':(source.includes('15 Weeks')?'Weeks':'weeks.');
   const anchor=t.id==='apex-dance-home-2'?'15-week autumn programme':(source.includes('15 Weeks')?'15 Weeks':'15 weeks.');
   const pos=source.indexOf(anchor);if(pos>=0){const start=pos+anchor.lastIndexOf(phrase);replace(excluded.id,start,start+phrase.length,'break-summary',{prefix:phrase+' · '});}
 }
 const trackers={
   'swl-home-1':{pattern:/Math\.floor\(elapsed \/ millisecondsPerWeek\) \+ 1/,days:[0,1,2,3,4,5,6]},
   'apex-home-1':{pattern:/Math\.floor\(\(now - termStart\) \/ \(7 \* DAY\)\) \+ 1/,days:[4]},
   'apex-timetable1-1':{pattern:/Math\.floor\(\s*\(now - start\) \/ \(7 \* 24 \* 60 \* 60 \* 1000\)\s*\) \+ 1/,days:[4]},
   'swl-classes-1':{pattern:/Math\.floor\(days \/ 7\) \+ 1/,days:[0,1,2,3,4,5,6],nowVariable:'date',nowTimestamp:true}
 };
 const tracker=trackers[t.id];if(tracker){const m=tracker.pattern.exec(source);if(!m)throw Error('Tracker expression missing: '+t.id);replace(excluded.id,m.index,m.index+m[0].length,'teaching-week',{dependsOn:['termStart','termEnd'],weekdays:tracker.days,...(tracker.nowVariable?{nowVariable:tracker.nowVariable,nowTimestamp:tracker.nowTimestamp}:{})});}
 if(t.id==='swl-classes-1')for(const m of source.matchAll(/TERM_WEEKS \* 7/g))replace('termEnd',m.index,m.index+m[0].length,'calendar-days',{dependsOn:['termStart']});
 if(t.id==='fulham-classes-1'){
   for(const m of source.matchAll(/<article class="fc-level fc-(beginners|intermediate|advanced)"[\s\S]*?<\/article>/g)){
     const key=m[1],card=m[0],name=key[0].toUpperCase()+key.slice(1);let n=0;
     for(const time of card.matchAll(/<time datetime="(\d{2}:\d{2})">([^<]+)<\/time>/g)){
       const id='class_'+key+'_'+(n++?'end':'start');t.fields.push({id,label:name+' · '+(n===1?'start':'end')+' time',type:'time',defaultValue:time[1],group:'Classes & fees',required:true});
       const at=m.index+time.index+time[0].indexOf(time[1]);replace(id,at,at+time[1].length,'html-attribute');const display=m.index+time.index+time[0].indexOf('>')+1;replace(id,display,display+time[2].length,'html-text',{format:'time-12'});
     }
   }
 }
 t.fields=t.fields.filter(f=>t.bindings.some(b=>b.fieldId===f.id));
}
