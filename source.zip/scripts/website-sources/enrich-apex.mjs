// Semantic bindings for duplicated values in the captured Apex components.
// The original bytes remain authoritative; this only replaces generic bindings.
export function enrichTemplate(template) {
  if (!['apex-uniform-1', 'apex-private-lessons-1'].includes(template.id)) return template;
  const source = template.originalCode;
  const semanticRanges = [];
  const field = (id, label, defaultValue, extra = {}) => {
    if (template.fields.some(item => item.id === id)) throw new Error('Duplicate Apex semantic field: ' + id);
    const result = { id, label, type: 'text', defaultValue, group: template.id === 'apex-uniform-1' ? 'Club shop' : 'Private lesson', required: true, ...extra };
    template.fields.push(result);
    return result;
  };
  function bindRange(item, start, end, encoding = 'html-text', extra = {}) {
    if (start < 0 || end <= start || end > source.length) throw new Error('Missing Apex source target for ' + item.id);
    if (semanticRanges.some(range => start < range.end && end > range.start)) throw new Error('Overlapping Apex semantic targets.');
    template.bindings = template.bindings.filter(binding => !(start < binding.end && end > binding.start));
    semanticRanges.push({ start, end });
    template.bindings.push({ fieldId: item.id, start, end, original: source.slice(start, end), encoding, ...extra });
  }
  function unique(item, original, encoding = 'html-text', extra = {}) {
    const start = source.indexOf(original);
    if (start < 0 || source.indexOf(original, start + 1) >= 0) throw new Error('Expected one Apex source target: ' + original);
    bindRange(item, start, start + original.length, encoding, extra);
  }
  function occurrences(value) {
    const result = [];
    for (let start = source.indexOf(value); start >= 0; start = source.indexOf(value, start + value.length)) result.push({ start, end: start + value.length });
    return result;
  }

  if (template.id === 'apex-uniform-1') {
    const code = field('shopAccessCode', 'Public club shop access code', 'AGC147', { maxLength: 100, help: 'Updates the displayed code, copy button and copy-status messages together.' });
    const visible = '<code class="access-code">AGC147</code>';
    const visibleAt = source.indexOf(visible);
    if (visibleAt < 0) throw new Error('Apex shop code element changed.');
    const codeAt = visibleAt + visible.indexOf('AGC147');
    bindRange(code, codeAt, codeAt + 6);
    const accessible = 'aria-label="Copy club code AGC147"';
    const accessibleAt = source.indexOf(accessible);
    if (accessibleAt < 0) throw new Error('Apex shop copy label changed.');
    const labelAt = accessibleAt + accessible.indexOf('AGC147');
    bindRange(code, labelAt, labelAt + 6, 'html-attribute');
    unique(code, '"AGC147 copied. Paste it into the club shop."', 'js-string', { format: 'text-affix', suffix: ' copied. Paste it into the club shop.' });
    unique(code, '"Copy AGC147 manually — use capital letters."', 'js-string', { format: 'text-affix', prefix: 'Copy ', suffix: ' manually — use capital letters.' });
  }

  if (template.id === 'apex-private-lessons-1') {
    const day = field('privateDay', 'Weekly lesson day', 'Thursday', { type: 'select', options: ['Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday'], help: 'Updates the slot labels, explanatory copy and email enquiry.' });
    const time = field('privateTime', 'Lesson time', '4:15–5:15pm', { maxLength: 80, help: 'Enter the complete range, such as 4:15–5:15pm. Also update the lesson duration below if it changes. This updates the enquiry email too.' });
    const duration = field('privateDuration', 'Lesson duration (minutes)', 60, { type: 'number', min: 1, max: 300, step: 1 });
    const price = field('privatePrice', 'Price of this lesson (£)', 90, { type: 'number', min: 0, max: 10000, step: 0.01, help: 'The advertised 30-minute and 60-minute rate table stays separately editable.' });
    const coach = field('privateCoach', 'Coach', 'Marx', { maxLength: 120 });
    const email = field('privateEmail', 'Enquiry email address', 'Management@apex-gymnastics.co.uk', { maxLength: 254, help: 'Address only. Updates both email links and the copy-email button.' });
    const enquiryStart = source.indexOf('href="mailto:Management@apex-gymnastics.co.uk?');
    const enquiryEnd = source.indexOf('"', enquiryStart + 6);
    if (enquiryStart < 0 || enquiryEnd < 0) throw new Error('Apex private enquiry link changed.');
    const isEnquiry = range => range.start > enquiryStart && range.end <= enquiryEnd;

    const dayRanges = occurrences('Thursday');
    if (dayRanges.length !== 4) throw new Error('Apex private day references changed.');
    for (const range of dayRanges) bindRange(day, range.start, range.end, isEnquiry(range) ? 'html-attribute' : 'html-text');
    const shortDay = source.indexOf('Thu%20', enquiryStart);
    if (shortDay < 0 || shortDay > enquiryEnd) throw new Error('Apex private enquiry subject changed.');
    bindRange(day, shortDay, shortDay + 3, 'html-attribute', { format: 'weekday-short' });

    unique(time, '4:15–5:15pm');
    const encodedTime = '4%3A15%E2%80%935%3A15';
    const timeRanges = occurrences(encodedTime);
    if (timeRanges.length !== 2 || timeRanges.some(range => !isEnquiry(range))) throw new Error('Apex private enquiry times changed.');
    for (const range of timeRanges) {
      const end = source.slice(range.end, range.end + 2) === 'pm' ? range.end + 2 : range.end;
      bindRange(time, range.start, end, 'html-attribute', { format: 'uri-component' });
    }
    for (const target of ['<span>60 minutes</span>', '<span>60-minute private lesson</span>', 'The current Thursday slot is 60 minutes.']) {
      const start = source.indexOf(target);
      if (start < 0 || source.indexOf(target, start + 1) >= 0) throw new Error('Apex private duration reference changed.');
      const at = start + target.indexOf('60');
      bindRange(duration, at, at + 2, 'number');
    }
    const priceTarget = '<strong>£90 <small>/ session</small></strong>';
    const priceStart = source.indexOf(priceTarget);
    if (priceStart < 0) throw new Error('Apex private slot price changed.');
    const priceAt = priceStart + priceTarget.indexOf('90');
    bindRange(price, priceAt, priceAt + 2, 'number');

    const coachRanges = occurrences('Marx');
    if (coachRanges.length !== 4) throw new Error('Apex private coach references changed.');
    for (const range of coachRanges) bindRange(coach, range.start, range.end, isEnquiry(range) ? 'html-attribute' : 'html-text', isEnquiry(range) ? { format: 'uri-component' } : {});

    const emailValue = 'Management@apex-gymnastics.co.uk';
    const emailRanges = occurrences(emailValue);
    if (emailRanges.length !== 4) throw new Error('Apex private email references changed.');
    for (const range of emailRanges) {
      if (source.slice(Math.max(0, range.start - 15), range.start).endsWith('const email = "')) bindRange(email, range.start - 1, range.end + 1, 'js-string');
      else bindRange(email, range.start, range.end, source.slice(range.start - 7, range.start) === 'mailto:' ? 'html-attribute' : 'html-text');
    }
  }
  template.fields = template.fields.filter(item => template.bindings.some(binding => binding.fieldId === item.id));
  return template;
}
