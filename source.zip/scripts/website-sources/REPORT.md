# Website code inventory

Captured 7 November 2026. All four Squarespace editors were accessed read-only. No page was saved or published.

Scope: 24 published main-navigation pages; 28 custom code blocks. The published component source was archived and its extraction verified against a complete editor copy from each club. The only detected Squarespace transformation was added attributes on full-document HTML tags; these are removed in the originals.

| Club | Page | Code blocks |
|---|---|---|
| swl | [HOME](https://www.swlgymnastics.co.uk/) | 2 |
| swl | [JOINING](https://www.swlgymnastics.co.uk/joining) | 0 |
| swl | [CLASSES](https://www.swlgymnastics.co.uk/classes) | 1 |
| swl | [PRIVATE LESSONS](https://www.swlgymnastics.co.uk/private-lessons) | 1 |
| swl | [PARTIES](https://www.swlgymnastics.co.uk/parties) | 1 |
| swl | [UNIFORM](https://www.swlgymnastics.co.uk/uniform) | 1 |
| swl | [CLUB RULES](https://www.swlgymnastics.co.uk/club-rules) | 1 |
| swl | [PATHWAYS](https://www.swlgymnastics.co.uk/pathways) | 1 |
| swl | [PROGRAMMES](https://www.swlgymnastics.co.uk/programmes) | 1 |
| swl | [IN-CLUB COMPETITION](https://www.swlgymnastics.co.uk/in-club-competition) | 1 |
| swl | [IN-CLUB ROUTINES](https://www.swlgymnastics.co.uk/in-club-competition-routines) | 1 |
| fulham | [Home](https://www.fulhamgymnastics.co.uk/) | 2 |
| fulham | [CLASSES](https://www.fulhamgymnastics.co.uk/classes) | 1 |
| fulham | [PROGRAMME](https://www.fulhamgymnastics.co.uk/levels-target-skills) | 1 |
| fulham | [FAQ](https://www.fulhamgymnastics.co.uk/faq) | 1 |
| apex | [HOME](https://www.apex-gymnastics.co.uk/) | 2 |
| apex | [TIMETABLE](https://www.apex-gymnastics.co.uk/timetable1) | 1 |
| apex | [UNIFORM](https://www.apex-gymnastics.co.uk/uniform) | 1 |
| apex | [PRIVATE LESSONS](https://www.apex-gymnastics.co.uk/private-lessons) | 1 |
| apex | [CLUB RULES](https://www.apex-gymnastics.co.uk/club-rules) | 1 |
| apex-dance | [HOME](https://www.apexdanceclub.co.uk/) | 3 |
| apex-dance | [TIMETABLE](https://www.apexdanceclub.co.uk/timetable1) | 1 |
| apex-dance | [TEAM](https://www.apexdanceclub.co.uk/team-1) | 1 |
| apex-dance | [CLUB RULES](https://www.apexdanceclub.co.uk/club-rules) | 1 |

SWL Joining uses native Squarespace content rather than a custom code block. It therefore has no replacement-code template.

Disabled/unpublished and Not Linked pages are outside the published catalog. The editor contains older renewal and sign-up pages; their content has not been added to the public app.

Originals remain separate from generated edits. Previewing or copying a replacement never changes Squarespace.
