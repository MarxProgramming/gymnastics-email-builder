import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {fileURLToPath} from 'node:url';
import {validateTemplate, generateWebsiteCode} from '../../dist/website-generator.js';
import {enrichTemplate as enrichSwlDance} from './enrich-swl-dance.mjs';
import {enrichTemplate as enrichApex} from './enrich-apex.mjs';
import {enrichEvents} from './enrich-events.mjs';
import {enrichTerms} from './enrich-terms.mjs';
const dir=path.dirname(fileURLToPath(import.meta.url));
const inventory=JSON.parse(fs.readFileSync(path.join(dir,'inventory.json'),'utf8'));
const MONTHS=['January','February','March','April','May','June','July','August','September','October','November','December'];
const DAYS=['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];
const entities={amp:'&',lt:'<',gt:'>',quot:'"',apos:"'",nbsp:'\u00a0',pound:'£',ndash:'–',mdash:'—',hellip:'…',rsquo:'’',lsquo:'‘',rdquo:'”',ldquo:'“',middot:'·',bull:'•',times:'×',copy:'©',reg:'®',trade:'™',rarr:'→',larr:'←',check:'✓',eacute:'é'};
const decode=s=>s.replace(/&(#x[\da-f]+|#\d+|[a-z]+);/gi,(m,k)=>k[0]==='#'?String.fromCodePoint(parseInt(k.slice(k[1]?.toLowerCase()==='x'?2:1),k[1]?.toLowerCase()==='x'?16:10)):entities[k]??m);
const clean=s=>decode(s).replace(/\s+/g,' ').trim();
const nice=s=>s.replace(/[-_]/g,' ').replace(/\b\w/g,c=>c.toUpperCase());
const esc=s=>s.replace(/[.*+?^${}()|[\]\\]/g,'\\$&');
function literal(source,at){
 let i=at; const skip=()=>{while(true){while(/\s/.test(source[i]||'')&&i<source.length)i++;if(source.startsWith('//',i)){i=source.indexOf('\n',i);if(i<0)throw Error('Unclosed comment');}else if(source.startsWith('/*',i)){i=source.indexOf('*/',i+2)+2;if(i<2)throw Error('Unclosed comment');}else break;}};
 function read(){skip();const start=i,c=source[i];if(c==='"'||c==="'"){i++;let value='';while(i<source.length){const ch=source[i++];if(ch===c)return{start,end:i,value};if(ch==='\\'){const e=source[i++];if(e==='u'){const h=source.slice(i,i+4);if(!/^[\da-f]{4}$/i.test(h))throw Error('Bad unicode');value+=String.fromCharCode(parseInt(h,16));i+=4;}else if(e==='x'){const h=source.slice(i,i+2);if(!/^[\da-f]{2}$/i.test(h))throw Error('Bad hex');value+=String.fromCharCode(parseInt(h,16));i+=2;}else value+=({n:'\n',r:'\r',t:'\t',b:'\b',f:'\f',v:'\v','\n':''}[e]??e);}else value+=ch;}throw Error('Unclosed string');}
 if(c==='['){i++;const children=[];skip();while(source[i]!==']'){children.push(read());skip();if(source[i]===','){i++;skip();}else if(source[i]!==']')throw Error('Array separator');}i++;return{start,end:i,value:children.map(n=>n.value),children};}
 if(c==='{'){i++;const properties=[];skip();while(source[i]!=='}'){let key;if(source[i]==='"'||source[i]==="'")key=read().value;else{const m=/^[A-Za-z_$][\w$]*/.exec(source.slice(i));if(!m)throw Error('Object key');key=m[0];i+=key.length;}if(['constructor','__proto__','prototype'].includes(key))throw Error('Unsafe key');skip();if(source[i++]!==':')throw Error('Object colon');const child=read();properties.push({key,...child});skip();if(source[i]===','){i++;skip();}else if(source[i]!=='}')throw Error('Object separator');}i++;return{start,end:i,value:Object.fromEntries(properties.map(n=>[n.key,n.value])),properties};}
 const m=/^(?:-?\d+(?:\.\d+)?(?:[eE][+-]?\d+)?|true|false|null)\b/.exec(source.slice(i));if(!m)throw Error('Unsupported nonliteral source at '+i);i+=m[0].length;return{start,end:i,value:JSON.parse(m[0])};}
 return read();
}
function config(source,name){const m=new RegExp('\\b(?:const|let|var)\\s+'+esc(name)+'\\s*=\\s*').exec(source);return m?literal(source,m.index+m[0].length):null;}
const TERMS={
 'swl-home-1':['2026-09-07','2026-12-20',15], 'swl-classes-1':['2026-09-07','2026-12-20',15],
 'fulham-home-1':['2026-09-07','2026-12-14',14], 'fulham-classes-1':['2026-09-07','2026-12-14',14],
 'apex-home-1':['2026-09-10','2026-12-17',15], 'apex-timetable1-1':['2026-09-10','2026-12-17',15],
 'apex-dance-home-2':['2026-09-11','2026-12-19',15], 'apex-dance-timetable1-1':['2026-09-11','2026-12-19',15]
};
const TITLES={'swl-home-1':'Home · term dates & navigation','swl-home-2':'Home · location & reviews','fulham-home-1':'Home · welcome & term dates','fulham-home-2':'Home · location & arrival','apex-home-1':'Home · term dates & navigation','apex-home-2':'Home · registration & location','apex-dance-home-1':'Home · welcome','apex-dance-home-2':'Home · term dates','apex-dance-home-3':'Home · programmes & registration'};
const results=[];
for(const page of inventory.pages)for(const block of page.blocks){
 const originalCode=fs.readFileSync(path.join(dir,block.file),'utf8');
 const id=path.basename(block.file,'.html'),clubId=page.clubId==='apex-dance'?'apexdance':page.clubId;
 const t={id,clubId,title:TITLES[id]||nice(page.title.toLowerCase())+(page.blocks.length>1?' · component '+(page.blocks.indexOf(block)+1):''),pageUrl:page.url,blockId:block.blockId,capturedAt:inventory.capturedAt,originalSha256:crypto.createHash('sha256').update(originalCode).digest('hex'),sourceKind:'captured-squarespace-code',description:'Original '+nice(page.title.toLowerCase())+' code block. The captured design and behaviour are preserved; edits replace only linked content.',reusability:'Shared editing controls; club-specific original design and behaviour.',originalCode,fields:[],bindings:[]};
 const occupied=[]; let seq=0;
 const available=(start,end)=>!occupied.some(r=>start<r.end&&end>r.start);
 function field(id,label,type,defaultValue,group='Page text',extra={}){let f=t.fields.find(f=>f.id===id);if(!f){f={id,label,type,defaultValue,group,...extra};t.fields.push(f);}return f;}
 function bind(f,start,end,encoding='html-text',extra={}){if(!available(start,end))return false;occupied.push({start,end});t.bindings.push({fieldId:f.id,start,end,original:originalCode.slice(start,end),encoding,...extra});return true;}
 const pieces=[],attrs=[],scripts=[];let cursor=0,heading='Page text',skipDepth=0;
 const tokens=/<script\b[^>]*>[\s\S]*?<\/script\s*>|<style\b[^>]*>[\s\S]*?<\/style\s*>|<!--[\s\S]*?-->|<![^>]*>|<\/?[A-Za-z][^>"']*(?:(?:"[^"]*"|'[^']*')[^>"']*)*>/gi;
 for(const token of originalCode.matchAll(tokens)){
   const text=originalCode.slice(cursor,token.index);
   if(!skipDepth&&text.trim())pieces.push({start:cursor,end:token.index,heading});
   const raw=token[0],tag=/^<\/?([\w-]+)/.exec(raw)?.[1]?.toLowerCase();
   if(tag==='script')scripts.push({start:token.index,end:token.index+raw.length,text:raw});
   else if(!['style'].includes(tag)&&!raw.startsWith('<!--')){
     if(/^<svg\b/i.test(raw)||/^<head\b/i.test(raw))skipDepth++;
     if(/^<\/(?:svg|head)\b/i.test(raw))skipDepth=Math.max(0,skipDepth-1);
     if(!skipDepth&&!raw.startsWith('</'))for(const m of raw.matchAll(/\b(href|src|datetime|aria-label|title|data-video|data-url)\s*=\s*(["'])([\s\S]*?)\2/gi)){const start=token.index+m.index+m[0].indexOf(m[2])+1;attrs.push({name:m[1].toLowerCase(),start,end:start+m[3].length,text:m[3],tag,heading});}
     if(/^<h[1-6]\b/i.test(raw)){const e=originalCode.indexOf('</h',token.index+raw.length);if(e>=0)heading=clean(originalCode.slice(token.index+raw.length,e).replace(/<[^>]*>/g,'')).slice(0,90)||heading;}
   }
   cursor=token.index+raw.length;
 }
 if(originalCode.slice(cursor).trim())pieces.push({start:cursor,end:originalCode.length,heading});
 const term=TERMS[id];
 if(term){
   const startField=field('termStart','Term starts','date',term[0],'Term',{settingsPath:'term.startDate',required:true});
   const endField=field('termEnd','Term ends','date',term[1],'Term',{settingsPath:'term.endDate',required:true});
   const season=field('termSeason','Term','select','Autumn','Term',{settingsPath:'term.season',options:['Spring','Summer','Autumn']});
   const weeks=field('termWeeks','Teaching weeks','number',term[2],'Term',{settingsPath:'term.totalWeeks',min:1,max:53,step:1});
   const semanticPieces=[...pieces,...attrs.filter(a=>['aria-label','title'].includes(a.name))];
   for(const s of scripts){for(const m of s.text.matchAll(/(?:"(?:\\.|[^"\\])*"|'(?:\\.|[^'\\])*')/g)){semanticPieces.push({start:s.start+m.index+1,end:s.start+m.index+m[0].length-1,script:true});}}
   for(const p of semanticPieces){const raw=originalCode.slice(p.start,p.end);
     for(const [iso,f] of [[term[0],startField],[term[1],endField]]){const date=new Date(iso+'T00:00:00Z'),month=MONTHS[date.getUTCMonth()],day=date.getUTCDate();const pattern=new RegExp('(?:(Monday|Tuesday|Wednesday|Thursday|Friday|Saturday|Sunday|Mon|Tue|Wed|Thu|Fri|Sat|Sun)[ ,]+)?('+day+')(?:st|nd|rd|th)?[ \\t]+('+month+'|'+month.slice(0,3)+')(?:[ \\t]+(2026))?','g');
       for(const m of raw.matchAll(pattern)){const weekday=m[1]?m[1].length>3?'dddd ':'ddd ':'';const ordinal=/\d(?:st|nd|rd|th)\b/.test(m[0]);bind(f,p.start+m.index,p.start+m.index+m[0].length,'html-text',{format:'date-custom',datePattern:weekday+(ordinal?'Do':'D')+' '+(m[3].length>3?'MMMM':'MMM')+(m[4]?' YYYY':'')});}}
     for(const m of (p.script && !/\b(?:[Tt]erm|[Pp]rogramme)\s/.test(raw) ? [] : raw.matchAll(/\bAutumn\b/g)))bind(season,p.start+m.index,p.start+m.index+6);
     for(const m of (p.script && !/\b(?:[Tt]erm|[Pp]rogramme)\s/.test(raw) ? [] : raw.matchAll(/\bautumn\b/g)))bind(season,p.start+m.index,p.start+m.index+6,'html-text',{format:'lowercase'});
     for(const m of raw.matchAll(new RegExp('\\b'+term[2]+'(?=[ -]*[Ww]eeks?\\b)','g')))bind(weeks,p.start+m.index,p.start+m.index+m[0].length,'number');
     if(/term|autumn/i.test(raw)&&!/copyright|©|opening/i.test(raw)&&(!p.script||/\b[Tt]erm\s/.test(raw)))for(const m of raw.matchAll(/\b2026\b/g))bind(endField,p.start+m.index,p.start+m.index+4,'html-text',{format:'date-custom',datePattern:'YYYY'});
   }
   for(const s of scripts){for(const m of s.text.matchAll(/\b(?:TOTAL_WEEKS|TERM_WEEKS|totalWeeks)\s*=\s*(\d+)/g)){const at=s.start+m.index+m[0].lastIndexOf(m[1]);bind(weeks,at,at+m[1].length,'number');}
     for(const m of s.text.matchAll(/(?:new Date|Date\.UTC)\(\s*(\d{4})\s*,\s*(\d{1,2})\s*,\s*(\d{1,2})((?:\s*,\s*\d+){0,4})\s*\)/g)){const iso=m[1]+'-'+String(+m[2]+1).padStart(2,'0')+'-'+m[3].padStart(2,'0');const f=iso===term[0]?startField:iso===term[1]?endField:null;if(f)bind(f,s.start+m.index,s.start+m.index+m[0].length,'js-date',{dateConstructor:m[0].startsWith('Date.UTC')?'utc':'date',timeArguments:m[4].split(',').slice(1).map(Number)});}}
 }
 function literalField(name,node,label,extra={}){const type=typeof node.value==='number'?'number':String(node.value).length>130?'textarea':'text';const f=field(name,label,type,node.value,'Classes & fees',extra);bind(f,node.start,node.end,type==='number'?'number':'js-string',{htmlText:true});return f;}
 if(id==='swl-classes-1'){
  const feeKeys={'Beginners':'beginners','Intermediate':'intermediate','Advanced':'advanced','Junior Advanced Class':'junioradvanced','Junior Squad':'juniorsquad','Floor & Vault Squad':'floorvault','Senior Elite Squad':'seniorelite'};
  const levels=config(originalCode,'LEVELS');for(const level of levels.properties){for(const child of level.properties){if(child.key==='total')literalField('fee_'+feeKeys[level.key],child,level.key+' · full term fee (£, including membership)',{settingsClassKey:feeKeys[level.key],settingsOffsetPath:'details.membershipFee',min:0,max:100000,help:'Applying club settings adds the membership charge to renewal tuition.'});if(child.key==='short')literalField('title_'+feeKeys[level.key],child,level.key+' · display name');}}
  const membership=config(originalCode,'MEMBERSHIP_FEE');const mf=literalField('membershipFee',membership,'Annual membership included (£)',{settingsPath:'details.membershipFee',min:0,max:10000});
  for(const p of pieces)for(const m of originalCode.slice(p.start,p.end).matchAll(/(?<=£)40(?= annual membership)/g))bind(mf,p.start+m.index,p.start+m.index+2,'number');
  const schedule=config(originalCode,'SCHEDULE');const f=field('weeklySchedule','Weekly class timetable','list',schedule.value,'Classes & fees',{itemLabel:'class',maxItems:100,itemFields:[{id:'day',label:'Day',type:'select',defaultValue:'Monday',options:['Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday']},{id:'level',label:'Class',type:'select',defaultValue:'Beginners',options:Object.keys(levels.value)},{id:'time',label:'Time (24-hour, start – end)',type:'text',defaultValue:'17:00 – 17:45',required:true,validation:'time-range'},{id:'tag',label:'Note',type:'text',defaultValue:''}],help:'Keep times in the format 17:00 – 17:45. Senior Elite has two sessions but one combined fee.'});bind(f,schedule.start,schedule.end,'json',{htmlFields:['time','tag']});
 }
 if(id==='apex-timetable1-1'){
  const programmes=config(originalCode,'programmes');for(const programme of programmes.properties)for(const child of programme.properties){if(['title','age','duration','ratio','description'].includes(child.key))literalField('programme_'+programme.key+'_'+child.key,child,programme.value.title+' · '+nice(child.key));if(child.key==='skills'){for(let i=0;i<child.children.length;i++)literalField('skill_'+programme.key+'_'+i,child.children[i],programme.value.title+' · skill '+(i+1));}}
  const sessions=config(originalCode,'sessions');const f=field('weeklySchedule','Thursday class timetable','list',sessions.value.map(row=>({programme:row[0],time:row[1]})),'Classes & fees',{itemLabel:'class',maxItems:50,itemFields:[{id:'programme',label:'Class',type:'select',defaultValue:'beginner',options:programmes.properties.map(p=>({value:p.key,label:p.value.title}))},{id:'time',label:'Time',type:'text',defaultValue:'4:15–5:00pm',required:true}]});bind(f,sessions.start,sessions.end,'json',{arrayFields:['programme','time'],htmlFields:['time']});
 }
 // Static class fee cards retain the captured price basis; central reuse is explicit.
 const fees=id==='fulham-classes-1'?[['292','beginners','Beginners'],['334','intermediate','Intermediate'],['376','advanced','Advanced']]:id==='apex-dance-timetable1-1'?[['210','junioracro','Junior Acro'],['240','intermediateacro','Intermediate / Advanced Acro']]:[];
 for(const [value,key,label]of fees){const f=field('fee_'+key,label+' · full term fee (£)','number',Number(value),'Classes & fees',{settingsClassKey:key,...(clubId==='fulham'?{settingsOffsetPath:'details.membershipFee'}:{}),min:0,max:100000,help:clubId==='fulham'?'Includes the membership charge.':'Term tuition; review each class before using.'});for(const p of pieces)for(const m of originalCode.slice(p.start,p.end).matchAll(new RegExp('£('+value+')(?![\\d.])','g')))bind(f,p.start+m.index+1,p.start+m.index+m[0].length,'number');}
 // Text-node edits preserve every surrounding tag, CSS rule and script.
 for(const p of pieces){const raw=originalCode.slice(p.start,p.end),left=raw.search(/\S/);if(left<0)continue;const trimmed=raw.trimEnd();const start=p.start+left,end=p.start+trimmed.length,value=decode(originalCode.slice(start,end));if(!available(start,end)||!/[\p{L}\p{N}]/u.test(value)||value.length>14000)continue;
  const label=(p.heading==='Page text'?'':p.heading+' · ')+clean(value).slice(0,75);const f=field('text_'+(++seq),label,value.length>150||value.includes('\n')?'textarea':'text',value,'Page text');bind(f,start,end);
 }
 for(const a of attrs){if(!available(a.start,a.end)||!a.text||a.text.startsWith('data:'))continue;
   if((a.name==='href'||a.name==='data-video'||a.name==='data-url'||a.name==='src'&&a.tag==='iframe')&&!a.text.startsWith('#')){
    const value=decode(a.text);if(!/^(?:https?:|mailto:|tel:|\/[^\/])/.test(value))continue;
    const f=field('link_'+(++seq),(a.heading==='Page text'?'':a.heading+' · ')+(a.tag==='iframe'?'Embedded video / form link':'Link')+' '+seq,'url',value,'Links',{help:'Keep registration, venue and enquiry links separate when their purpose differs.'});bind(f,a.start,a.end,'html-attribute');
   }
 }
 // Source fields without a safe range are omitted rather than silently doing nothing.
 t.fields=t.fields.filter(f=>t.bindings.some(b=>b.fieldId===f.id));
 enrichTerms(t);
 enrichApex(t);
 enrichSwlDance(t);
 enrichEvents(t);
 validateTemplate(t);if(generateWebsiteCode(t)!==originalCode)throw Error(id+' lost source fidelity');
 results.push(t);console.log(id+': '+t.fields.length+' fields, '+t.bindings.length+' source locations');
}
fs.writeFileSync(path.join(dir,'../../dist/website-catalog.js'),'// Captured Squarespace originals. Generated by scripts/website-sources/build-catalog.mjs.\nexport const WEBSITE_CATALOG = '+JSON.stringify(results).replace(/</g,'\\u003c')+';\n');
fs.writeFileSync(path.join(dir,'catalog-summary.json'),JSON.stringify(results.map(({id,clubId,title,fields,bindings,originalSha256})=>({id,clubId,title,fields:fields.length,bindings:bindings.length,originalSha256})),null,2)+'\n');
console.log('Catalog complete: '+results.length+' components.');
