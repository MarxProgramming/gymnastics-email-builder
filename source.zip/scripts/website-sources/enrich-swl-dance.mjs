// Semantics specific to the captured SWL and Apex Dance code. Original source
// offsets remain authoritative; this helper never rewrites the original snippet.
function addField(template, field) {
  const existing = template.fields.find(item => item.id === field.id);
  if (existing) { Object.assign(existing, field); return existing; }
  template.fields.push(field); return field;
}
function bind(template, fieldId, start, end, extra = {}) {
  if (start < 0 || end <= start) throw new Error(template.id + ': a semantic source location was not found.');
  template.bindings = template.bindings.filter(item => !(item.start < end && item.end > start));
  template.bindings.push({ fieldId, start, end, original: template.originalCode.slice(start, end), encoding: 'html-text', ...extra });
}
function bindMatch(template, fieldId, region, expression, group = 1, extra = {}) {
  const match = expression.exec(region.text);
  if (!match || match[group] == null) throw new Error(template.id + ': could not locate ' + fieldId + '.');
  const offset = match[0].indexOf(match[group]);
  const start = region.start + match.index + offset;
  bind(template, fieldId, start, start + match[group].length, extra);
  return match[group];
}
function bindUnique(template, fieldId, text, extra = {}) {
  const start = template.originalCode.indexOf(text);
  if (start < 0 || template.originalCode.indexOf(text, start + 1) >= 0) throw new Error(template.id + ': expected one source occurrence of ' + text);
  bind(template, fieldId, start, start + text.length, extra);
}
function prune(template) { template.fields = template.fields.filter(field => template.bindings.some(binding => binding.fieldId === field.id)); }
const danceCards = [
  { marker:'FRIDAY JUNIOR ACRO', day:'Friday', key:'junioracro', name:'Junior Acro', start:'17:30', end:'18:15', duration:45, fee:210, weekly:14 },
  { marker:'FRIDAY INTERMEDIATE ACRO', day:'Friday', key:'intermediateacro', name:'Intermediate Acro', start:'18:30', end:'19:30', duration:60, fee:240, weekly:16 },
  { marker:'FRIDAY ADVANCED ACRO', day:'Friday', key:'advancedacro', name:'Advanced Acro', start:'19:30', end:'20:30', duration:60, fee:240, weekly:16 },
  { marker:'SATURDAY JUNIOR ACRO', day:'Saturday', key:'junioracro', name:'Junior Acro', start:'09:15', end:'10:00', duration:45, fee:210, weekly:14 },
  { marker:'SATURDAY INTERMEDIATE ACRO', day:'Saturday', key:'intermediateacro', name:'Intermediate Acro', start:'10:00', end:'11:00', duration:60, fee:240, weekly:16 }
];
function enrichDanceTimetable(template) {
  const source = template.originalCode;
  danceCards.forEach((card, index) => {
    const start = source.indexOf('<!-- ' + card.marker + ' -->');
    const next = index + 1 < danceCards.length ? source.indexOf('<!-- ' + danceCards[index + 1].marker + ' -->') : source.length;
    if (start < 0 || next <= start) throw new Error('Dance timetable class markers changed.');
    const region = { start, text: source.slice(start, next) };
    const base = card.day.toLowerCase() + '_' + card.key;
    addField(template, { id:'fee_' + card.key, label:card.name + ' · full term tuition (£)', type:'number', defaultValue:card.fee, group:'Classes & fees', min:0, max:100000, settingsClassKey:card.key, help:'This tuition covers one weekly class. Review its per-session rate below if changing the fee or teaching weeks.' });
    bindMatch(template, 'fee_' + card.key, region, /<div class="price-val">£(\d+)<\/div>/, 1, {encoding:'number'});
    addField(template, { id:'weeklyFee_' + card.key, label:card.name + ' · advertised per-session rate (£)', type:'number', defaultValue:card.weekly, group:'Classes & fees', min:0, max:10000, help:'Check this rate against the full term tuition and teaching weeks. It is shared by this class type on both days.' });
    bindMatch(template, 'weeklyFee_' + card.key, region, /<div class="price-session">£(\d+) \/ session<\/div>/, 1, {encoding:'number'});
    addField(template, { id:'className_' + card.key, label:card.name + ' · display name', type:'text', defaultValue:card.name, group:'Classes & fees', required:true });
    bindMatch(template, 'className_' + card.key, region, /<div class="class-name">([^<]+)<\/div>/);
    for (const part of ['start','end']) addField(template, { id:'time_' + base + '_' + part, label:card.day + ' ' + card.name + ' · ' + (part === 'start' ? 'start' : 'finish'), type:'time', defaultValue:card[part], group:'Classes & times', required:true });
    const time = /<div class="time-val">(\d{1,2}:\d{2})\s*–\s*(\d{1,2}:\d{2})<\/div>/.exec(region.text);
    if (!time) throw new Error('Dance timetable time range changed for ' + base);
    const startAt = region.start + time.index + time[0].indexOf(time[1]);
    const endAt = region.start + time.index + time[0].lastIndexOf(time[2]);
    bind(template, 'time_' + base + '_start', startAt, startAt + time[1].length, {format:'time-12',omitPeriod:true});
    bind(template, 'time_' + base + '_end', endAt, endAt + time[2].length, {format:'time-12',omitPeriod:true});
    addField(template, { id:'duration_' + base, label:card.day + ' ' + card.name + ' · duration (minutes)', type:'number', defaultValue:card.duration, group:'Classes & times', min:1, max:600, step:1, help:'Keep the advertised duration in line with the start and finish times.' });
    bindMatch(template, 'duration_' + base, region, /<div class="time-dur">(\d+) min<\/div>/, 1, {encoding:'number'});
  });
  // Supporting summaries use the same time controls as their corresponding card.
  const overview = source.indexOf('Friday 5:30–8:30 pm · Saturday 9:15–11:00 am');
  if (overview < 0) throw new Error('Dance timetable session summary changed.');
  const overviewText = 'Friday 5:30–8:30 pm · Saturday 9:15–11:00 am';
  for (const [text,id,offset] of [
    ['5:30','time_friday_junioracro_start',0], ['8:30 pm','time_friday_advancedacro_end',0],
    ['9:15','time_saturday_junioracro_start',0], ['11:00 am','time_saturday_intermediateacro_end',0]
  ]) {
    const start = overview + overviewText.indexOf(text, offset);
    bind(template,id,start,start+text.length,{format:'time-12',...(text.includes(' ') ? {periodSpace:true} : {omitPeriod:true})});
  }
  bindUnique(template,'time_friday_junioracro_start','5:30 pm',{format:'time-12',periodSpace:true});
  bindUnique(template,'time_saturday_junioracro_start','9:15 am',{format:'time-12',periodSpace:true});
  bindUnique(template,'time_saturday_intermediateacro_start','10:00 am',{format:'time-12',periodSpace:true});
  for (const [label,id] of [['Junior Acro','className_junioracro'],['Intermediate Acro','className_intermediateacro']]) {
    const sentence = '<strong>' + label + ' at ';
    const at = source.indexOf(sentence);
    if (at < 0) throw new Error('Dance timetable day description changed.');
    bind(template,id,at+'<strong>'.length,at+'<strong>'.length+label.length);
  }
  prune(template);
}
export function enrichTemplate(template) {
  if (template.id === 'apex-dance-timetable1-1') enrichDanceTimetable(template);
  if (template.id === 'swl-classes-1') {
    const timetable = template.fields.find(field => field.id === 'weeklySchedule');
    if (!timetable || timetable.defaultValue.length !== 30) throw new Error('The captured SWL timetable must retain all 30 weekly sessions.');
    const timeField = timetable.itemFields.find(field => field.id === 'time');
    timeField.validation = 'time-range';
    timeField.help = 'Use a 24-hour start and finish, such as 17:00 – 17:45.';
    if (timetable.defaultValue.filter(item => item.level === 'Senior Elite Squad').length !== 2) throw new Error('SWL Senior Elite must retain both sessions of its combined programme.');
  }
  return template;
}
