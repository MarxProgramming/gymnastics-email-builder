// Produce one offline HTML file with exactly the same generator and email designs.
// No runtime evaluation, build dependencies, network requests or external assets.
import { readFile, writeFile, mkdir } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const safeJSON = value => JSON.stringify(value).replace(/</g, '\\u003c').replace(/\u2028/g, '\\u2028').replace(/\u2029/g, '\\u2029');
const withoutExports = source => source.replace(/^export /gm, '');

export async function buildStandalone() {
  const dist = path.join(root, 'dist');
  const templates = {};
  const logos = {};
  for (const id of ['swl', 'fulham', 'apex', 'apexdance']) {
    templates[id] = await readFile(path.join(dist, 'templates', `${id}.gs`), 'utf8');
    const extension = ['apex', 'apexdance'].includes(id) ? 'png' : 'jpg';
    const image = await readFile(path.join(dist, 'templates', `${id}.${extension}`));
    logos[`templates/${id}.${extension}`] = `data:image/${extension === 'png' ? 'png' : 'jpeg'};base64,${image.toString('base64')}`;
  }
  let [html, css, engine, rendererCode, applicationSource, accessSource, campaignSource, timetableSource, clubInfoSource, termSource, swlRenewalSource] = await Promise.all([
    readFile(path.join(dist, 'index.html'), 'utf8'),
    readFile(path.join(dist, 'styles.css'), 'utf8'),
    readFile(path.join(dist, 'engine.js'), 'utf8'),
    readFile(path.join(dist, 'templates/renderers.js'), 'utf8'),
    readFile(path.join(dist, 'app.js'), 'utf8'),
    readFile(path.join(dist, 'access.js'), 'utf8'),
    readFile(path.join(dist, 'campaigns.js'), 'utf8'),
    readFile(path.join(dist, 'timetables.js'), 'utf8'),
    readFile(path.join(dist, 'club-info.js'), 'utf8'),
    readFile(path.join(dist, 'term-defaults.js'), 'utf8'),
    readFile(path.join(dist, 'swl-renewals.js'), 'utf8')
  ]);
  const loadStart = engine.indexOf('export async function loadTemplate(clubId)');
  const loadEnd = engine.indexOf('\nfunction personalise(', loadStart);
  if (loadStart < 0 || loadEnd < 0) throw new Error('Could not find the template loader. Update the standalone bundler for the new engine.');
  engine = engine.slice(0, loadStart) + `async function loadTemplate(clubId) {
  clubFor(clubId);
  return embeddedTemplates[clubId];
}
` + engine.slice(loadEnd);
  engine = engine.replace(/^import .* from '\.\/templates\/renderers\.js';\n/m, '');
  engine = engine.replace(/^import .* from '\.\/campaigns\.js';\n/m, '');
  engine = engine.replace(/^import .* from '\.\/term-defaults\.js';\n/m, '');
  engine = engine.replace(/^import .* from '\.\/swl-renewals\.js';\n/m, '');
  for (const [logoPath, dataURI] of Object.entries(logos)) engine = engine.replace(`logo: '${logoPath}'`, `logo: ${safeJSON(dataURI)}`);
  engine = withoutExports(engine);
  applicationSource = applicationSource.replace(/^import .* from '\.\/engine\.js';\n/m, '');
  applicationSource = applicationSource.replace(/^import .* from '\.\/access\.js';\n/m, '');
  applicationSource = applicationSource.replace(/^import .* from '\.\/campaigns\.js';\n/m, '');
  applicationSource = applicationSource.replace(/^import .* from '\.\/timetables\.js';\n/m, '');
  applicationSource = applicationSource.replace(/^import .* from '\.\/club-info\.js';\n/m, '');
  applicationSource = applicationSource.replace(/^import .* from '\.\/term-defaults\.js';\n/m, '');
  termSource = termSource.replace(/^import .* from '\.\/(?:timetables|campaigns)\.js';\n/gm, '');
  accessSource = withoutExports(accessSource);
  const engineSource = `const embeddedTemplates = ${safeJSON(templates)};\n${withoutExports(rendererCode)}\n${withoutExports(campaignSource)}\n${withoutExports(timetableSource)}\n${withoutExports(clubInfoSource)}\n${withoutExports(termSource)}\n${withoutExports(swlRenewalSource)}\n${engine}`;
  const script = `(function () {\n'use strict';\n${accessSource}\n${engineSource}\n${applicationSource}\n})();`;
  if (/<\/script/i.test(script) || /<\/style/i.test(css)) throw new Error('Unexpected closing tag in bundled code.');
  if (/^\s*(?:import|export)\s/m.test(script) || script.includes('import.meta')) throw new Error('An unbundled module reference remains.');
  const stylesheetTag = '<link rel="stylesheet" href="styles.css">';
  const scriptTag = '<script type="module" src="app.js"></script>';
  if (!html.includes(stylesheetTag) || !html.includes(scriptTag)) throw new Error('Update the bundler for the new HTML entry points.');
  html = html.replace(stylesheetTag, `<style>\n${css}\n</style>`).replace(scriptTag, '');
  html = html.replace('class="wordmark" href="./"', 'class="wordmark" href="#"');
  html = html.replace('</body>', `<script>\n${script}\n</script>\n</body>`);
  return { html, engineSource, applicationSource, accessSource };
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const destination = path.resolve(process.argv[2] || path.join(root, 'build/index.html'));
  const { html } = await buildStandalone();
  await mkdir(path.dirname(destination), { recursive: true });
  await writeFile(destination, html);
  console.log(`Standalone app saved (${Buffer.byteLength(html)} bytes).`);
}
