// Rebuild preview functions from the checked-in app templates.
// Original desktop masters are never accessed or modified by this step.
import { readFile, writeFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import path from 'node:path';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const destination = path.join(root, 'dist/templates');
let renderers = '// Generated from the checked-in app templates. Email design and escaping are preserved.\n';
for (const [id, prefix] of [['swl', 'Swl'], ['fulham', 'Fulham'], ['apex', 'Apex'], ['apexdance', 'ApexDance']]) {
  const master = await readFile(path.join(destination, `${id}.gs`), 'utf8');
  const start = master.indexOf(`function build${prefix}Email_(`);
  const end = master.indexOf('// ==========================================\n// HELPERS', start);
  let renderer = master.slice(start, end).trim();
  renderer = renderer.replace(`function build${prefix}Email_(parent, child)`, `export function build${prefix}Email_(parent, child, content)`);
  renderer = renderer.replace(`${id}EmailContent_(parent, child)`, 'content');
  const escapeStart = master.indexOf(`function escape${prefix}Html_(`);
  const escapeEnd = master.indexOf(`function get${prefix}Logo_(`, escapeStart);
  if (start < 0 || end < 0 || escapeStart < 0 || escapeEnd < 0) throw new Error(`Cannot extract ${id} renderer.`);
  renderers += `\n${renderer}\n\n${master.slice(escapeStart, escapeEnd).trim()}\n`;
}
await writeFile(path.join(destination, 'renderers.js'), renderers);
console.log('Rebuilt four exact email preview renderers.');
