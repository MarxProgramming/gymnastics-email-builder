// Rebuild the browser assets only when intentionally importing updated masters.
// The masters themselves are never modified.
import { readFile, writeFile, mkdir } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import path from 'node:path';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const source = process.argv[2];
if (!source) throw new Error('Pass the folder containing the SWL, Fulham and Apex master folders.');
const destination = path.join(root, 'dist/templates');
await mkdir(destination, { recursive: true });
let renderers = '// Generated from the saved club masters. Email design and escaping are preserved.\n';
for (const [club, prefix, type] of [['SWL', 'Swl', 'jpeg'], ['Fulham', 'Fulham', 'jpeg'], ['Apex', 'Apex', 'png']]) {
  const id = club.toLowerCase();
  const master = await readFile(path.join(source, club, `${club} reusable email template.gs`), 'utf8');
  await writeFile(path.join(destination, `${id}.gs`), master);
  const match = master.match(new RegExp(`const ${club.toUpperCase()}_LOGO_BASE64 = (["'])([A-Za-z0-9+/=]+)\\1;`));
  if (!match) throw new Error(`Cannot find embedded logo for ${club}.`);
  await writeFile(path.join(destination, `${id}.${type === 'jpeg' ? 'jpg' : type}`), Buffer.from(match[2], 'base64'));
  const start = master.indexOf(`function build${prefix}Email_(`);
  const end = master.indexOf('// ==========================================\n// HELPERS', start);
  let renderer = master.slice(start, end).trim();
  renderer = renderer.replace(`function build${prefix}Email_(parent, child)`, `export function build${prefix}Email_(parent, child, content)`);
  renderer = renderer.replace(`${id}EmailContent_(parent, child)`, 'content');
  const escapeStart = master.indexOf(`function escape${prefix}Html_(`);
  const escapeEnd = master.indexOf(`function get${prefix}Logo_(`, escapeStart);
  if (start < 0 || end < 0 || escapeStart < 0 || escapeEnd < 0) throw new Error(`Cannot extract ${club} renderer.`);
  renderers += `\n${renderer}\n\n${master.slice(escapeStart, escapeEnd).trim()}\n`;
}
await writeFile(path.join(destination, 'renderers.js'), renderers);
console.log('Copied three unchanged masters, embedded logos and exact email renderers.');
