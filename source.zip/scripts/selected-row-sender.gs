function onOpen() {
  SpreadsheetApp.getUi()
    .createMenu('__MENU__ emails')
    .addItem('Send selected emails', 'sendSelected__PREFIX__Emails')
    .addItem('Check selected rows (no email)', 'checkSelected__PREFIX__Rows')
    .addToUi();
}

function sendSelected__PREFIX__Emails() { process__PREFIX__Emails_(false); }
function checkSelected__PREFIX__Rows() { process__PREFIX__Emails_(true); }

function normaliseEmailHeading_(value) {
  return String(value || '').normalize('NFKC').toLowerCase()
    .replace(/['’‘]/g, '').replace(/[._:\/()\-]+/g, ' ').replace(/\s+/g, ' ').trim();
}

function emailHeadingAliases_() {
  return {
    child: ['childs name','child name','childs first name','child first name','childs full name','child full name','gymnast name','gymnasts name','participant name','student name'],
    parent: ['parents name','parent name','parents first name','parent first name','parents full name','parent full name','parent 1 name','parent1 name','guardian name','guardians name','parent guardian name','parent or guardian name','primary parent name','primary contact name'],
    email: ['email','email address','parent email','parents email','parent email address','parents email address','primary email','primary email address','contact email','contact email address'],
    status: ['email status','email send status','email sending status'],
    review: ['review','email review']
  };
}

function emailHeadingMatches_(values, aliases) {
  const matches = {};
  Object.keys(aliases).forEach(key => {
    matches[key] = [];
    values.forEach((value, index) => {
      if (aliases[key].includes(normaliseEmailHeading_(value))) matches[key].push(index + 1);
    });
  });
  return matches;
}

function emailColumnLetter_(column) {
  let label = '';
  for (let number = column; number > 0; number = Math.floor((number - 1) / 26)) label = String.fromCharCode(65 + (number - 1) % 26) + label;
  return label;
}

function resolveEmailColumns_(sheet) {
  const width = sheet.getLastColumn();
  const height = Math.min(20, sheet.getLastRow());
  if (!width || !height) throw new Error('The sheet is empty. Add headings for Childs Name, Parents Name and Email within the first 20 rows.');
  const aliases = emailHeadingAliases_();
  const rows = sheet.getRange(1, 1, height, width).getDisplayValues();
  const required = ['child', 'parent', 'email'];
  const labels = { child: 'child name', parent: 'parent name', email: 'email address', status: 'Email Status', review: 'Review' };
  const scanned = rows.map((values, index) => {
    const matches = emailHeadingMatches_(values, aliases);
    return { row: index + 1, values, matches, score: required.filter(key => matches[key].length).length };
  });
  const candidates = scanned.filter(item => item.score === required.length);
  if (candidates.length > 1) throw new Error('More than one possible heading row was found: ' + candidates.map(item => item.row).join(', ') + '. Keep one set of email headings within the first 20 rows.');
  if (!candidates.length) {
    const best = scanned.slice().sort((a, b) => b.score - a.score)[0];
    const missing = required.filter(key => !best.matches[key].length).map(key => labels[key]);
    throw new Error('Could not identify the ' + missing.join(' and ') + ' heading' + (missing.length > 1 ? 's' : '') + (best.score ? ' in row ' + best.row : ' within the first 20 rows') + '. Use Childs Name (or Child Name), Parents Name (or Parent Name) and Email (or Email Address).');
  }
  const found = candidates[0];
  Object.keys(aliases).forEach(key => {
    if (found.matches[key].length > 1) throw new Error('Ambiguous ' + labels[key] + ' headings in row ' + found.row + ': ' + found.matches[key].map(column => emailColumnLetter_(column) + ' (' + found.values[column - 1] + ')').join(', ') + '. Give only the intended column a recognised heading; no emails were sent.');
  });
  const columns = {};
  Object.keys(aliases).forEach(key => { columns[key] = found.matches[key][0] || 0; });
  return { headerRow: found.row, columns, headings: found.values, lastUsedColumn: width, statusCreated: false };
}

function ensureEmailStatusColumn_(sheet, layout) {
  if (layout.columns.status) return;
  // Recheck the current edge under the document lock; never overwrite attendance or contact columns.
  const lastColumn = sheet.getLastColumn();
  const currentHeadings = sheet.getRange(layout.headerRow, 1, 1, lastColumn).getDisplayValues()[0];
  const existing = emailHeadingMatches_(currentHeadings, emailHeadingAliases_()).status;
  if (existing.length > 1) throw new Error('More than one Email Status column now exists. Resolve the duplicate headings before sending.');
  if (existing.length === 1) {
    layout.columns.status = existing[0];
    layout.headings = currentHeadings;
    return;
  }
  const column = lastColumn + 1;
  const maximum = sheet.getMaxColumns();
  if (column > maximum) sheet.insertColumnsAfter(maximum, column - maximum);
  sheet.getRange(layout.headerRow, column).setValue('Email Status');
  SpreadsheetApp.flush();
  layout.columns.status = column;
  layout.headings[column - 1] = 'Email Status';
  layout.statusCreated = true;
}

function emailMappingSummary_(layout) {
  if (!layout) return '';
  const line = (label, key) => label + ': ' + emailColumnLetter_(layout.columns[key]) + ' — ' + layout.headings[layout.columns[key] - 1];
  return ['Heading row: ' + layout.headerRow, line('Child', 'child'), line('Parent', 'parent'), line('Recipient', 'email'),
    layout.columns.status ? line('Status', 'status') + (layout.statusCreated ? ' (created)' : '') : 'Status: Email Status will be added after the last used column (currently ' + emailColumnLetter_(layout.lastUsedColumn + 1) + ') when sending the first eligible row.',
    layout.columns.review ? line('Review', 'review') : 'Review: no Review column; this optional filter is not applied.'].join('\n');
}

function emailSkipSummary_(reasons) {
  const labels = { status: 'already marked in Email Status', review: 'marked for Review', hidden: 'hidden or filtered', child: 'missing child name', parent: 'missing parent name', email: 'invalid or missing email address' };
  const items = Object.keys(labels).filter(key => reasons[key]).map(key => reasons[key] + ' ' + labels[key]);
  return items.length ? items.join('; ') : 'none';
}

function process__PREFIX__Emails_(dryRun) {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const sheet = ss.getActiveSheet();
  const selection = ss.getSelection().getActiveRangeList();
  if (!selection) { ss.toast('Highlight the data rows you want to email first.', '__MENU__ emails', 15); return; }
  const selected = new Set();
  const lastRow = sheet.getLastRow();
  selection.getRanges().forEach(range => {
    for (let row = Math.max(1, range.getRow()); row <= Math.min(lastRow, range.getLastRow()); row++) selected.add(row);
  });
  const lock = LockService.getDocumentLock();
  if (!lock.tryLock(1000)) { ss.toast('Another send is still running. Wait for it to finish.', '__MENU__ emails', 20); return; }
  let sent = 0, skipped = 0, failed = 0, pause = '', fatal = false, layout = null, rows = [];
  const reasons = { status: 0, review: 0, hidden: 0, child: 0, parent: 0, email: 0 };
  const started = Date.now();
  try {
    layout = resolveEmailColumns_(sheet);
    const columns = layout.columns;
    rows = Array.from(selected).filter(row => row > layout.headerRow).sort((a, b) => a - b);
    if (!rows.length) throw new Error('Select at least one data row below heading row ' + layout.headerRow + '.');
    let quota = dryRun ? Infinity : MailApp.getRemainingDailyQuota();
    if (!dryRun) build__PREFIX__Email_('Parent', 'Child');
    const banner = dryRun ? null : get__PREFIX__Logo_();
    for (let index = 0; index < rows.length; index++) {
      if (Date.now() - started > 240000) { pause = 'Paused at the time limit. Select the same rows and send again to continue.'; break; }
      const row = rows[index];
      const width = Math.max(...Object.values(columns));
      const values = sheet.getRange(row, 1, 1, width).getDisplayValues()[0];
      const previous = columns.status ? String(values[columns.status - 1] || '').trim() : '';
      const review = columns.review ? String(values[columns.review - 1] || '').trim() : '';
      const person = personFromValues_(values, row, columns);
      let reason = '';
      if (previous) reason = 'status';
      else if (review) reason = 'review';
      else if (sheet.isRowHiddenByUser(row) || sheet.isRowHiddenByFilter(row)) reason = 'hidden';
      else if (!person.child) reason = 'child';
      else if (!person.parent) reason = 'parent';
      else if (!isValidEmail_(person.email)) reason = 'email';
      if (reason) { skipped++; reasons[reason]++; continue; }
      if (quota < 1) { pause = 'Google’s daily email allowance is used up. Remaining rows are unsent.'; break; }
      if (dryRun) { sent++; continue; }
      const email = build__PREFIX__Email_(person.parent, person.child);
      ensureEmailStatusColumn_(sheet, layout);
      // Recheck a newly discovered/created status cell before sending this row.
      const status = sheet.getRange(row, columns.status);
      if (String(status.getDisplayValues()[0][0] || '').trim()) { skipped++; reasons.status++; continue; }
      ss.toast('Sending row ' + row + ' (' + (index + 1) + ' of ' + rows.length + '). Sent: ' + sent, '__MENU__ emails', 10);
      let accepted = false;
      try {
        status.setValue('Sending — check Sent mail if interrupted').setBackground('#FFF3CD');
        SpreadsheetApp.flush();
        MailApp.sendEmail(person.email, email.subject, email.plainBody, {
          htmlBody: email.htmlBody, name: '__NAME__', inlineImages: { __ID__Logo: banner.copyBlob() }
        });
        accepted = true;
        sent++; quota--;
        status.setValue('Email sent — ' + Utilities.formatDate(new Date(), 'Europe/London', 'dd/MM/yyyy HH:mm')).setBackground('#E6FFE6');
        SpreadsheetApp.flush();
      } catch (error) {
        failed++;
        try {
          status.setValue((accepted ? 'Sent; status update failed: ' : 'Check Sent mail before retrying: ') + error.message).setBackground('#F8D7DA');
          SpreadsheetApp.flush();
        } catch (statusError) {
          pause = 'Stopped: could not record the result for row ' + row + '. Check Sent mail before retrying.';
          break;
        }
      }
    }
  } catch (error) { pause = error.message; fatal = true; }
  finally { lock.releaseLock(); }
  const skippedDetails = emailSkipSummary_(reasons);
  const totals = dryRun ? 'Test only: ' + sent + ' eligible selected rows; ' + skipped + ' skipped. No emails sent.' : 'Sent: ' + sent + '. Skipped: ' + skipped + '. Errors: ' + failed + '.';
  const details = [totals, 'Selected data rows: ' + rows.length, 'Skip reasons: ' + skippedDetails, pause, emailMappingSummary_(layout)].filter(Boolean).join('\n\n');
  if (dryRun) console.log(JSON.stringify({ testOnly: true, selectedRows: rows.length, wouldSend: sent, skipped, reasons, failed, problem: pause, headerRow: layout && layout.headerRow, columns: layout && layout.columns }));
  ss.toast(totals + ' ' + (skipped ? 'Skip reasons: ' + skippedDetails + '. ' : '') + pause, dryRun ? '__MENU__ email check' : '__MENU__ emails finished', 30);
  // Results only: sending still starts immediately, with no confirmation step.
  if (dryRun || fatal || failed) SpreadsheetApp.getUi().alert((dryRun ? '__MENU__ email check' : '__MENU__ email results') + '\n\n' + details);
}
