// Recreate the two user-requested app-owned variants from the original Apex master.
// The original files are read only. Pass: master-folder, white-Apex-PNG, Dance-logo-PNG.
import { readFile, writeFile, copyFile } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { applyEmailSender } from './sender-source.mjs';
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const [masters, whiteApexPath, danceLogoPath] = process.argv.slice(2);
if (!masters || !whiteApexPath || !danceLogoPath) throw new Error('Pass the master folder, white Apex PNG and Apex Dance PNG.');
const original = await readFile(path.join(masters, 'Apex/Apex reusable email template.gs'), 'utf8');
const whiteApex = (await readFile(whiteApexPath)).toString('base64');
const danceLogo = (await readFile(danceLogoPath)).toString('base64');
const destination = path.join(root, 'dist/templates');

function replaceHeader(source, header) {
  const start = source.indexOf('<!-- APEX LOGO -->');
  const end = source.indexOf('<!-- GREETING AND MESSAGE', start);
  if (start < 0 || end < 0) throw new Error('The original Apex header changed; inspect it before importing.');
  return source.slice(0, start) + header + '\n' + source.slice(end);
}

const apexHeader = `<!-- APEX GRADIENT HEADER — SOLID COLOUR FALLBACK FOR EMAIL CLIENTS -->
<tr>
<td bgcolor="#236E80" align="center" style="padding:24px 24px 26px;text-align:center;background-color:#236E80;background-image:linear-gradient(120deg,#1B566A 0%,#3399B0 100%);border-radius:19px 19px 0 0;">
<a href="https://www.apex-gymnastics.co.uk" style="text-decoration:none;">
<img src="cid:apexLogo" width="120" height="120" alt="Apex Gymnastics logo" style="display:block;width:120px;max-width:100%;height:auto;margin:0 auto;border:0;">
</a>
<p style="margin:8px 0 0;font-family:Arial,Helvetica,sans-serif;font-size:24px;line-height:1.3;letter-spacing:2px;font-weight:700;color:#FFFFFF;">APEX GYMNASTICS</p>
</td>
</tr>`;
let apex = replaceHeader(original, apexHeader)
  .replace(/const APEX_LOGO_BASE64 = ["'][A-Za-z0-9+/=]+["'];/, `const APEX_LOGO_BASE64 = "${whiteApex}";`)
  .replace('GmailApp.sendEmail(', 'MailApp.sendEmail(');
await writeFile(path.join(destination, 'apex.gs'), await applyEmailSender(apex, 'apex'));
await copyFile(whiteApexPath, path.join(destination, 'apex-email.png'));

const danceHeader = `<!-- APEX DANCE GRADIENT HEADER — SOLID COLOUR FALLBACK FOR EMAIL CLIENTS -->
<tr>
<td bgcolor="#1B0D35" align="center" style="padding:22px 24px 26px;text-align:center;background-color:#1B0D35;background-image:linear-gradient(120deg,#0D0718 0%,#3A1F6E 100%);border-bottom:2px solid #C8A84B;border-radius:19px 19px 0 0;">
<a href="https://www.apexdanceclub.co.uk" style="text-decoration:none;">
<img src="cid:apexdanceLogo" width="136" height="136" alt="Apex Dance Club logo" style="display:block;width:136px;max-width:100%;height:auto;margin:0 auto;border:0;">
</a>
<p style="margin:6px 0 0;font-family:Arial,Helvetica,sans-serif;font-size:24px;line-height:1.3;letter-spacing:2px;font-weight:700;color:#F5F0FF;">APEX DANCE CLUB</p>
</td>
</tr>`;
let dance = replaceHeader(original, danceHeader)
  .replaceAll('APEX GYMNASTICS', 'APEX DANCE CLUB')
  .replaceAll('Apex Gymnastics', 'Apex Dance Club')
  .replaceAll('Apex emails', 'Apex Dance emails')
  .replaceAll('Apex email check', 'Apex Dance email check')
  .replaceAll('apexEmailContent_', 'apexdanceEmailContent_')
  .replaceAll('sendSelectedApexEmails', 'sendSelectedApexDanceEmails')
  .replaceAll('checkSelectedApexRows', 'checkSelectedApexDanceRows')
  .replaceAll('processApexEmails_', 'processApexDanceEmails_')
  .replaceAll('buildApexEmail_', 'buildApexDanceEmail_')
  .replaceAll('escapeApexHtml_', 'escapeApexDanceHtml_')
  .replaceAll('getApexLogo_', 'getApexDanceLogo_')
  .replaceAll('apexLogo', 'apexdanceLogo')
  .replaceAll('APEX_LOGO_BASE64', 'APEXDANCE_LOGO_BASE64')
  .replaceAll('Apex-logo.png', 'Apex-Dance-logo.png')
  .replaceAll('https://www.apex-gymnastics.co.uk', 'https://www.apexdanceclub.co.uk')
  .replaceAll('#236E80', '#3A1F6E')
  .replaceAll('#3399B0', '#C8A84B')
  .replaceAll('#EDF8FA', '#F5F1FB')
  .replaceAll('#D7E5E8', '#E4DBEE')
  .replaceAll('#F3F9FA', '#F8F5FC')
  .replaceAll('#64748B', '#786887')
  .replaceAll('rgba(35,110,128,0.09)', 'rgba(58,31,110,0.09)')
  .replace(/const APEXDANCE_LOGO_BASE64 = ["'][A-Za-z0-9+/=]+["'];/, `const APEXDANCE_LOGO_BASE64 = "${danceLogo}";`)
  .replace('GmailApp.sendEmail(', 'MailApp.sendEmail(');
await writeFile(path.join(destination, 'apexdance.gs'), await applyEmailSender(dance, 'apexdance'));
await copyFile(danceLogoPath, path.join(destination, 'apexdance.png'));
console.log('Created app-owned Apex Gymnastics and Apex Dance variants; originals unchanged.');
