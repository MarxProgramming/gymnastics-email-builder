import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import {buildStandalone} from '../scripts/build-standalone.mjs';
import {WEBSITE_CATALOG} from '../dist/website-catalog.js';
import {createManagementState} from '../dist/management-store.js';
import {applyCentralSettings,generateWebsiteCode,getTemplateDefaults} from '../dist/website-generator.js';

test('full standalone script parses and preserves every original website component',async()=>{
 const {html,engineSource,managementSource}=await buildStandalone();
 const script=html.match(/<script>\n([\s\S]*)\n<\/script>/)?.[1];assert.ok(script);assert.doesNotThrow(()=>new vm.Script(script));
 const context=vm.createContext({URL,TextEncoder});
 vm.runInContext(engineSource+'\n'+managementSource+'\nglobalThis.api={WEBSITE_CATALOG,getTemplateDefaults,generateWebsiteCode,applyCentralSettings,createManagementState};',context);
 const api=context.api;assert.equal(api.WEBSITE_CATALOG.length,28);
 for(const template of WEBSITE_CATALOG){
  const embedded=api.WEBSITE_CATALOG.find(item=>item.id===template.id);
  assert.equal(embedded.originalCode,template.originalCode,template.id);
  assert.equal(api.generateWebsiteCode(embedded,api.getTemplateDefaults(embedded)),template.originalCode,template.id);
  const expected=generateWebsiteCode(template,applyCentralSettings(template,getTemplateDefaults(template),createManagementState().clubs[template.clubId]).values);
  const actual=api.generateWebsiteCode(embedded,api.applyCentralSettings(embedded,api.getTemplateDefaults(embedded),api.createManagementState().clubs[template.clubId]).values);
  assert.equal(actual,expected,template.id+' central settings parity');
 }
});
