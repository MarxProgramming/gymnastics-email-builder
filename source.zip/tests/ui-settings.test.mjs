import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import vm from 'node:vm';

// Exercise the actual UI settings functions without mounting or mocking the
// entire interface. Browser QA covers their controls and DOM placement.
const source = await readFile(new URL('../dist/app.js', import.meta.url), 'utf8');
function sourceFunction(name, nextName) {
  const start = source.indexOf(`function ${name}(`);
  const end = source.indexOf(`function ${nextName}(`, start);
  assert.ok(start >= 0 && end > start, `${name} exists in the app`);
  return source.slice(start, end);
}
const termCode = sourceFunction('savedTermSettings', 'restoreTermSettings');
const deadlineCode = sourceFunction('restoreDeadlineSettings', 'updateDeadlineFields');
function settings(mode = 'renewal') {
  const fields = Object.fromEntries(['offer-fixed-deadline','offer-expiry-hours','deadline-kind','payment-deadline','term-start'].map(id => [id,{value:''}]));
  const context = vm.createContext({ fields, emailMode:mode, DAY_MS:86400000, UI_SETTINGS_VERSION:1, string:value => typeof value === 'string' ? value : '', $:id => fields[id] });
  vm.runInContext(termCode + deadlineCode, context);
  return { context, fields };
}
const plain = value => JSON.parse(JSON.stringify(value));
test('standard historical term labels become a dropdown choice and use the start-date year', () => {
  const {context} = settings();
  for (const name of ['Spring 2026','spring term 2026','Spring']) {
    const result = context.savedTermSettings({campaign:{termName:name}});
    assert.deepEqual(plain(result),{choice:'Spring',savedLabel:''});
    assert.equal(context.composeTermName(result.choice,'2027-01-06',result.savedLabel),'Spring 2027');
  }
  assert.equal(context.composeTermName('Autumn','2028-09-01'),'Autumn 2028');
});
test('a genuinely custom historical term label is preserved as a saved choice', () => {
  const {context} = settings();
  const result = context.savedTermSettings({campaign:{termName:'Spring 2026 — extra sessions'}});
  assert.equal(result.choice,'saved');
  assert.equal(context.composeTermName(result.choice,'2027-01-06',result.savedLabel),'Spring 2026 — extra sessions');
});
test('a new term has no invented season/year and an intentional empty choice stays empty', () => {
  const {context} = settings();
  assert.deepEqual(plain(context.savedTermSettings({})),{choice:'',savedLabel:''});
  assert.equal(context.composeTermName('Summer',''),'Summer');
  assert.equal(context.composeTermName('','2027-05-01'),'');
  assert.equal(context.savedTermSettings({termChoice:'',campaign:{termName:'Summer 2026'}}).choice,'');
});
test('renewal deadlines remain manually chosen and term-date changes never calculate another date', () => {
  const {context,fields} = settings('renewal');
  fields['term-start'].value='2027-01-06';
  context.restoreDeadlineSettings({campaign:{}});
  assert.equal(fields['payment-deadline'].value,'');
  fields['payment-deadline'].value='2026-12-20';
  context.restoreDeadlineSettings({campaign:{deadline:'2026-12-20'}});
  assert.equal(fields['payment-deadline'].value,'2026-12-20');
  fields['term-start'].value='2027-04-10';
  context.restoreDeadlineSettings({renewalDeadlineRule:'7',campaign:{deadline:'2026-12-20'}});
  assert.equal(fields['payment-deadline'].value,'2026-12-20');
});
test('a new or old blank offer gets 48 hours, while an existing fixed date or hours are preserved', () => {
  const {context,fields} = settings('offer');
  context.restoreDeadlineSettings({});
  assert.equal(fields['deadline-kind'].value,'hours'); assert.equal(fields['offer-expiry-hours'].value,'48');
  context.restoreDeadlineSettings({deadlineKind:'fixed',campaign:{deadline:'',offerExpiryHours:''}});
  assert.equal(fields['deadline-kind'].value,'hours'); assert.equal(fields['offer-expiry-hours'].value,'48');
  context.restoreDeadlineSettings({deadlineKind:'fixed',campaign:{deadline:'2027-01-03'}});
  assert.equal(fields['deadline-kind'].value,'fixed'); assert.equal(fields['offer-fixed-deadline'].value,'2027-01-03');
  context.restoreDeadlineSettings({deadlineKind:'hours',campaign:{offerExpiryHours:'72'}});
  assert.equal(fields['deadline-kind'].value,'hours'); assert.equal(fields['offer-expiry-hours'].value,'72');
});
test('an intentional blank after settings migration remains blank instead of reapplying 48 hours', () => {
  const {context,fields} = settings('offer');
  context.restoreDeadlineSettings({uiSettingsVersion:1,deadlineKind:'hours',campaign:{offerExpiryHours:''}});
  assert.equal(fields['deadline-kind'].value,'hours'); assert.equal(fields['offer-expiry-hours'].value,'');
});


const presetUiCode = sourceFunction('activeTermPreset', 'updateTermPresetUI');
function presetUi({club='swl', mode='offer', term='Spring 2027', start='2027-01-04', end='2027-03-21', markerClub=club, markerMode=mode, membershipPence=4000} = {}) {
  const fields = { 'term-name':{value:term}, 'term-start':{value:start}, 'term-end':{value:end} };
  const context = vm.createContext({ clubId:club, emailMode:mode, currentTermDefaults:{presetId:'spring-2027',clubId:markerClub,mode:markerMode}, TERM_OFFER_MEMBERSHIP_PENCE:{[club]:membershipPence}, TERM_PRESETS:{[club]:{id:'spring-2027',termName:'Spring 2027',status:'ready',startDate:'2027-01-04',endDate:'2027-03-21',excludedDates:[]}}, $:id => fields[id], getTermFeeHint:()=>'Spring 2027 fees include tuition plus £40 membership.' });
  vm.runInContext(presetUiCode,context);
  return context;
}
test('the SWL Offer all-in label and £40 hint appear only for the active matching term preset', () => {
  const context = presetUi();
  const card = {regularKey:'swl:beginners',combined:false};
  assert.equal(context.feeFieldLabel(card),'Total incl. membership (£)');
  assert.match(context.feeFieldHint(card),/£40 membership/);
});
test('another term or edited date range cannot inherit the Spring preset fee hint', () => {
  for (const state of [{term:'Autumn 2027'}, {start:'2027-01-11'}, {end:'2027-03-28'}]) {
    const context = presetUi(state);
    assert.equal(context.feeFieldLabel({regularKey:'swl:beginners'}),'Term fee (£)');
    assert.doesNotMatch(context.feeFieldHint({regularKey:'swl:beginners'}),/£40/);
  }
});
test('a marker from another club or mode cannot activate the Spring membership label', () => {
  for (const state of [{markerClub:'apex'}, {markerMode:'renewal'}, {mode:'basic'}]) {
    const context = presetUi(state);
    assert.equal(context.activeTermPreset(),null);
    assert.doesNotMatch(context.feeFieldHint({regularKey:'swl:beginners'}),/£40/);
  }
});
test('custom classes keep their own editable fee explanation instead of an assumed preset membership amount', () => {
  const context = presetUi();
  assert.equal(context.feeFieldLabel({regularKey:'',combined:false}),'Term fee (£)');
  assert.doesNotMatch(context.feeFieldHint({regularKey:'',combined:false}),/£40/);
});
test('all-in Offer labels follow confirmed membership metadata for every club', () => {
  assert.equal(presetUi({club:'fulham',membershipPence:4000}).feeFieldLabel({regularKey:'fulham:beginners'}),'Total incl. membership (£)');
  for (const state of [{club:'fulham',membershipPence:null},{club:'apex',membershipPence:0},{club:'swl',mode:'renewal'}]) {
    assert.equal(presetUi(state).feeFieldLabel({regularKey:`${state.club}:beginners`}),'Term fee (£)');
  }
});
