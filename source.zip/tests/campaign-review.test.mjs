import test from 'node:test';
import assert from 'node:assert/strict';
import { getClassSchedule, validateCampaign, renderCampaignContent } from '../dist/campaigns.js';
import { getClubEmailDesign } from '../dist/engine.js';

function campaign(overrides = {}, sessions = [{ weekday: 1, startTime: '17:00', endTime: '18:00' }]) {
  return {
    termName: 'Example term', startDate: '2027-01-01', endDate: '2027-01-31',
    deadline: '2026-12-20', excludedDates: [], excludedRanges: [],
    classes: [{ id: 'example', name: 'Example class', fee: '199.95', paymentUrl: 'https://example.com/pay', sessions }],
    ...overrides
  };
}
const schedule = input => getClassSchedule(input, 'example');

test('review: inclusive calendar dates cross New Year without losing the final session', () => {
  const actual = schedule(campaign({ startDate: '2026-12-28', endDate: '2027-01-04' }));
  assert.deepEqual(actual.sessions[0].dates, ['2026-12-28', '2027-01-04']);
  assert.equal(actual.firstDate, '2026-12-28');
  assert.equal(actual.lastDate, '2027-01-04');
  assert.equal(actual.teachingWeeks, 2);
});

test('review: leap day is a real Tuesday occurrence, while a false leap date is rejected', () => {
  const actual = schedule(campaign({ startDate: '2028-02-27', endDate: '2028-03-05' }, [{ weekday: 2, startTime: '17:00', endTime: '18:00' }]));
  assert.deepEqual(actual.sessions[0].dates, ['2028-02-29']);
  assert.equal(actual.sessionCount, 1);
  assert.throws(() => validateCampaign('renewal', campaign({ startDate: '2027-02-29', endDate: '2027-03-31' })), /valid term start date/);
});

test('review: UK spring and autumn clock changes do not shift or duplicate class dates', () => {
  const sessions = [{ weekday: 0, startTime: '09:30', endTime: '10:30' }];
  const spring = schedule(campaign({ startDate: '2027-03-20', endDate: '2027-04-05' }, sessions));
  const autumn = schedule(campaign({ startDate: '2027-10-17', endDate: '2027-11-07' }, sessions));
  assert.deepEqual(spring.sessions[0].dates, ['2027-03-21', '2027-03-28', '2027-04-04']);
  assert.deepEqual(autumn.sessions[0].dates, ['2027-10-17', '2027-10-24', '2027-10-31', '2027-11-07']);
  assert.equal(spring.sessionCount, 3);
  assert.equal(autumn.sessionCount, 4);
});

test('review: two distinct sessions on one weekday retain both attendances but charge one programme fee', () => {
  const source = campaign({ startDate: '2027-01-04', endDate: '2027-01-11' }, [
    { weekday: 1, startTime: '17:00', endTime: '18:00' },
    { weekday: 1, startTime: '18:15', endTime: '19:15' }
  ]);
  const validated = validateCampaign('renewal', source);
  const actual = schedule(validated);
  assert.equal(actual.sessionCount, 4);
  assert.equal(actual.teachingWeeks, 2);
  assert.deepEqual(actual.sessions.map(item => item.count), [2, 2]);
  assert.equal(validated.classes[0].fee, 199.95);
  const email = renderCampaignContent('renewal', validated, validated.classes[0], { subject: 'Renew {{child}}', body: 'Your next term.' }, { child: 'Alex', parent: 'Pat' }, { name: 'Example Club', accent: '#765091', design: getClubEmailDesign('swl') });
  assert.equal((email.plain.match(/Total term fee: £199\.95/g) || []).length, 1);
  assert.equal((email.html.match(/£199\.95/g) || []).length, 1);
  assert.ok(!email.plain.includes('£399.90'));
});

test('review: a cancelled Monday–Sunday week spans New Year consistently for combined sessions', () => {
  const source = campaign({ startDate: '2026-12-21', endDate: '2027-01-10', excludedRanges: [{ startDate: '2026-12-28', endDate: '2027-01-03' }] }, [
    { weekday: 1, startTime: '17:00', endTime: '18:00' },
    { weekday: 4, startTime: '17:00', endTime: '18:00' },
    { weekday: 0, startTime: '09:30', endTime: '10:30' }
  ]);
  const actual = schedule(source);
  assert.deepEqual(actual.sessions.map(item => item.dates), [
    ['2026-12-21', '2027-01-04'], ['2026-12-24', '2027-01-07'], ['2026-12-27', '2027-01-10']
  ]);
  assert.deepEqual(actual.excludedDates, ['2026-12-28', '2026-12-31', '2027-01-03']);
  assert.equal(actual.sessionCount, 6);
  assert.equal(actual.teachingWeeks, 2);
});

test('review: cancelling first and last dates updates the actual surviving session range', () => {
  const source = campaign({ startDate: '2027-02-01', endDate: '2027-02-28', excludedDates: ['2027-02-04', '2027-02-25'] }, [{ weekday: 4, startTime: '17:00', endTime: '18:00' }]);
  const actual = schedule(source);
  assert.deepEqual(actual.sessions[0].dates, ['2027-02-11', '2027-02-18']);
  assert.equal(actual.firstDate, '2027-02-11');
  assert.equal(actual.lastDate, '2027-02-18');
  assert.equal(actual.sessions[0].firstDate, '2027-02-11');
  assert.equal(actual.sessions[0].lastDate, '2027-02-18');
  assert.equal(actual.teachingWeeks, 2);
});

test('review: non-session term boundaries and an irrelevant cancellation do not become class dates', () => {
  const source = campaign({ startDate: '2027-01-01', endDate: '2027-01-13', excludedDates: ['2027-01-02'] });
  const actual = schedule(source);
  assert.deepEqual(actual.sessions[0].dates, ['2027-01-04', '2027-01-11']);
  assert.deepEqual(actual.excludedDates, []);
  assert.equal(actual.firstDate, '2027-01-04');
  assert.equal(actual.lastDate, '2027-01-11');
});

test('review: overlapping cancellation ranges and explicit dates never double-remove a session', () => {
  const source = campaign({ excludedDates: ['2027-01-11', '2027-01-11'], excludedRanges: [
    { startDate: '2027-01-04', endDate: '2027-01-10' },
    { startDate: '2027-01-08', endDate: '2027-01-12' }
  ] });
  const original = structuredClone(source);
  const validated = validateCampaign('renewal', source);
  const actual = schedule(validated);
  assert.deepEqual(actual.sessions[0].dates, ['2027-01-18', '2027-01-25']);
  assert.deepEqual(actual.excludedDates, ['2027-01-04', '2027-01-11']);
  assert.equal(validated.classes[0].fee, 199.95);
  assert.deepEqual(source, original, 'validation does not change the saved editable draft');
});

test('review: a combined programme with one fully cancelled weekly session cannot be generated as paid', () => {
  const source = campaign({ startDate: '2027-01-04', endDate: '2027-01-10', excludedDates: ['2027-01-04'] }, [
    { weekday: 1, startTime: '17:00', endTime: '18:00' },
    { weekday: 4, startTime: '17:00', endTime: '18:00' }
  ]);
  assert.deepEqual(schedule(source).sessions.map(item => item.count), [0, 1]);
  assert.throws(() => validateCampaign('renewal', source), /weekly session with no dates/);
});
