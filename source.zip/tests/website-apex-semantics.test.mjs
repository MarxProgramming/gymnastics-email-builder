import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import { readFile } from 'node:fs/promises';
import { enrichTemplate } from '../scripts/website-sources/enrich-apex.mjs';
import { generateWebsiteCode, validateTemplate } from '../dist/website-generator.js';

async function component(id) {
 const originalCode=await readFile(new URL('../scripts/website-sources/originals/'+id+'.html',import.meta.url),'utf8');
 return enrichTemplate({id,clubId:'apex',originalCode,fields:[],bindings:[]});
}
function inlineScript(code) { return [...code.matchAll(/<script\b[^>]*>([\s\S]*?)<\/script>/g)].map(match=>match[1]).join('\n'); }

test('semantic Apex bindings preserve original snippets byte for byte by default',async()=>{
 for(const id of ['apex-uniform-1','apex-private-lessons-1']) {
  const template=await component(id);validateTemplate(template);assert.equal(generateWebsiteCode(template),template.originalCode);
 }
});
test('shop access code synchronizes visible, accessible and JavaScript messages safely',async()=>{
 const template=await component('apex-uniform-1'),value='NEW"<&CODE',code=generateWebsiteCode(template,{shopAccessCode:value});
 assert.ok(!code.includes('AGC147'));assert.ok(code.includes('NEW&quot;&lt;&amp;CODE'));
 const nodes={button:{addEventListener(event,fn){this.click=fn;}},label:{},status:{},code:{textContent:value}};let copied;
 const root={dataset:{},querySelector(selector){return {'[data-copy-code]':nodes.button,'[data-copy-label]':nodes.label,'[data-copy-status]':nodes.status,'.access-code':nodes.code}[selector];}};
 vm.runInNewContext(inlineScript(code),{document:{getElementById(){return root;}},window:{isSecureContext:true,clearTimeout(){},setTimeout(){}},navigator:{clipboard:{async writeText(text){copied=text;}}}});
 await nodes.button.click();assert.equal(copied,value);assert.equal(nodes.status.textContent,value+' copied. Paste it into the club shop.');
});
test('private lesson edits update copy-email and every encoded enquiry detail',async()=>{
 const template=await component('apex-private-lessons-1');
 const values={privateDay:'Saturday',privateTime:'10:00–10:45am',privateDuration:45,privatePrice:75,privateCoach:'Jo & Sam',privateEmail:'lessons+bookings@example.com'};
 const code=generateWebsiteCode(template,values);new vm.Script(inlineScript(code));
 assert.ok(!code.includes('Thursday'));assert.ok(!code.includes('Marx'));assert.ok(!code.includes('4:15–5:15pm'));assert.ok(!code.includes('Management@apex-gymnastics.co.uk'));
 const href=code.match(/href="(mailto:[^"]+\?subject=[^"]+)"/)[1].replace(/&amp;/g,'&');const url=new URL(href);
 assert.equal(url.pathname,values.privateEmail);assert.ok(url.searchParams.get('subject').includes('Sat 10:00–10:45am'));assert.ok(url.searchParams.get('body').includes('Saturday 10:00–10:45am private lesson slot with Jo & Sam.'));
 assert.ok(code.includes('<span>45 minutes</span>'));assert.ok(code.includes('<span>45-minute private lesson</span>'));assert.ok(code.includes('The current Saturday slot is 45 minutes.'));assert.ok(code.includes('<strong>£75 <small>/ session</small></strong>'));
 assert.ok(code.includes('<dt>60 minutes</dt>'));assert.ok(code.includes('<dd>£90 / session</dd>'));
 let copied,button;const root={dataset:{},querySelector(selector){if(selector==='[data-copy-email]')return button={addEventListener(event,fn){this.click=fn;}};return {};}};
 vm.runInNewContext(inlineScript(code),{document:{getElementById(){return root;}},window:{isSecureContext:true,clearTimeout(){},setTimeout(){}},navigator:{clipboard:{async writeText(text){copied=text;}}}});
 await button.click();assert.equal(copied,values.privateEmail);
});
test('semantic enrichment removes conflicting generic controls without touching originals',async()=>{
 const original=await component('apex-uniform-1');const start=original.originalCode.indexOf('AGC147');
 const generic={...original,fields:[{id:'oldCode',type:'text',defaultValue:'AGC147'}],bindings:[{fieldId:'oldCode',start,end:start+6,original:'AGC147',encoding:'html-text'}]};
 const enriched=enrichTemplate(generic);validateTemplate(enriched);assert.ok(!enriched.fields.some(field=>field.id==='oldCode'));assert.equal(generateWebsiteCode(enriched),original.originalCode);
});
