import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import { REGULAR_TIMETABLES, migrateRegularTimetable } from '../dist/timetables.js';
import { TERM_DEFAULTS_VERSION, TERM_PRESETS, TERM_WEEKLY_RATES, TERM_OFFER_MEMBERSHIP_PENCE, applyTermDefaults, calculatePresetCardFee, getTermFeeHint } from '../dist/term-defaults.js';
import { buildStandalone } from '../scripts/build-standalone.mjs';
const clubIds=['swl','fulham','apex','apexdance'];
const emptyDraft=(club,mode='renewal')=>migrateRegularTimetable(club,mode,{});
function independentlyCountDates(preset,weekday){
  const matches=[];
  for(let day=Date.parse(preset.startDate+'T00:00:00Z');day<=Date.parse(preset.endDate+'T00:00:00Z');day+=86400000){
    const date=new Date(day),iso=date.toISOString().slice(0,10);
    if(date.getUTCDay()===weekday&&!preset.excludedDates.includes(iso))matches.push(iso);
  }
  return matches;
}

test('Spring2027 presets independently count the owner-confirmed dates and half-term breaks',()=>{
  const expectations={swl:{start:'2027-01-04',end:'2027-03-21',count:11,excluded:[]},fulham:{start:'2027-01-11',end:'2027-03-21',count:9,excluded:['2027-02-15']},apex:{start:'2027-01-07',end:'2027-03-18',count:10,excluded:['2027-02-18']},apexdance:{start:'2027-01-08',end:'2027-03-20',count:10,excluded:['2027-02-19','2027-02-20']}};
  for(const club of clubIds){const preset=TERM_PRESETS[club],expected=expectations[club];assert.equal(preset.startDate,expected.start);assert.equal(preset.endDate,expected.end);assert.deepEqual(preset.excludedDates,expected.excluded);
    for(const spec of REGULAR_TIMETABLES[club])for(const session of spec.sessions)assert.equal(independentlyCountDates(preset,session.weekday).length,expected.count,club+' '+spec.name);
  }
});

test('new advanced drafts get dates and term label without inventing a deadline or payment link',()=>{
  for(const club of clubIds)for(const mode of ['renewal','offer']){
    const result=applyTermDefaults(club,mode,{});
    assert.equal(result.campaign.termName,'Spring 2027');assert.equal(result.termChoice,'Spring');assert.equal(result.campaign.startDate,TERM_PRESETS[club].startDate);assert.deepEqual(result.excludedDates,TERM_PRESETS[club].excludedDates);
    assert.ok(!result.campaign.deadline);assert.equal(result.termDefaults.version,TERM_DEFAULTS_VERSION);
    assert.equal(result.cards.length,REGULAR_TIMETABLES[club].length);assert.ok(result.cards.every(card=>!card.paymentUrl));
  }
});

test('Dance published session rates produce £140/£160/£160 for both modes and each alternative weekly group',()=>{
  for(const mode of ['renewal','offer']){
    const draft=applyTermDefaults('apexdance',mode,{});
    assert.deepEqual(draft.cards.map(card=>card.fee),['140.00','160.00','160.00']);
    for(const card of draft.cards){const price=calculatePresetCardFee('apexdance',mode,card);assert.equal(price.units,10);assert.equal(price.membershipPence,0);assert.equal(price.tuitionPence,Number(card.fee)*100);}
  }
});

test('every regular class has a sourced rate, with website estimates distinguished from owner confirmations',()=>{
  for(const club of clubIds)for(const spec of REGULAR_TIMETABLES[club]){
    const rate=TERM_WEEKLY_RATES[club][spec.key];assert.ok(rate && Number.isInteger(rate.pence) && rate.pence>0);assert.ok(rate.source);
    assert.equal(rate.sourceKind,club==='swl'?'website-approximate':club==='apexdance'?'published':'user-confirmed');
    assert.equal(rate.basis,spec.combined?'programme-week':'session');
  }
});

test('matching Spring drafts receive only blank fees and preserve saved prices, links, notes and deadline',()=>{
  const original=emptyDraft('apexdance');Object.assign(original,{termChoice:'Spring',excludedDates:[...TERM_PRESETS.apexdance.excludedDates]});
  original.campaign={termName:'Spring 2027',startDate:TERM_PRESETS.apexdance.startDate,endDate:TERM_PRESETS.apexdance.endDate,deadline:'2026-12-15',body:'My text'};
  Object.assign(original.cards[0],{fee:'135',paymentUrl:'https://example.com/my-pay',feeNote:'My note',enabled:false});original.cards[1].fee='0';
  const before=JSON.stringify(original),result=applyTermDefaults('apexdance','renewal',original);
  assert.equal(JSON.stringify(original),before);assert.deepEqual(result.cards.map(card=>card.fee),['135','0','160.00']);
  for(const key of ['paymentUrl','feeNote','enabled'])assert.equal(result.cards[0][key],original.cards[0][key]);
  assert.equal(result.campaign.deadline,'2026-12-15');assert.equal(result.campaign.body,'My text');
});

test('other terms, custom date ranges, custom labels and exclusions are never silently replaced',()=>{
  const examples=[{termName:'Autumn 2026',startDate:'2026-09-01',endDate:'2026-12-20'}, {termName:'Spring 2027',startDate:'2027-01-15',endDate:'2027-03-20'}, {termName:'My custom camp',startDate:'2027-01-08',endDate:'2027-03-20'}, {termName:'Summer',startDate:'',endDate:''}];
  for(const campaign of examples){const draft={...emptyDraft('apexdance'),campaign};assert.deepEqual(applyTermDefaults('apexdance','renewal',draft),draft);}
  const customExclusions={...emptyDraft('apexdance'),campaign:{...TERM_PRESETS.apexdance},excludedDates:['2027-02-12']};
  assert.deepEqual(applyTermDefaults('apexdance','renewal',customExclusions),customExclusions);
  const basic={campaign:{body:'Basic'},cards:[]};assert.deepEqual(applyTermDefaults('swl','basic',basic,{force:true}),basic);
});

test('a saved marker protects later cleared fees or changed dates on reload',()=>{
  const initial=applyTermDefaults('apexdance','offer',{});
  initial.cards[0].fee='';initial.campaign.startDate='';initial.excludedDates=[];
  const roundTrip=JSON.parse(JSON.stringify(initial));assert.deepEqual(applyTermDefaults('apexdance','offer',roundTrip),roundTrip);
});

test('explicit loading refreshes dates and regular fees while retaining links, notes and custom cards',()=>{
  const draft=applyTermDefaults('apexdance','renewal',{});draft.campaign.startDate='2028-01-01';draft.campaign.deadline='2026-12-01';draft.excludedDates=['2028-01-15'];
  draft.cards[0].fee='999';draft.cards[0].paymentUrl='https://example.com/keep';draft.cards[0].feeNote='Keep my note';
  const custom={id:'custom',regularKey:'',name:'My private lesson',fee:'80',paymentUrl:'https://example.com/custom',sessions:[{weekday:2,startTime:'10:00',endTime:'11:00'}]};draft.cards.push(custom);
  draft.cards[1].sessions[0].startTime='18:00';draft.cards[1].fee='888';
  const forced=applyTermDefaults('apexdance','renewal',draft,{force:true});
  assert.equal(forced.campaign.startDate,'2027-01-08');assert.equal(forced.campaign.deadline,'2026-12-01');assert.deepEqual(forced.excludedDates,TERM_PRESETS.apexdance.excludedDates);
  assert.equal(forced.cards[0].fee,'140.00');assert.equal(forced.cards[0].paymentUrl,'https://example.com/keep');assert.equal(forced.cards[0].feeNote,'Keep my note');assert.equal(forced.cards[1].fee,'888');assert.deepEqual(forced.cards.at(-1),custom);
});

test('bundled offline app exposes identical term presets and migration behavior',async()=>{
  const {engineSource}=await buildStandalone();const context=vm.createContext({URL});vm.runInContext(engineSource+'\nglobalThis.termApi={TERM_PRESETS,applyTermDefaults,getTermFeeHint};',context);
  assert.deepEqual(JSON.parse(JSON.stringify(context.termApi.TERM_PRESETS)),TERM_PRESETS);
  for(const club of clubIds)for(const mode of ['renewal','offer'])assert.deepEqual(JSON.parse(JSON.stringify(context.termApi.applyTermDefaults(club,mode,{}))),applyTermDefaults(club,mode,{}));
});

test('approved SWL approximate rates produce tuition plus one Offer-only £40 charge',()=>{
  const tuition={beginners:220,intermediate:253,advanced:286,junioradvanced:286,juniorsquad:352,floorvault:396,seniorelite:803};
  for(const mode of ['renewal','offer']){
    const draft=applyTermDefaults('swl',mode,{});
    for(const card of draft.cards){
      const key=card.regularKey.split(':')[1],price=calculatePresetCardFee('swl',mode,card);
      assert.equal(Number(card.fee),tuition[key]+(mode==='offer'?40:0));assert.equal(price.membershipPence,mode==='offer'?4000:0);assert.equal(price.units,11);
      assert.equal(TERM_WEEKLY_RATES.swl[key].sourceKind,'website-approximate');
    }
    const elite=draft.cards.find(card=>card.regularKey==='swl:seniorelite');
    assert.equal(elite.sessions.length,2);assert.equal(calculatePresetCardFee('swl',mode,elite).tuitionPence,80300,'Wednesday + Saturday is one weekly programme, not two payments');
    assert.match(getTermFeeHint('swl',mode),/approximate weekly rates/);
  }
  assert.match(getTermFeeHint('swl','offer'),/plus £40 annual IGA/);
  assert.match(getTermFeeHint('swl','renewal'),/No extra annual membership/);
});

test('Apex owner-confirmed £15/£17/£20/£34 rates fill the correct ten-class fees',()=>{
  for(const mode of ['renewal','offer']){
    const draft=applyTermDefaults('apex',mode,{});
    const feeByKey=Object.fromEntries(draft.cards.map(card=>[card.regularKey.split(':')[1],card.fee]));
    assert.equal(feeByKey.beginners,'150.00');assert.equal(feeByKey.intermediate,'170.00');assert.equal(feeByKey.advanced,'200.00');
    assert.equal(feeByKey.twohouradvanced,'340.00','two-hour rate is explicitly £17 × 2, while one-hour Advanced stays £20');
    assert.equal(TERM_WEEKLY_RATES.apex.advanced.sourceKind,'user-confirmed');
    for(const card of draft.cards){const price=calculatePresetCardFee('apex',mode,card);if(price)assert.equal(price.membershipPence,0);}
  }
});

test('Fulham owner-confirmed tuition is £180/£207/£234 for nine Monday classes',()=>{
  const renewal=applyTermDefaults('fulham','renewal',{});
  assert.deepEqual(renewal.cards.map(card=>card.fee),['180.00','207.00','234.00']);
  for(const card of renewal.cards){const price=calculatePresetCardFee('fulham','renewal',card);assert.equal(price.units,9);assert.equal(price.membershipPence,0);}
  for(const rate of Object.values(TERM_WEEKLY_RATES.fulham))assert.equal(rate.sourceKind,'user-confirmed');
  const offer=applyTermDefaults('fulham','offer',{});
  assert.equal(TERM_OFFER_MEMBERSHIP_PENCE.fulham,4000);
  assert.deepEqual(offer.cards.map(card=>card.fee),['220.00','247.00','274.00']);
  assert.match(getTermFeeHint('fulham','offer'),/includes £40 annual IGA/);
  assert.match(getTermFeeHint('fulham','renewal'),/No extra annual membership/);
});
