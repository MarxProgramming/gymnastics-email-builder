import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import { readFile } from 'node:fs/promises';
import { REGULAR_TIMETABLES, migrateRegularTimetable } from '../dist/timetables.js';
import { TERM_DEFAULTS_VERSION, TERM_PRESETS, TERM_WEEKLY_RATES, TERM_OFFER_MEMBERSHIP_PENCE, TERM_PAYMENT_LINKS_VERSION, SPRING_RENEWAL_PAYMENT_LINKS, hasRenewalPaymentLinks, validateKnownPaymentAmounts, applyTermDefaults, calculatePresetCardFee, getTermFeeHint } from '../dist/term-defaults.js';
import { buildStandalone } from '../scripts/build-standalone.mjs';
const clubIds=['swl','fulham','apex','apexdance'];
const emptyDraft=(club,mode='renewal')=>migrateRegularTimetable(club,mode,{});
function independentlyCountDates(preset,weekday){
  const matches=[];
  for(let day=Date.parse(preset.startDate+'T00:00:00Z');day<=Date.parse(preset.endDate+'T00:00:00Z');day+=86400000){
    const date=new Date(day),iso=date.toISOString().slice(0,10);
    if(date.getUTCDay()===weekday&&!preset.excludedDates.includes(iso))matches.push(iso);
  }
  return matches;
}

test('Spring2027 presets independently count the owner-confirmed dates and half-term breaks',()=>{
  const expectations={swl:{start:'2027-01-04',end:'2027-03-21',count:11,excluded:[]},fulham:{start:'2027-01-11',end:'2027-03-21',count:9,excluded:['2027-02-15']},apex:{start:'2027-01-07',end:'2027-03-18',count:10,excluded:['2027-02-18']},apexdance:{start:'2027-01-08',end:'2027-03-20',count:10,excluded:['2027-02-19','2027-02-20']}};
  for(const club of clubIds){const preset=TERM_PRESETS[club],expected=expectations[club];assert.equal(preset.startDate,expected.start);assert.equal(preset.endDate,expected.end);assert.deepEqual(preset.excludedDates,expected.excluded);
    for(const spec of REGULAR_TIMETABLES[club])for(const session of spec.sessions)assert.equal(independentlyCountDates(preset,session.weekday).length,expected.count,club+' '+spec.name);
  }
});

test('new advanced drafts get dates and term label, with verified links only in the approved payment contexts',()=>{
  for(const club of clubIds)for(const mode of ['renewal','offer']){
    const result=applyTermDefaults(club,mode,{});
    assert.equal(result.campaign.termName,'Spring 2027');assert.equal(result.termChoice,'Spring');assert.equal(result.campaign.startDate,TERM_PRESETS[club].startDate);assert.deepEqual(result.excludedDates,TERM_PRESETS[club].excludedDates);
    assert.ok(!result.campaign.deadline);assert.equal(result.termDefaults.version,TERM_DEFAULTS_VERSION);
    const hasLinks=hasRenewalPaymentLinks(club,mode)||(club==='swl'&&mode==='offer');assert.equal(result.cards.length,REGULAR_TIMETABLES[club].length);assert.equal(result.cards.every(card=>Boolean(card.paymentUrl)),hasLinks);if(!hasLinks)assert.ok(result.cards.every(card=>!card.paymentUrl));
  }
});

test('Dance published session rates produce £140/£160/£160 for both modes and each alternative weekly group',()=>{
  for(const mode of ['renewal','offer']){
    const draft=applyTermDefaults('apexdance',mode,{});
    assert.deepEqual(draft.cards.map(card=>card.fee),['140.00','160.00','160.00']);
    for(const card of draft.cards){const price=calculatePresetCardFee('apexdance',mode,card);assert.equal(price.units,10);assert.equal(price.membershipPence,0);assert.equal(price.tuitionPence,Number(card.fee)*100);}
  }
});

test('every regular class has a sourced rate, with website estimates distinguished from owner confirmations',()=>{
  for(const club of clubIds)for(const spec of REGULAR_TIMETABLES[club]){
    const rate=TERM_WEEKLY_RATES[club][spec.key];assert.ok(rate && Number.isInteger(rate.pence) && rate.pence>0);assert.ok(rate.source);
    assert.equal(rate.sourceKind,club==='swl'?'website-approximate':club==='apexdance'?'published':'user-confirmed');
    assert.equal(rate.basis,spec.combined?'programme-week':'session');
  }
});

test('matching Spring drafts receive only blank fees and preserve saved prices, links, notes and deadline',()=>{
  const original=emptyDraft('apexdance');Object.assign(original,{termChoice:'Spring',excludedDates:[...TERM_PRESETS.apexdance.excludedDates]});
  original.campaign={termName:'Spring 2027',startDate:TERM_PRESETS.apexdance.startDate,endDate:TERM_PRESETS.apexdance.endDate,deadline:'2026-12-15',body:'My text'};
  Object.assign(original.cards[0],{fee:'135',paymentUrl:'https://example.com/my-pay',feeNote:'My note',enabled:false});original.cards[1].fee='0';
  const before=JSON.stringify(original),result=applyTermDefaults('apexdance','renewal',original);
  assert.equal(JSON.stringify(original),before);assert.deepEqual(result.cards.map(card=>card.fee),['135','0','160.00']);
  for(const key of ['paymentUrl','feeNote','enabled'])assert.equal(result.cards[0][key],original.cards[0][key]);
  assert.equal(result.campaign.deadline,'2026-12-15');assert.equal(result.campaign.body,'My text');
});

test('other terms, custom date ranges, custom labels and exclusions are never silently replaced',()=>{
  const examples=[{termName:'Autumn 2026',startDate:'2026-09-01',endDate:'2026-12-20'}, {termName:'Spring 2027',startDate:'2027-01-15',endDate:'2027-03-20'}, {termName:'My custom camp',startDate:'2027-01-08',endDate:'2027-03-20'}, {termName:'Summer',startDate:'',endDate:''}];
  for(const campaign of examples){const draft={...emptyDraft('apexdance'),campaign};assert.deepEqual(applyTermDefaults('apexdance','renewal',draft),draft);}
  const customExclusions={...emptyDraft('apexdance'),campaign:{...TERM_PRESETS.apexdance},excludedDates:['2027-02-12']};
  assert.deepEqual(applyTermDefaults('apexdance','renewal',customExclusions),customExclusions);
  const basic={campaign:{body:'Basic'},cards:[]};assert.deepEqual(applyTermDefaults('swl','basic',basic,{force:true}),basic);
});

test('a saved marker protects later cleared fees or changed dates on reload',()=>{
  const initial=applyTermDefaults('apexdance','offer',{});
  initial.cards[0].fee='';initial.campaign.startDate='';initial.excludedDates=[];
  const roundTrip=JSON.parse(JSON.stringify(initial));assert.deepEqual(applyTermDefaults('apexdance','offer',roundTrip),roundTrip);
});

test('explicit loading refreshes dates, regular fees and verified links while retaining notes and custom cards',()=>{
  const draft=applyTermDefaults('apexdance','renewal',{});draft.campaign.startDate='2028-01-01';draft.campaign.deadline='2026-12-01';draft.excludedDates=['2028-01-15'];
  draft.cards[0].fee='999';draft.cards[0].paymentUrl='https://example.com/keep';draft.cards[0].feeNote='Keep my note';
  const custom={id:'custom',regularKey:'',name:'My private lesson',fee:'80',paymentUrl:'https://example.com/custom',sessions:[{weekday:2,startTime:'10:00',endTime:'11:00'}]};draft.cards.push(custom);
  draft.cards[1].sessions[0].startTime='18:00';draft.cards[1].fee='888';
  const forced=applyTermDefaults('apexdance','renewal',draft,{force:true});
  assert.equal(forced.campaign.startDate,'2027-01-08');assert.equal(forced.campaign.deadline,'2026-12-01');assert.deepEqual(forced.excludedDates,TERM_PRESETS.apexdance.excludedDates);
  assert.equal(forced.cards[0].fee,'140.00');assert.equal(forced.cards[0].paymentUrl,SPRING_RENEWAL_PAYMENT_LINKS.apexdance.junioracro.url);assert.equal(forced.cards[0].feeNote,'Keep my note');assert.equal(forced.cards[1].fee,'888');assert.deepEqual(forced.cards.at(-1),custom);
});

test('bundled offline app exposes identical term presets and migration behavior',async()=>{
  const {engineSource}=await buildStandalone();const context=vm.createContext({URL});vm.runInContext(engineSource+'\nglobalThis.termApi={TERM_PRESETS,applyTermDefaults,getTermFeeHint};',context);
  assert.deepEqual(JSON.parse(JSON.stringify(context.termApi.TERM_PRESETS)),TERM_PRESETS);
  for(const club of clubIds)for(const mode of ['renewal','offer'])assert.deepEqual(JSON.parse(JSON.stringify(context.termApi.applyTermDefaults(club,mode,{}))),applyTermDefaults(club,mode,{}));
});

test('approved SWL approximate rates produce tuition plus one Offer-only £40 charge',()=>{
  const tuition={beginners:220,intermediate:253,advanced:286,junioradvanced:286,juniorsquad:352,floorvault:396,seniorelite:803};
  for(const mode of ['renewal','offer']){
    const draft=applyTermDefaults('swl',mode,{});
    for(const card of draft.cards){
      const key=card.regularKey.split(':')[1],price=calculatePresetCardFee('swl',mode,card);
      assert.equal(Number(card.fee),tuition[key]+(mode==='offer'?40:0));assert.equal(price.membershipPence,mode==='offer'?4000:0);assert.equal(price.units,11);
      assert.equal(TERM_WEEKLY_RATES.swl[key].sourceKind,'website-approximate');
    }
    const elite=draft.cards.find(card=>card.regularKey==='swl:seniorelite');
    assert.equal(elite.sessions.length,2);assert.equal(calculatePresetCardFee('swl',mode,elite).tuitionPence,80300,'Wednesday + Saturday is one weekly programme, not two payments');
    assert.match(getTermFeeHint('swl',mode),/approximate weekly rates/);
  }
  assert.match(getTermFeeHint('swl','offer'),/plus £40 annual IGA/);
  assert.match(getTermFeeHint('swl','renewal'),/No extra annual membership/);
});

test('Apex owner-confirmed £15/£17/£20/£34 rates fill the correct ten-class fees',()=>{
  for(const mode of ['renewal','offer']){
    const draft=applyTermDefaults('apex',mode,{});
    const feeByKey=Object.fromEntries(draft.cards.map(card=>[card.regularKey.split(':')[1],card.fee]));
    assert.equal(feeByKey.beginners,'150.00');assert.equal(feeByKey.intermediate,'170.00');assert.equal(feeByKey.advanced,'200.00');
    assert.equal(feeByKey.twohouradvanced,'340.00','two-hour rate is explicitly £17 × 2, while one-hour Advanced stays £20');
    assert.equal(TERM_WEEKLY_RATES.apex.advanced.sourceKind,'user-confirmed');
    for(const card of draft.cards){const price=calculatePresetCardFee('apex',mode,card);if(price)assert.equal(price.membershipPence,0);}
  }
});

test('Fulham owner-confirmed tuition is £180/£207/£234 for nine Monday classes',()=>{
  const renewal=applyTermDefaults('fulham','renewal',{});
  assert.deepEqual(renewal.cards.map(card=>card.fee),['180.00','207.00','234.00']);
  for(const card of renewal.cards){const price=calculatePresetCardFee('fulham','renewal',card);assert.equal(price.units,9);assert.equal(price.membershipPence,0);}
  for(const rate of Object.values(TERM_WEEKLY_RATES.fulham))assert.equal(rate.sourceKind,'user-confirmed');
  const offer=applyTermDefaults('fulham','offer',{});
  assert.equal(TERM_OFFER_MEMBERSHIP_PENCE.fulham,4000);
  assert.deepEqual(offer.cards.map(card=>card.fee),['220.00','247.00','274.00']);
  assert.match(getTermFeeHint('fulham','offer'),/includes £40 annual IGA/);
  assert.match(getTermFeeHint('fulham','renewal'),/No extra annual membership/);
});

const verifiedPaymentFixtures = [
  ['swl','beginners','hlc2GxQ6',22000],['swl','intermediate','4hBq2qKF',25300],['swl','advanced','OjQcUm8a',28600],['swl','junioradvanced','ceYS5tXJ',28600],['swl','juniorsquad','0MsWda5J',35200],['swl','floorvault','EK8lYpJ0',39600],['swl','seniorelite','f2AfMH27',80300],
  ['apex','beginners','r1CZo5tX',15000],['apex','intermediate','VK3qHhqp',17000],['apex','advanced','KyPDuqUs',20000],['apex','twohouradvanced','9ZyYMtkg',34000],
  ['apexdance','junioracro','5z4aQHz7',14000],['apexdance','intermediateacro','4fy0bAWe',16000],['apexdance','advancedacro','v3kQiVko',16000]
];
function oldPresetDraft(club) {
  const draft=applyTermDefaults(club,'renewal',{});
  delete draft.termDefaults.paymentLinksVersion;
  draft.cards=draft.cards.map(card=>({...card,paymentUrl:''}));
  return draft;
}

test('all 14 verified fixed-price links map to the correct renewal class, title and amount',()=>{
  assert.equal(Object.values(SPRING_RENEWAL_PAYMENT_LINKS).flatMap(Object.values).length,14);
  assert.equal(new Set(verifiedPaymentFixtures.map(row=>row[2])).size,14);
  for(const [club,key,slug,amount] of verifiedPaymentFixtures){
    const payment=SPRING_RENEWAL_PAYMENT_LINKS[club][key],spec=REGULAR_TIMETABLES[club].find(item=>item.key===key);
    assert.equal(payment.url,'https://square.link/u/'+slug);assert.equal(payment.amountPence,amount);
    assert.ok(payment.title.includes(spec.name));assert.match(payment.title,/Spring 2027 Renewal/);
    const card=applyTermDefaults(club,'renewal',{}).cards.find(item=>item.regularKey===club+':'+key);
    assert.equal(card.paymentUrl,payment.url);assert.equal(Number(card.fee)*100,amount);
  }
  for(const club of clubIds){assert.equal(hasRenewalPaymentLinks(club,'renewal'),club!=='fulham');for(const mode of ['basic','offer'])assert.equal(hasRenewalPaymentLinks(club,mode),false);}
});

test('saved v1 Spring drafts gain only blank matching links without repeating the date/fee migration',()=>{
  assert.equal(TERM_DEFAULTS_VERSION,1,'link backfill must not re-run the original fee defaults');
  for(const club of ['swl','apex','apexdance']){
    const original=oldPresetDraft(club);original.campaign.deadline='2026-12-12';original.cards[0].paymentUrl='https://example.com/custom-checkout';original.cards[1].fee='';original.cards[2].fee='0';
    original.cards.push({...original.cards[0],id:'ccustom',regularKey:'',name:'My special class',paymentUrl:''});
    const before=JSON.stringify(original),result=applyTermDefaults(club,'renewal',original);
    assert.equal(JSON.stringify(original),before);assert.equal(result.termDefaults.paymentLinksVersion,TERM_PAYMENT_LINKS_VERSION);assert.equal(result.campaign.deadline,original.campaign.deadline);
    assert.equal(result.cards[0].paymentUrl,original.cards[0].paymentUrl);assert.equal(result.cards[1].fee,'');assert.equal(result.cards[1].paymentUrl,'');assert.equal(result.cards[2].fee,'0');assert.equal(result.cards[2].paymentUrl,'');assert.equal(result.cards.at(-1).paymentUrl,'');
    for(let index=3;index<original.cards.length-1;index++){const card=result.cards[index];assert.equal(card.paymentUrl,SPRING_RENEWAL_PAYMENT_LINKS[club][card.regularKey.split(':')[1]].url);}
    assert.deepEqual(result.campaign,original.campaign);
  }
});

test('fixed-price checkout links are not attached to changed fees, names, timetables or term dates',()=>{
  for(const mutate of [card=>{card.fee='139';},card=>{card.fee='140.001';},card=>{card.fee='140x';},card=>{card.name='Custom Junior';},card=>{card.sessions[0].startTime='17:00';},card=>{card.combined=true;},card=>{card.regularKey='';}]){
    const draft=oldPresetDraft('apexdance');mutate(draft.cards[0]);assert.equal(applyTermDefaults('apexdance','renewal',draft).cards[0].paymentUrl,'');
  }
  for(const mutate of [draft=>{draft.campaign.startDate='2027-01-15';},draft=>{draft.campaign.endDate='2027-03-13';},draft=>{draft.excludedDates=['2027-02-12'];},draft=>{draft.campaign.termName='Spring 2028';},draft=>{draft.campaign.excludedRanges=[{startDate:'2027-02-01',endDate:'2027-02-07'}];}]){
    const draft=oldPresetDraft('apexdance');mutate(draft);assert.deepEqual(applyTermDefaults('apexdance','renewal',draft),draft);
  }
});

test('after one-time backfill, deliberately cleared links stay cleared until explicit Load restores the verified pair',()=>{
  const migrated=applyTermDefaults('apexdance','renewal',oldPresetDraft('apexdance'));
  migrated.cards[0].paymentUrl='';migrated.cards[0].fee='135';
  const again=applyTermDefaults('apexdance','renewal',JSON.parse(JSON.stringify(migrated)));
  assert.equal(again.cards[0].paymentUrl,'');assert.equal(again.cards[0].fee,'135');
  const forced=applyTermDefaults('apexdance','renewal',again,{force:true});
  assert.equal(forced.cards[0].paymentUrl,SPRING_RENEWAL_PAYMENT_LINKS.apexdance.junioracro.url);assert.equal(forced.cards[0].fee,'140.00');
});

test('explicit Load preserves existing links outside the verified payment contexts',()=>{
  for(const club of clubIds)for(const mode of ['offer','renewal']){
    if(hasRenewalPaymentLinks(club,mode)||(club==='swl'&&mode==='offer'))continue;
    const old=applyTermDefaults(club,mode,{});old.cards[0].paymentUrl='https://example.com/keep';
    const forced=applyTermDefaults(club,mode,old,{force:true});assert.equal(forced.cards[0].paymentUrl,'https://example.com/keep');assert.ok(forced.cards.slice(1).every(card=>!card.paymentUrl));
  }
  const basic={campaign:{body:'Basic'},cards:[{paymentUrl:'https://example.com/basic'}]};assert.deepEqual(applyTermDefaults('swl','basic',basic,{force:true}),basic);
});

test('preview and generated standalone scripts use each selected class’s verified checkout and exact price',async()=>{
  globalThis.fetch=async url=>new Response(await readFile(url,'utf8'));
  const {generateScript,renderPreview,CLUBS}=await import('../dist/engine.js');
  const prefixes={swl:'Swl',apex:'Apex',apexdance:'ApexDance'};
  for(const clubId of ['swl','apex','apexdance']){
    const draft=applyTermDefaults(clubId,'renewal',{});
    const classes=draft.cards.map(card=>({id:card.id,name:card.name,fee:card.fee,paymentUrl:card.paymentUrl,sessions:card.combined?card.sessions:[card.sessions[0]]}));
    const options={mode:'renewal',subject:'{{term}} renewal',body:'Class details for {{child}}.',campaign:{...draft.campaign,deadline:'2026-12-15',classes}};
    const source=await generateScript(clubId,options),context=vm.createContext({});vm.runInContext(source,context);
    const club=CLUBS.find(item=>item.id===clubId),b64=source.match(new RegExp(`const ${clubId.toUpperCase()}_LOGO_BASE64 = ["']([^"']+)`))[1];
    for(let index=0;index<classes.length;index++){
      const cls=classes[index];vm.runInContext('selectedCampaignClass_=EMAIL_CAMPAIGN.campaign.classes.find(cls=>cls.id==='+JSON.stringify(cls.id)+')',context);
      const actual=context['build'+prefixes[clubId]+'Email_']('Pat','Alex');
      const preview=await renderPreview(clubId,{...options,previewClassId:cls.id},{parent:'Pat',child:'Alex'});
      assert.equal(preview,actual.htmlBody.replace('cid:'+clubId+'Logo','data:'+club.logoMime+';base64,'+b64));
      assert.ok(actual.htmlBody.includes('href="'+cls.paymentUrl+'"'));assert.ok(actual.plainBody.includes(cls.paymentUrl));assert.ok(actual.plainBody.includes('£'+cls.fee));
      for(const other of classes)if(other.id!==cls.id)assert.ok(!actual.plainBody.includes(other.paymentUrl));
    }
  }
});

test('known fixed checkout links reject edited amounts, including tracked URL variants, without rewriting anything',()=>{
  for(const [club,key,slug,amount] of verifiedPaymentFixtures){
    const payment=SPRING_RENEWAL_PAYMENT_LINKS[club][key];
    for(const suffix of ['', '/', '?ref=email', '#payment']){
      const campaign={classes:[{name:key,fee:(amount/100-1).toFixed(2),paymentUrl:payment.url+suffix}]},before=JSON.stringify(campaign);
      assert.throws(()=>validateKnownPaymentAmounts(campaign),error=>error.message.includes('charges £'+(amount/100).toFixed(2))&&error.message.includes('or use a payment link'));
      assert.equal(JSON.stringify(campaign),before);
      campaign.classes[0].fee=(amount/100).toFixed(2);assert.equal(validateKnownPaymentAmounts(campaign),campaign);
    }
  }
  const custom={classes:[{name:'My rate',fee:'210',paymentUrl:'https://example.com/my-checkout'}]};assert.equal(validateKnownPaymentAmounts(custom),custom);
});

test('preview, generated script and offline app all block a known checkout amount mismatch',async()=>{
  globalThis.fetch=async url=>new Response(await readFile(url,'utf8'));
  const {generateScript,renderPreview}=await import('../dist/engine.js');
  const draft=applyTermDefaults('swl','renewal',{}),card=draft.cards[0];
  const options={mode:'renewal',subject:'Spring renewal',body:'Details for {{child}}.',campaign:{...draft.campaign,deadline:'2026-12-15',classes:[{id:card.id,name:card.name,fee:'210',paymentUrl:card.paymentUrl,sessions:[card.sessions[0]]}]}};
  const expected=/charges £220\.00.*or use a payment link/;
  await assert.rejects(()=>renderPreview('swl',options),expected);await assert.rejects(()=>generateScript('swl',options),expected);
  const {engineSource}=await buildStandalone();const context=vm.createContext({URL});vm.runInContext(engineSource+'\nglobalThis.engineApi={generateScript,renderPreview};',context);
  await assert.rejects(()=>context.engineApi.renderPreview('swl',options),expected);await assert.rejects(()=>context.engineApi.generateScript('swl',options),expected);
  options.campaign.classes[0].paymentUrl='https://example.com/custom';assert.ok((await renderPreview('swl',options)).includes('£210.00'));assert.ok(await generateScript('swl',options));
});
