import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { createDefaultClubSettings, validateClubSettings, applyClubSettingsToEmailDraft, createManagementStore, parseConfigurationBackup } from '../dist/management-store.js';
import { validateCampaign } from '../dist/campaigns.js';
import { getClubInfoDefaults } from '../dist/club-info.js';
globalThis.fetch = async url => new Response(await readFile(url,'utf8'));
const {renderPreview,generateScript}=await import('../dist/engine.js');
const bank={bankAccountName:'Test & <Club>',bankSortCode:'00-00-00',bankAccountNumber:'00000000',bankReference:'{{child}} {{class}}'};
const campaign={...bank,termName:'Spring 2028',startDate:'2028-01-03',endDate:'2028-01-30',deadline:'2027-12-15',classes:[{id:'test',name:'Beginners',fee:100,paymentUrl:'https://example.com/pay',sessions:[{weekday:1,startTime:'17:00',endTime:'18:00'}]}]};
for(const club of ['swl','fulham','apex','apexdance'])for(const variant of ['main','reminder'])test(`${club} ${variant}: concise renewal, correct online/BACS option and cash`,async()=>{
 const options={mode:'renewal',renewalVariant:variant,subject:'Renew {{child}}',body:'Time to renew.',campaign:{...getClubInfoDefaults(club,'renewal'),...campaign}};
 const html=await renderPreview(club,options,{child:'Alex',parent:'Pat'});
 for(const text of ['How to renew','Option 2 — Pay cash','before the end of the current term','first day of the new term','reply to this email','Head Coach','color:#b91c1c'])assert.ok(html.includes(text),text);
 for(const text of ['Payment &amp; cancellation policy','What to wear','Read club rules','Location','View leotards','Suggested dancewear'])assert.ok(!html.includes(text),text);
 assert.equal(html.includes('https://example.com/pay'),club!=='fulham');
 if(club==='fulham'){assert.ok(html.includes('Test &amp; &lt;Club&gt;'));assert.ok(html.includes('00000000'));assert.ok(html.includes('Alex Beginners'));assert.ok(html.includes('let us know you have paid by BACS'));}
});
test('Fulham validates bank details instead of payment URLs, online clubs still require URLs',()=>{
 assert.equal(validateCampaign('renewal',{...campaign,classes:[{...campaign.classes[0],paymentUrl:''}]},'fulham').paymentMethod,'bacs');
 assert.throws(()=>validateCampaign('renewal',{...campaign,bankSortCode:'123'},'fulham'),/BACS/);
 assert.throws(()=>validateCampaign('renewal',{...campaign,bankAccountNumber:''},'fulham'),/BACS/);
 assert.throws(()=>validateCampaign('renewal',{...campaign,classes:[{...campaign.classes[0],paymentUrl:''}]},'swl'),/payment/);
 const clean=validateCampaign('renewal',{...campaign,policyUrl:'javascript:old',uniformUrl:'javascript:old',informationUrl:'javascript:old'},'swl');
 assert.equal(clean.policyUrl,'');assert.equal(clean.uniformUrl,'');
});
test('Offers retain policies and Apex British Gymnastics sign-up',async()=>{
 for(const club of ['swl','fulham','apex','apexdance']){
  const html=await renderPreview(club,{mode:'offer',subject:'Your place',body:'Welcome',campaign:{...getClubInfoDefaults(club,'offer'),...campaign}});
  assert.ok(html.includes('Payment &amp; cancellation policy'));assert.ok(html.includes('What to wear'));
  if(club==='apex'){assert.ok(html.includes('https://mybg.british-gymnastics.org/'));assert.ok(html.includes('does not already have current'));}
 }
});
test('Approved rates produce all Spring totals and add membership once',()=>{
 const expected={swl:[['beginners',20,220,260],['intermediate',23,253,293],['advanced',26,286,326],['junioradvanced',26,286,326],['juniorsquad',32,352,392],['floorvault',36,396,436],['seniorelite',73,803,843]],fulham:[['beginners',20,180,220],['intermediate',23,207,247],['advanced',26,234,274]],apex:[['beginners',15,150,150],['intermediate',17,170,170],['advanced',20,200,200],['twohouradvanced',34,340,340]],apexdance:[['junioracro',14,140,140],['intermediateacro',16,160,160],['advancedacro',16,160,160]]};
 for(const[club,rows]of Object.entries(expected)){
  const saved=createDefaultClubSettings(club);
  for(const[key,rate,fee,offer]of rows){const cls=saved.classes.find(c=>c.regularKey===club+':'+key);assert.ok(cls,key);assert.equal(Number(cls.weeklyRate),rate);assert.equal(Number(cls.fee),fee);assert.equal(Number(cls.newMemberFee),offer);}
  const draft=applyClubSettingsToEmailDraft({},saved,{clubId:club,mode:'offer',includeClasses:true});
  for(const cls of draft.cards){const original=saved.classes.find(c=>c.id===cls.id);assert.equal(cls.fee,original.newMemberFee);}
 }
});
test('Future dates, cancellation and edited rates recalculate, unequal class days split safely',()=>{
 let swl=createDefaultClubSettings('swl');swl.term={...swl.term,startDate:'2028-01-03',endDate:'2028-01-30',year:2028,excludedDates:['2028-01-10']};
 swl=validateClubSettings(swl,'swl');const beginners=swl.classes.find(c=>c.regularKey==='swl:beginners');assert.equal(beginners.fee,'');assert.match(beginners.priceIssue,/Different class days/);
 const draft=applyClubSettingsToEmailDraft({},swl,{clubId:'swl',includeClasses:true});const monday=draft.cards.find(c=>c.regularKey==='swl:beginners'&&c.sessions[0].weekday===1);assert.equal(monday.fee,'60.00');
 const senior=swl.classes.find(c=>c.regularKey==='swl:seniorelite');assert.equal(senior.fee,'292.00');assert.equal(senior.newMemberFee,'332.00');
 beginners.weeklyRate='21.50';const changed=validateClubSettings(swl,'swl');assert.ok(changed.classes.find(c=>c.id===beginners.id).priceGroups.some(g=>g.fee==='64.50'));
});
test('Saved rates, offer links and private BACS settings round-trip through backups',()=>{
 const store=createManagementStore();const fulham=store.getClubSettings('fulham');fulham.details={...fulham.details,...bank};fulham.classes[0].weeklyRate='22.50';store.saveClubSettings('fulham',fulham);
 const swl=store.getClubSettings('swl');swl.classes[0].offerPaymentUrl='https://example.com/join';store.saveClubSettings('swl',swl);
 const backup=parseConfigurationBackup(store.exportBackup());assert.equal(backup.management.clubs.fulham.details.bankAccountNumber,'00000000');assert.equal(backup.management.clubs.fulham.classes[0].weeklyRate,'22.50');assert.equal(backup.management.clubs.swl.classes[0].offerPaymentUrl,'https://example.com/join');
 const offer=applyClubSettingsToEmailDraft({},store.getClubSettings('fulham'),{clubId:'fulham',mode:'offer',includeClasses:true});assert.equal(offer.campaign.bankAccountName,bank.bankAccountName);assert.ok(offer.cards.every(c=>!c.paymentUrl));
});

test('Applying shared details to offers preserves BG sign-up and first-term policies',()=>{
 for(const club of ['swl','fulham','apex','apexdance']){
  const original={campaign:getClubInfoDefaults(club,'offer')};
  const applied=applyClubSettingsToEmailDraft(original,createDefaultClubSettings(club),{clubId:club,mode:'offer',includeClasses:true,includeDetails:true});
  for(const key of ['refundPolicy','membershipNote','membershipUrl','paymentInstructions']) assert.equal(applied.campaign[key],original.campaign[key]);
 }
});

test('SWL offers use seven separate verified membership-inclusive links',async()=>{
 const {applyTermDefaults,SPRING_OFFER_PAYMENT_LINKS,validateKnownPaymentAmounts}=await import('../dist/term-defaults.js');
 const draft=applyTermDefaults('swl','offer',{});assert.equal(draft.cards.length,7);
 for(const cls of draft.cards){const link=SPRING_OFFER_PAYMENT_LINKS.swl[cls.regularKey.split(':')[1]];assert.equal(cls.paymentUrl,link.url);assert.equal(Number(cls.fee)*100,link.amountPence);assert.doesNotThrow(()=>validateKnownPaymentAmounts({classes:[cls]}));assert.throws(()=>validateKnownPaymentAmounts({classes:[{...cls,fee:Number(cls.fee)-40}]}),/charges/);}
 const saved=createDefaultClubSettings('swl');assert.ok(saved.classes.every(cls=>cls.offerPaymentUrl));
 const applied=applyClubSettingsToEmailDraft({},saved,{clubId:'swl',mode:'offer',includeClasses:true});assert.deepEqual(applied.cards.map(cls=>cls.paymentUrl),draft.cards.map(cls=>cls.paymentUrl));
});
