import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import { WEBSITE_CATALOG } from '../dist/website-catalog.js';
import { getTemplateDefaults, generateWebsiteCode, applyCentralSettings } from '../dist/website-generator.js';
import { createDefaultClubSettings } from '../dist/management-store.js';
const dance = WEBSITE_CATALOG.find(template => template.id === 'apex-dance-timetable1-1');
const swl = WEBSITE_CATALOG.find(template => template.id === 'swl-classes-1');
const count = (source, text) => source.split(text).length - 1;

test('SWL and Dance preserve complete captured source at their original values', () => {
  for (const template of [swl, dance]) assert.equal(generateWebsiteCode(template, getTemplateDefaults(template)), template.originalCode);
});

test('Dance Advanced fee edits cannot change Intermediate prices that originally matched it', () => {
  const values = getTemplateDefaults(dance);
  values.fee_advancedacro = 197;
  values.weeklyFee_advancedacro = 19.7;
  const code = generateWebsiteCode(dance, values);
  assert.equal(count(code, 'class="price-val">£197'), 1);
  assert.equal(count(code, 'class="price-val">£240'), 2);
  assert.equal(count(code, 'class="price-session">£19.7 / session'), 1);
  assert.equal(count(code, 'class="price-session">£16 / session'), 2);
  assert.equal(count(code, 'class="price-val">£210'), 2);
});

test('Dance time controls update the card, overview and supporting sentence together', () => {
  const values = getTemplateDefaults(dance);
  values.time_friday_junioracro_start = '17:35';
  values.time_saturday_intermediateacro_start = '10:05';
  const code = generateWebsiteCode(dance, values);
  assert.equal(count(code, '5:35'), 3);
  assert.equal(count(code, '10:05'), 2);
  assert.match(code, /<div class="time-val">5:35 – 6:15<\/div>/);
  assert.match(code, /<strong>Intermediate Acro at 10:05 am<\/strong>/);
  assert.match(code, /Saturday 9:15–11:00 am/);
});

test('central Dance prices match class identity and retain independently reviewed weekly rates', () => {
  const settings = createDefaultClubSettings('apexdance');
  settings.classes.find(item => item.regularKey === 'apexdance:junioracro').fee = '141';
  settings.classes.find(item => item.regularKey === 'apexdance:intermediateacro').fee = '162';
  settings.classes.find(item => item.regularKey === 'apexdance:advancedacro').fee = '183';
  const applied = applyCentralSettings(dance, getTemplateDefaults(dance), settings);
  assert.equal(Number(applied.values.fee_junioracro), 141);
  assert.equal(Number(applied.values.fee_intermediateacro), 162);
  assert.equal(Number(applied.values.fee_advancedacro), 183);
  assert.equal(applied.values.weeklyFee_junioracro, 14);
  assert.equal(applied.values.weeklyFee_advancedacro, 16);
  const code = generateWebsiteCode(dance, applied.values);
  assert.equal(count(code, 'class="price-val">£141'), 2);
  assert.equal(count(code, 'class="price-val">£162'), 2);
  assert.equal(count(code, 'class="price-val">£183'), 1);
});

test('SWL keeps all thirty ordered sessions and both days of the combined Senior Elite programme', () => {
  const values = getTemplateDefaults(swl);
  assert.equal(values.weeklySchedule.length, 30);
  assert.deepEqual(values.weeklySchedule.filter(item => item.day === 'Monday').map(item => item.level), ['Beginners','Junior Squad','Intermediate','Junior Advanced Class','Advanced']);
  assert.deepEqual(values.weeklySchedule.filter(item => item.level === 'Senior Elite Squad').map(item => [item.day,item.time,item.tag]), [['Wednesday','17:00 – 20:15','Wed + Sat combined'],['Saturday','14:30 – 17:00','Wed + Sat combined']]);
  values.weeklySchedule[0].time = '17:05 - 17:50';
  const code = generateWebsiteCode(swl, values);
  assert.match(code, /17:05 – 17:50/);
  for (const script of code.matchAll(/<script\b[^>]*>([\s\S]*?)<\/script\s*>/gi)) new vm.Script(script[1]);
  values.weeklySchedule[0].time = '18:00 – 17:00';
  assert.throws(() => generateWebsiteCode(swl, values), /finish|end|after/i);
});
