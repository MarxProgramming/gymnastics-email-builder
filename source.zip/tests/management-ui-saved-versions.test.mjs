import test from 'node:test';
import assert from 'node:assert/strict';
import { prepareSavedWebsiteVersion } from '../dist/management-ui.js';
import * as generator from '../dist/website-generator.js';
const hash = 'a'.repeat(64);
const template = { id:'club-term-card', clubId:'swl', originalSha256:hash, originalCode:'<p>Spring 2027</p>', fields:[{id:'termTitle',label:'Term title',type:'text',defaultValue:'Spring 2027'}], bindings:[{fieldId:'termTitle',original:'Spring 2027',start:3,end:14,encoding:'html-text'}] };
const record = () => ({ id:'saved-1', clubId:'swl', templateId:template.id, name:'My term', sourceHash:hash, values:{termTitle:'Autumn 2027'} });

test('saved website versions load only against their original source and keep independent values', () => {
  const item = record(), prepared = prepareSavedWebsiteVersion(item, template, generator);
  assert.equal(prepared.values.termTitle, 'Autumn 2027');
  assert.equal(prepared.needsReview, false);
  prepared.values.termTitle = 'Edited';
  assert.equal(item.values.termTitle, 'Autumn 2027');
});

test('a changed source is rejected before old ordinal fields can be applied', () => {
  let generatorCalled = false;
  assert.throws(() => prepareSavedWebsiteVersion(record(), {...template,originalSha256:'b'.repeat(64)}, {generateWebsiteCode(){generatorCalled=true;}}), /original website component has changed/);
  assert.equal(generatorCalled,false);
});

test('unknown and invalid imported values produce clear load errors', () => {
  const unknown = record(); unknown.values.text_999 = 'Wrong source field';
  assert.throws(() => prepareSavedWebsiteVersion(unknown, template, generator), /Unknown editable field: text_999/);
  const invalid = record(); invalid.values.termTitle = {value:'not text'};
  assert.throws(() => prepareSavedWebsiteVersion(invalid, template, generator), /Term title: enter text/);
  assert.throws(() => prepareSavedWebsiteVersion(record(), null, generator), /component that is not in this app/);
});

test('older versions without source fingerprints remain available with an explicit review flag', () => {
  const item = record(); delete item.sourceHash;
  const prepared = prepareSavedWebsiteVersion(item,template,generator);
  assert.equal(prepared.needsReview,true);
  assert.equal(prepared.values.termTitle,'Autumn 2027');
});
