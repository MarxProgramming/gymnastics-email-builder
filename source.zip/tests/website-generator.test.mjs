import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import {readFile} from 'node:fs/promises';
import {validateTemplate,getTemplateDefaults,validateWebsiteValues,generateWebsiteCode,applyCentralSettings,buildPreviewDocument,validateWebsiteUrl} from '../dist/website-generator.js';
const original='<section id="example"><h2>Autumn term</h2>\n<a href="https://example.com/register">Register</a><p>£120.00</p>\n<script>const title = "Autumn term"; const open = true;</script></section>';
const template={id:'fixture',clubId:'swl',title:'Test only',originalCode:original,fields:[
 {id:'term',label:'Term name',defaultValue:'Autumn term',settingsPath:'term.termName'},
 {id:'link',type:'url',defaultValue:'https://example.com/register'},
 {id:'fee',type:'number',defaultValue:120,min:0,max:9999},
 {id:'open',type:'boolean',defaultValue:true}
],bindings:[
 {fieldId:'term',original:'Autumn term',before:'<h2>',after:'</h2>',encoding:'html-text'},
 {fieldId:'term',original:'"Autumn term"',before:'const title = ',encoding:'js-string'},
 {fieldId:'link',original:'https://example.com/register',encoding:'html-attribute'},
 {fieldId:'fee',original:'£120.00',encoding:'html-text',format:'money'},
 {fieldId:'open',original:'true',before:'const open = ',encoding:'boolean'}
]};

test('unchanged and normalized defaults preserve every original byte',()=>{
 assert.equal(generateWebsiteCode(template),original);
 assert.equal(generateWebsiteCode(template,getTemplateDefaults(template)),original);
 assert.equal(generateWebsiteCode(template,{fee:'120.00'}),original);
 const defaults=getTemplateDefaults(template);defaults.term='Changed';assert.equal(template.fields[0].defaultValue,'Autumn term');
});
test('edits replace only exact original targets, including duplicate display/JS bindings',()=>{
 const generated=generateWebsiteCode(template,{term:'Spring & summer',fee:'140.5',open:false});
 assert.equal(generated,original.replace('<h2>Autumn term</h2>','<h2>Spring &amp; summer</h2>').replace('"Autumn term"','"Spring \u0026 summer"'.replace('\\u0026','\\u0026')).replace('£120.00','£140.50').replace('open = true','open = false').replace('"Spring & summer"','"Spring \\u0026 summer"'));
 assert.ok(generated.includes('id="example"'));assert.ok(generated.includes('href="https://example.com/register"'));
});
test('HTML edits cannot introduce markup and attributes safely encode delimiters',()=>{
 const generated=generateWebsiteCode(template,{term:'<img src=x onerror="alert(1)">' });
 assert.ok(generated.includes('&lt;img src=x onerror=&quot;alert(1)&quot;&gt;'));assert.ok(!generated.includes('<img'));
 const attr={id:'attr',clubId:'swl',originalCode:'<div data-note="old"></div>',fields:[{id:'note',defaultValue:'old'}],bindings:[{fieldId:'note',original:'old',encoding:'html-attribute'}]};
 assert.equal(generateWebsiteCode(attr,{note:'x" onmouseover=alert(1) `'}),'<div data-note="x&quot;&#32;onmouseover&#61;alert(1)&#32;&#96;"></div>');
});
test('JavaScript string values round-trip without executing code or closing script tags',()=>{
 const value='Quotes \\ " \' ` ${evil()} </script> &\n\u2028\u2029';
 for(const quote of ['"',"'",'`']){
  const t={id:'string',clubId:'apex',originalCode:'const value = '+quote+'old'+quote+';',fields:[{id:'value',defaultValue:'old'}],bindings:[{fieldId:'value',original:quote+'old'+quote,encoding:'js-string',quote}]};
  const output=generateWebsiteCode(t,{value});assert.ok(!output.includes('</script>'));const context=vm.createContext({evil:()=>assert.fail('must stay literal')});vm.runInContext(output+'\nglobalThis.result=value;',context);assert.equal(context.result,value);
 }
});
test('ambiguous, absent, stale, overlapping and invalid occurrence targets refuse generation',()=>{
 const t={id:'bad',clubId:'swl',originalCode:'old old',fields:[{id:'text',defaultValue:'old'}],bindings:[{fieldId:'text',original:'old'}]};
 assert.throws(()=>generateWebsiteCode(t),/ambiguous/);
 assert.throws(()=>generateWebsiteCode({...t,bindings:[{fieldId:'text',original:'missing'}]}),/not found/);
 assert.throws(()=>generateWebsiteCode({...t,bindings:[{fieldId:'text',original:'old',start:1,end:4}]}),/no longer matches/);
 assert.throws(()=>generateWebsiteCode({...t,bindings:[{fieldId:'text',original:'old',occurrence:2}]}),/occurrence/);
 assert.throws(()=>generateWebsiteCode({...t,bindings:[{fieldId:'text',original:'old',start:0,end:3},{fieldId:'text',original:'old',occurrence:0}]}),/overlap/);
 assert.equal(generateWebsiteCode({...t,bindings:[{fieldId:'text',original:'old',occurrence:1}]},{text:'new'}),'old new');
});
test('bindings resolve before replacements so new text cannot redirect later edits',()=>{
 const t={id:'targets',clubId:'swl',originalCode:'A B',fields:[{id:'first',defaultValue:'A'},{id:'second',defaultValue:'B'}],bindings:[{fieldId:'first',original:'A'},{fieldId:'second',original:'B'}]};
 assert.equal(generateWebsiteCode(t,{first:'B',second:'C'}),'B C');
});
test('date, time, price, choices and unsafe links are validated without touching source',()=>{
 const fields=[{id:'date',type:'date',defaultValue:'2028-02-29'},{id:'time',type:'time',defaultValue:'17:30'},{id:'fee',type:'number',defaultValue:10,min:0,step:.5},{id:'choice',type:'select',defaultValue:'a',options:['a',{value:'b',label:'B'}]}];
 const t={id:'validation',clubId:'fulham',originalCode:'readonly',fields,bindings:[]};
 for(const values of [{date:'2027-02-29'},{time:'24:00'},{fee:-1},{fee:NaN},{fee:'   '},{fee:1.2},{choice:'c'}])assert.throws(()=>validateWebsiteValues(t,values));
 for(const link of ['javascript:alert(1)','data:text/html,bad','//example.com','https://user:pass@example.com','https://example.com/a b','https:\\example.com'])assert.throws(()=>validateWebsiteUrl(link));
 for(const link of ['https://example.com/x?a=1&b=2','/classes','#dates','mailto:club@example.com','tel:+442012345678'])assert.equal(validateWebsiteUrl(link),link);
});
test('source fields with no binding cannot silently discard user edits',()=>{
 const t={id:'readonly',clubId:'swl',originalCode:'Read only',fields:[{id:'x',defaultValue:'x'}],bindings:[]};assert.equal(generateWebsiteCode(t),'Read only');assert.throws(()=>generateWebsiteCode(t,{x:'y'}),/not connected/);
});
test('central settings are applied explicitly and report missing paths',()=>{
 const t={...template,fields:[...template.fields,{id:'missing',defaultValue:'keep',settingsPath:'term.unknown'}]};
 const result=applyCentralSettings(t,{fee:130},{term:{termName:'Spring 2027'}});
 assert.equal(result.values.term,'Spring 2027');assert.equal(result.values.fee,130);assert.deepEqual(result.applied,['term']);assert.deepEqual(result.missing,['missing']);assert.equal(generateWebsiteCode(t),original);
});
test('prototype keys and non-JSON configuration values are rejected',()=>{
 assert.throws(()=>validateWebsiteValues(template,JSON.parse('{"__proto__":{"x":1}}')),/Unknown editable/);
 assert.throws(()=>validateTemplate({...template,fields:[{id:'bad',defaultValue:JSON.parse('{"constructor":{"prototype":{"x":1}}}')}]}),/Unsupported configuration key/);
 assert.throws(()=>validateTemplate({...template,fields:[{id:'bad',defaultValue:'x',settingsPath:'term.__proto__.x'}]}),/safe central-settings/);
 assert.throws(()=>validateTemplate({...template,fields:[{id:'bad',defaultValue:()=>1}]}),/plain object/);
 assert.equal({}.x,undefined);
});
test('JSON-backed class rows retain metadata and safely serialize additions',()=>{
 const rows=[{id:'monday',name:'Beginners',fee:10,internal:'preserved'}];
 const t={id:'list',clubId:'apexdance',originalCode:'const classes = [{"id":"monday","name":"Beginners","fee":10,"internal":"preserved"}];',fields:[{id:'classes',type:'list',defaultValue:rows,itemFields:[{id:'name',defaultValue:'Beginners'},{id:'fee',type:'number',defaultValue:10,min:0}]}],bindings:[{fieldId:'classes',original:JSON.stringify(rows),encoding:'json'}]};
 assert.equal(generateWebsiteCode(t),t.originalCode);const changed=[{...rows[0],fee:15},{id:'friday',name:'</script>',fee:20}];const output=generateWebsiteCode(t,{classes:changed});assert.ok(!output.includes('</script>'));const context=vm.createContext({});vm.runInContext(output+'\nglobalThis.result=classes;',context);assert.equal(context.result.length,2);assert.equal(context.result[0].internal,'preserved');assert.equal(context.result[1].name,'</script>');
});
test('explicit repeated HTML rows support additions, removals and unique identity checks',()=>{
 const row='<li id="item-default"><b>Default</b></li>';
 const fields=[{id:'id',defaultValue:'default'},{id:'name',defaultValue:'Default'}];
 const rowBindings=[{fieldId:'id',original:'default',before:'id="item-',encoding:'html-attribute'},{fieldId:'name',original:'Default',before:'<b>',encoding:'html-text'}];
 const t={id:'repeat',clubId:'swl',originalCode:'<ul>'+row+'</ul>',fields:[{id:'rows',type:'list',defaultValue:[{id:'default',name:'Default'}],itemFields:fields}],bindings:[{fieldId:'rows',original:row,encoding:'repeat',rowTemplate:row,rowBindings,uniqueFields:['id']}]};
 assert.equal(generateWebsiteCode(t),t.originalCode);assert.equal(generateWebsiteCode(t,{rows:[{id:'a',name:'A'},{id:'b',name:'B & C'}]}),'<ul><li id="item-a"><b>A</b></li><li id="item-b"><b>B &amp; C</b></li></ul>');assert.equal(generateWebsiteCode(t,{rows:[]} ),'<ul></ul>');assert.throws(()=>generateWebsiteCode(t,{rows:[{id:'a',name:'A'},{id:'a',name:'B'}]}),/unique/);
});
test('date formatting and CSS values use constrained encodings',()=>{
 const t={id:'format',clubId:'swl',originalCode:'<p>29 February 2028</p><style>.x{color:#765091;gap:10px}</style>',fields:[{id:'date',type:'date',defaultValue:'2028-02-29'},{id:'color',defaultValue:'#765091'},{id:'gap',type:'number',defaultValue:10}],bindings:[{fieldId:'date',original:'29 February 2028',format:'date-long'},{fieldId:'color',original:'#765091',encoding:'css-color'},{fieldId:'gap',original:'10px',encoding:'css-number',unit:'px'}]};
 assert.match(generateWebsiteCode(t,{date:'2027-01-04',color:'#fff',gap:12}),/4 January 2027/);assert.throws(()=>generateWebsiteCode(t,{color:'red; background:url(https://x)'}),/hex colour/);
});
test('preview is isolated by default and interactive mode never grants parent, network scripts or forms',()=>{
 const code='<script>parent.document.body.innerHTML="no";fetch("https://example.com")</script><form action="https://example.com"></form>';
 const preview=buildPreviewDocument(code);assert.equal(preview.sandbox,'');assert.ok(preview.srcdoc.includes("script-src &#39;none&#39;"));assert.ok(preview.srcdoc.indexOf('Content-Security-Policy')<preview.srcdoc.indexOf(code));
 const active=buildPreviewDocument(code,{interactive:true,allowRemoteAssets:true,baseUrl:'https://example.com/'});assert.equal(active.sandbox,'allow-scripts');assert.ok(!active.sandbox.includes('allow-same-origin'));assert.ok(active.srcdoc.includes("connect-src &#39;none&#39;"));assert.ok(active.srcdoc.includes("form-action &#39;none&#39;"));assert.ok(active.srcdoc.includes("script-src &#39;unsafe-inline&#39;;"));assert.ok(active.srcdoc.includes('img-src data: blob: https:'));
 assert.throws(()=>buildPreviewDocument(code,{baseUrl:'javascript:alert(1)'}));
});
test('the pure engine also accepts plain data from another JavaScript realm',async()=>{
 const source=(await readFile(new URL('../dist/website-generator.js',import.meta.url),'utf8')).replace(/^export /gm,'');const context=vm.createContext({URL});vm.runInContext(source+'\nglobalThis.generate=generateWebsiteCode;',context);assert.equal(context.generate(template,{}),original);
});

import {WEBSITE_CATALOG} from '../dist/website-catalog.js';
import {createDefaultClubSettings} from '../dist/management-store.js';

test('catalog keeps all 28 captured components byte-for-byte when unchanged',()=>{
 assert.equal(WEBSITE_CATALOG.length,28);
 for(const template of WEBSITE_CATALOG){assert.equal(generateWebsiteCode(template),template.originalCode,template.id);assert.ok(template.fields.length>0,template.id);}
});

test('Spring central settings preserve structural IDs, selectors and valid scripts',()=>{
 const selectors=code=>[...code.matchAll(/(?:getElementById|querySelector|querySelectorAll)\(\s*(["'])(.*?)\1\s*\)/g)].map(m=>m[0]);
 const ids=code=>[...code.matchAll(/\bid\s*=\s*(["'])(.*?)\1/g)].map(m=>m[0]);
 for(const template of WEBSITE_CATALOG){
  const result=applyCentralSettings(template,{},createDefaultClubSettings(template.clubId));
  const generated=generateWebsiteCode(template,result.values);
  assert.deepEqual(selectors(generated),selectors(template.originalCode),template.id+' selectors');
  assert.deepEqual(ids(generated),ids(template.originalCode),template.id+' IDs');
  for(const script of generated.matchAll(/<script\b[^>]*>([\s\S]*?)<\/script\s*>/gi))assert.doesNotThrow(()=>new vm.Script(script[1]),template.id+' generated JavaScript');
  if(template.fields.some(f=>f.id==='termStart')){assert.match(generated,/2027/,template.id);assert.equal(result.missing.length,0,template.id+' missing shared settings');}
 }
});

test('website prices add membership only to SWL/Fulham all-in prices',()=>{
 const swl=WEBSITE_CATALOG.find(t=>t.id==='swl-classes-1'),values=applyCentralSettings(swl,{},createDefaultClubSettings('swl')).values;
 assert.equal(values.fee_beginners,260);assert.equal(values.fee_seniorelite,843);assert.equal(values.membershipFee,40);
 const fulham=WEBSITE_CATALOG.find(t=>t.id==='fulham-classes-1');assert.equal(applyCentralSettings(fulham,{},createDefaultClubSettings('fulham')).values.fee_beginners,220);
});

test('cancelled dates update both visible break notices and teaching week calculations',()=>{
 for(const id of ['apex-home-1','apex-timetable1-1']){
  const t=WEBSITE_CATALOG.find(t=>t.id===id),v=applyCentralSettings(t,{},createDefaultClubSettings('apex')).values;
  const output=generateWebsiteCode(t,v);assert.match(output,/No classes: 18 February 2027/);assert.doesNotMatch(output,/Classes continue through half term/);
  const b=t.bindings.find(b=>b.encoding==='teaching-week'),fixture={...t,id:'tracker-test',originalCode:b.original,bindings:[{...b,start:0,end:b.original.length}],fields:t.fields.filter(f=>['excludedDates','termStart','termEnd'].includes(f.id))};
  const expr=generateWebsiteCode(fixture,{excludedDates:v.excludedDates,termStart:v.termStart,termEnd:v.termEnd});
  assert.equal(vm.runInNewContext(expr,{now:new Date('2027-02-11T15:00:00')}),6);
  assert.equal(vm.runInNewContext(expr,{now:new Date('2027-02-18T15:00:00')}),6);
  assert.equal(vm.runInNewContext(expr,{now:new Date('2027-02-25T15:00:00')}),7);
 }
 const fulham=WEBSITE_CATALOG.find(t=>t.id==='fulham-home-1'),v=applyCentralSettings(fulham,{},createDefaultClubSettings('fulham')).values;
 assert.match(generateWebsiteCode(fulham,v),/No classes: 15 February 2027/);
 assert.match(generateWebsiteCode(fulham,{...v,excludedDates:[]}),/No half-term break/);
});

test('term date display, JS dates and time formats retain their source conventions',()=>{
 const t={id:'dates',clubId:'swl',originalCode:'start=Date.UTC(2026, 8, 7); 7 Sep; 5:00pm',fields:[{id:'start',type:'date',defaultValue:'2026-09-07'},{id:'time',type:'time',defaultValue:'17:00'}],bindings:[{fieldId:'start',original:'Date.UTC(2026, 8, 7)',encoding:'js-date',dateConstructor:'utc'},{fieldId:'start',original:'7 Sep',encoding:'html-text',format:'date-custom',datePattern:'D MMM'},{fieldId:'time',original:'5:00pm',encoding:'html-text',format:'time-12'}]};
 assert.equal(generateWebsiteCode(t,{start:'2027-01-04',time:'09:15'}),'start=Date.UTC(2027, 0, 4); 4 Jan; 9:15am');
 const catalog=WEBSITE_CATALOG.find(t=>t.id==='swl-home-1');assert.throws(()=>generateWebsiteCode(catalog,{termStart:'2027-03-21',termEnd:'2027-01-04'}),/end must be/);
});

test('script-built class descriptions remain text and timetable accepts ordinary hyphens',()=>{
 const t=WEBSITE_CATALOG.find(t=>t.id==='apex-timetable1-1');const generated=generateWebsiteCode(t,{programme_beginner_description:'Use <img src=x onerror=alert(1)> & enjoy'});
 assert.match(generated,/Use \\u0026lt;img/);assert.doesNotMatch(generated,/description:\s*["']Use <img/);
 const swl=WEBSITE_CATALOG.find(t=>t.id==='swl-classes-1'),v=getTemplateDefaults(swl);v.weeklySchedule[0].time='9:00 - 10:00';
 assert.match(generateWebsiteCode(swl,v),/09:00 – 10:00/);v.weeklySchedule[0].time='17:00 - 16:00';assert.throws(()=>generateWebsiteCode(swl,v),/end time/);
});

test('competition deadline controls visible copy and UK midnight cutoff across GMT/BST',()=>{
 const t=WEBSITE_CATALOG.find(t=>t.id==='swl-in-club-competition-1');
 for(const [date,expected]of [['2027-06-30','2027-06-30T23:00:00.000Z'],['2027-11-15','2027-11-16T00:00:00.000Z']]){
  const output=generateWebsiteCode(t,{entryDeadline:date,competitionBooking:'https://example.com/new-entry'});
  assert.ok(output.includes('Date.parse("'+expected+'")'));assert.ok(output.includes('datetime="'+date+'"'));
  assert.ok(output.includes('const bookingUrl = "https://example.com/new-entry"'));assert.doesNotMatch(output,/square\.link\/u\/Li9VJeOv/);
  for(const script of output.matchAll(/<script\b[^>]*>([\s\S]*?)<\/script\s*>/gi))assert.doesNotThrow(()=>new vm.Script(script[1]));
 }
 const applied=applyCentralSettings(t,{},createDefaultClubSettings('swl'));assert.equal(applied.applied.length,0);assert.equal(generateWebsiteCode(t,applied.values),t.originalCode);
});
