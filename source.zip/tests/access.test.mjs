import test from 'node:test';
import assert from 'node:assert/strict';
import { ACCESS_DURATION_MS, ACCESS_STORAGE_KEY, isCorrectPassword, isAccessRecordValid, reconcileAccess, readRememberedAccess, rememberAccess, clearRememberedAccess } from '../dist/access.js';

function memoryStorage() {
  const values = new Map();
  return { getItem: key => values.get(key) ?? null, setItem: (key, value) => values.set(key, String(value)), removeItem: key => values.delete(key) };
}
const now = 1_800_000_000_000;

test('only the exact fixed password opens the gate', () => {
  assert.equal(isCorrectPassword('Gymnast17500'), true);
  for (const value of ['', 'gymnast17500', 'GYMNAST17500', 'Gymnast17500 ', ' Gymnast17500', null, undefined, 17500]) assert.equal(isCorrectPassword(value), false);
});
test('remembered access is issued for exactly 90 days without storing the password', () => {
  const storage = memoryStorage();
  const result = rememberAccess(storage, now);
  assert.equal(result.remembered, true);
  assert.equal(result.record.expiresAt - result.record.issuedAt, 90 * 24 * 60 * 60 * 1000);
  assert.equal(storage.getItem(ACCESS_STORAGE_KEY).includes('Gymnast17500'), false);
  assert.deepEqual(readRememberedAccess(storage, now + 1), result.record);
});
test('reopening at day 89 preserves the original expiry instead of sliding it forward', () => {
  const storage = memoryStorage();
  const original = rememberAccess(storage, now).record;
  const reopened = readRememberedAccess(storage, now + 89 * 86400000);
  assert.deepEqual(reopened, original);
  assert.equal(JSON.parse(storage.getItem(ACCESS_STORAGE_KEY)).expiresAt, original.expiresAt);
});
test('expiry is exclusive at exactly 90 days without mutating shared storage', () => {
  const storage = memoryStorage();
  const { record } = rememberAccess(storage, now);
  assert.equal(isAccessRecordValid(record, now + ACCESS_DURATION_MS - 1), true);
  assert.equal(isAccessRecordValid(record, now + ACCESS_DURATION_MS), false);
  assert.equal(readRememberedAccess(storage, now + ACCESS_DURATION_MS), null);
  assert.deepEqual(JSON.parse(storage.getItem(ACCESS_STORAGE_KEY)), record);
});
test('malformed, future-dated, old-version and stretched records cannot restore access', () => {
  const storage = memoryStorage();
  const original = rememberAccess(storage, now).record;
  const invalid = ['invalid JSON', null, [], {}, { ...original, version: 2 }, { ...original, issuedAt: now + 1 }, { ...original, expiresAt: original.expiresAt + 1 }, { ...original, issuedAt: String(now) }, { ...original, expiresAt: Infinity }];
  for (const value of invalid) {
    storage.setItem(ACCESS_STORAGE_KEY, typeof value === 'string' ? value : JSON.stringify(value));
    assert.equal(readRememberedAccess(storage, now), null);
  }
});
test('blocked storage still returns a valid current-session record and an honest remember result', () => {
  const blocked = { getItem() { throw new Error('blocked'); }, setItem() { throw new Error('blocked'); }, removeItem() { throw new Error('blocked'); } };
  assert.equal(readRememberedAccess(blocked, now), null);
  const result = rememberAccess(blocked, now);
  assert.equal(result.remembered, false);
  assert.equal(isAccessRecordValid(result.record, now), true);
  assert.equal(clearRememberedAccess(blocked), false);
  assert.equal(rememberAccess(null, now).remembered, false);
});
test('locking removes remembered access and a reload no longer restores it', () => {
  const storage = memoryStorage();
  rememberAccess(storage, now);
  assert.equal(clearRememberedAccess(storage), true);
  assert.equal(readRememberedAccess(storage, now + 100), null);
});
test('a silent failed write is not reported as remembered', () => {
  const storage = { getItem() { return null; }, setItem() {}, removeItem() {} };
  assert.equal(rememberAccess(storage, now).remembered, false);
});
test('locking can invalidate access even if remove is blocked but overwrite works', () => {
  const storage = memoryStorage();
  rememberAccess(storage, now);
  storage.removeItem = () => { throw new Error('cannot remove'); };
  assert.equal(clearRememberedAccess(storage), true);
  assert.equal(readRememberedAccess(storage, now + 100), null);
});


test('an old tab adopts a newer shared login before its old timer expires', () => {
  const storage = memoryStorage();
  const oldRecord = rememberAccess(storage, now).record;
  const freshRecord = rememberAccess(storage, now + 89 * 86400000).record;
  const result = reconcileAccess(storage, oldRecord, true, now + ACCESS_DURATION_MS);
  assert.deepEqual(result, { record: freshRecord, remembered: true, reason: 'stored' });
  assert.deepEqual(JSON.parse(storage.getItem(ACCESS_STORAGE_KEY)), freshRecord);
});
test('cleared shared storage locks an unexpired remembered session on reconciliation', () => {
  const storage = memoryStorage();
  const oldRecord = rememberAccess(storage, now).record;
  storage.removeItem(ACCESS_STORAGE_KEY); // Same resulting state as localStorage.clear().
  const result = reconcileAccess(storage, oldRecord, true, now + 100);
  assert.deepEqual(result, { record: null, remembered: false, reason: 'cleared' });
});
test('a session-only fallback survives absent storage and later blocked reads until its own expiry', () => {
  const storage = memoryStorage();
  const sessionRecord = rememberAccess(null, now).record;
  const expected = { record: sessionRecord, remembered: false, reason: 'session' };
  assert.deepEqual(reconcileAccess(storage, sessionRecord, false, now + 100), expected);
  assert.deepEqual(reconcileAccess(null, sessionRecord, false, now + 100), expected);
  assert.deepEqual(reconcileAccess(null, sessionRecord, false, now + ACCESS_DURATION_MS), { record: null, remembered: false, reason: 'expired' });
});
test('temporary storage unavailability preserves valid remembered access without extending it', () => {
  const record = rememberAccess(null, now).record;
  assert.deepEqual(reconcileAccess(null, record, true, now + 100), { record, remembered: true, reason: 'session' });
  assert.deepEqual(reconcileAccess(null, record, true, now + ACCESS_DURATION_MS), { record: null, remembered: false, reason: 'expired' });
});
test('a locked tab adopts another tab’s valid login and retains its exact expiry', () => {
  const storage = memoryStorage();
  const record = rememberAccess(storage, now).record;
  assert.deepEqual(reconcileAccess(storage, null, false, now + 100), { record, remembered: true, reason: 'stored' });
});
test('expiry reconciliation never removes or overwrites a shared access entry', () => {
  const storage = memoryStorage();
  const record = rememberAccess(storage, now).record;
  storage.removeItem = () => { throw new Error('expiry must not remove shared access'); };
  storage.setItem = () => { throw new Error('expiry must not write shared access'); };
  assert.equal(reconcileAccess(storage, record, true, now + ACCESS_DURATION_MS).record, null);
  assert.deepEqual(JSON.parse(storage.getItem(ACCESS_STORAGE_KEY)), record);
});
