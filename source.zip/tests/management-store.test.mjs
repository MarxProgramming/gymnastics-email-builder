import test from 'node:test';
import assert from 'node:assert/strict';
import {
 MANAGEMENT_STORAGE_KEY, EMAIL_DRAFT_KEYS, MAX_BACKUP_BYTES, createManagementState, createDefaultClubSettings,
 validateManagementState, validateClubSettings, updateClubSettings, saveWebsiteTemplate, deleteWebsiteTemplate,
 cloneConfigurationData, createConfigurationBackup, parseConfigurationBackup, inspectConfigurationBackup,
 restoreConfigurationBackup, createManagementStore, applyClubSettingsToEmailDraft, loadManagementState, countTeachingWeeks
} from '../dist/management-store.js';

function storage(initial = {}) {
 const data = new Map(Object.entries(initial)), writes=[];
 return { data, writes, getItem: key => data.get(key) ?? null, setItem(key,value){data.set(key,String(value));writes.push(['set',key]);}, removeItem(key){data.delete(key);writes.push(['remove',key]);} };
}
const draft = { version:2, clubId:'swl', mode:'renewal', drafts:{'swl:renewal':{subject:'My subject',body:'Literal <script>data only</script>',renewalMessages:{main:{subject:'Main',body:'Text'},reminder:{subject:'Reminder',body:'Follow-up'}},custom:{untouched:true}}}};
const instance={id:'swl-renewal-panel-1',clubId:'swl',templateId:'swl-term-panel',name:'Spring panel',values:{title:'Spring term',price:220},sourceCode:'<script>window.__shouldNotRun=true;</script>',bindings:{title:'term.termName'}};

test('confirmed defaults cover four clubs without changing email drafts or needing storage',()=>{
 const initial=JSON.stringify(draft),store=createManagementStore();assert.equal(store.persistent,false);const state=store.getState();
 assert.deepEqual(Object.keys(state.clubs),['swl','fulham','apex','apexdance']);assert.equal(state.clubs.swl.term.startDate,'2027-01-04');assert.equal(state.clubs.fulham.term.excludedDates[0],'2027-02-15');assert.equal(state.clubs.swl.classes.find(c=>c.regularKey==='swl:beginners').fee,'220.00');assert.equal(state.clubs.apex.classes.find(c=>c.regularKey==='apex:twohouradvanced').fee,'340.00');
 state.clubs.swl.term.startDate='2028-01-01';assert.equal(store.getState().clubs.swl.term.startDate,'2027-01-04');assert.equal(JSON.stringify(draft),initial);
 assert.deepEqual(Object.values(state.clubs).map(club=>club.details.membershipFee),[40,40,0,0]);
 const s=storage({[EMAIL_DRAFT_KEYS[0]]:initial});createManagementStore(s);assert.equal(s.writes.length,0);
});
test('club updates are immutable, preserve unrelated settings, and validate dates/classes before save',()=>{
 const original=createManagementState(),before=JSON.stringify(original);
 const next=updateClubSettings(original,'swl',{term:{deadline:'2026-12-22',excludedDates:['2027-02-01','2027-02-01']}});assert.equal(next.clubs.swl.term.deadline,'2026-12-22');assert.deepEqual(next.clubs.swl.term.excludedDates,['2027-02-01']);assert.deepEqual(next.clubs.apex,original.clubs.apex);assert.equal(JSON.stringify(original),before);
 for(const patch of [{term:{startDate:'2027-02-30'}},{term:{startDate:'2028-01-01'}},{term:{endDate:'2026-01-01'}},{term:{excludedDates:['2028-02-01']}},{classes:[{id:'one',sessions:[{weekday:8}]}]},{classes:[{id:'one',sessions:[{weekday:1,startTime:'18:00',endTime:'17:00'}]}]},{surprise:true}]) assert.throws(()=>updateClubSettings(original,'swl',patch));
 const s=storage(),store=createManagementStore(s);assert.throws(()=>store.saveClubSettings('swl',{term:{endDate:'2026-01-01'}}));assert.equal(s.writes.length,0);
 assert.throws(()=>updateClubSettings(original,'swl',{details:{membershipFee:-40}}));assert.throws(()=>updateClubSettings(original,'fulham',{details:{membershipFee:''}}));
 assert.equal(updateClubSettings(original,'swl',{details:{...original.clubs.swl.details,membershipFee:'42.50'}}).clubs.swl.details.membershipFee,42.5);
});
test('teaching week totals follow active session days and full-week cancellations',()=>{
 const state=createManagementState();assert.deepEqual(Object.values(state.clubs).map(club=>club.term.totalWeeks),[11,9,10,10]);
 const partial=updateClubSettings(state,'swl',{term:{excludedDates:['2027-02-15'],totalWeeks:999}});assert.equal(partial.clubs.swl.term.totalWeeks,11);
 const cancelled=['2027-02-15','2027-02-16','2027-02-17','2027-02-18','2027-02-19','2027-02-20','2027-02-21'];assert.equal(updateClubSettings(state,'swl',{term:{excludedDates:cancelled}}).clubs.swl.term.totalWeeks,10);
 const term={startDate:'2027-01-05',endDate:'2027-01-10',excludedDates:[]};const classes=[{enabled:true,sessions:[{weekday:1}]}];assert.equal(countTeachingWeeks({term,classes}),0);
 assert.equal(countTeachingWeeks({term:{...term,endDate:'2027-01-11'},classes}),1);assert.equal(countTeachingWeeks({term,classes:[]}),0);
 const withoutBreak=updateClubSettings(state,'apex',{term:{excludedDates:[]}});assert.equal(withoutBreak.clubs.apex.term.totalWeeks,11);
});
test('saved templates preserve original code as inert data and update by instance ID',()=>{
 const base=createManagementState();const first=saveWebsiteTemplate(base,instance);assert.equal(first.templates[0].sourceCode,instance.sourceCode);assert.equal(globalThis.__shouldNotRun,undefined);assert.equal(base.templates.length,0);
 const next=saveWebsiteTemplate(first,{...instance,name:'Edited',values:{title:'Summer'}});assert.equal(next.templates.length,1);assert.equal(next.templates[0].name,'Edited');assert.equal(first.templates[0].name,'Spring panel');assert.equal(deleteWebsiteTemplate(next,instance.id).templates.length,0);
 assert.throws(()=>saveWebsiteTemplate(base,{...instance,clubId:'unknown'}));assert.throws(()=>saveWebsiteTemplate(base,{...instance,name:''}));
});
test('saved source fingerprints survive backups and reject malformed fingerprints before writing',()=>{
 const s=storage(),store=createManagementStore(s),fingerprint='A1'.repeat(32);
 store.saveTemplate({...instance,sourceHash:fingerprint});
 const exported=parseConfigurationBackup(store.exportBackup());assert.equal(exported.management.templates[0].sourceHash,fingerprint.toLowerCase());
 const restored=createManagementStore(storage());restored.importBackup(exported);assert.equal(restored.getState().templates[0].sourceHash,fingerprint.toLowerCase());
 const writes=s.writes.length;
 for(const sourceHash of ['',null,'not-a-hash','a'.repeat(63),'g'.repeat(64),123])assert.throws(()=>store.saveTemplate({...instance,sourceHash}),/fingerprint/);
 assert.equal(s.writes.length,writes);assert.equal(store.getState().templates[0].sourceHash,fingerprint.toLowerCase());
 assert.equal(saveWebsiteTemplate(createManagementState(),instance).templates[0].sourceHash,undefined);
});
test('backup includes exactly the supported email drafts and never access or unrelated storage',()=>{
 const raw=JSON.stringify(draft,null,2),legacy=JSON.stringify({clubId:'apex',subject:'Older draft'});
 const s=storage({[EMAIL_DRAFT_KEYS[0]]:raw,[EMAIL_DRAFT_KEYS[1]]:legacy,'club-email-builder-access-v1':'SECRET ACCESS','other-tool':'PRIVATE'});
 const backup=createConfigurationBackup(s,saveWebsiteTemplate(createManagementState(),instance),{now:'2026-11-07T12:00:00Z'}),serialized=JSON.stringify(backup);assert.equal(backup.emailDrafts[EMAIL_DRAFT_KEYS[0]],raw);assert.equal(backup.emailDrafts[EMAIL_DRAFT_KEYS[1]],legacy);assert.ok(!serialized.includes('SECRET ACCESS'));assert.ok(!serialized.includes('PRIVATE'));assert.deepEqual(Object.keys(backup.emailDrafts),EMAIL_DRAFT_KEYS);
 const inspected=inspectConfigurationBackup(serialized);assert.equal(inspected.summary.templates,1);assert.equal(inspected.summary.emailDraftCount,2);assert.equal(inspected.summary.clubs,4);assert.equal(s.writes.length,0);assert.equal(parseConfigurationBackup(serialized).management.templates[0].sourceCode,instance.sourceCode);
});
test('restoring settings keeps email drafts by default and restores them only explicitly',()=>{
 const previous=JSON.stringify({...draft,mode:'basic'}),incoming=JSON.stringify(draft);const source=storage({[EMAIL_DRAFT_KEYS[0]]:incoming});const backup=createConfigurationBackup(source);
 const dest=storage({[EMAIL_DRAFT_KEYS[0]]:previous,[EMAIL_DRAFT_KEYS[1]]:'old legacy text','club-email-builder-access-v1':'KEEP','other-tool':'KEEP TOO'});
 const result=restoreConfigurationBackup(dest,backup);assert.equal(dest.getItem(EMAIL_DRAFT_KEYS[0]),previous);assert.equal(dest.getItem(EMAIL_DRAFT_KEYS[1]),'old legacy text');assert.deepEqual(result.restoredEmailDraftKeys,[]);
 const restored=restoreConfigurationBackup(dest,backup,{restoreEmailDrafts:true});assert.equal(dest.getItem(EMAIL_DRAFT_KEYS[0]),incoming);assert.equal(dest.getItem(EMAIL_DRAFT_KEYS[1]),null);assert.deepEqual(restored.restoredEmailDraftKeys,EMAIL_DRAFT_KEYS);assert.equal(dest.getItem('club-email-builder-access-v1'),'KEEP');assert.equal(dest.getItem('other-tool'),'KEEP TOO');
});
test('invalid backups and prototype attacks fail before writing anything',()=>{
 const backup=createConfigurationBackup(storage()),s=storage();
 const attacks=[
  JSON.stringify({...backup,version:99}),JSON.stringify({...backup,format:'other'}),'{bad json',
  JSON.stringify({...backup,emailDrafts:{'club-email-builder-access-v1':'secret'}}),
  JSON.stringify({...backup,emailDrafts:{[EMAIL_DRAFT_KEYS[0]]:JSON.stringify({version:2,drafts:{'bad:renewal':{}}})}}),
  JSON.stringify({...backup,emailDrafts:{[EMAIL_DRAFT_KEYS[0]]:'{"version":2,"drafts":{"swl:renewal":{"__proto__":{"polluted":true}}}}'}}),
  JSON.stringify(backup).replace('"templates":[]','"templates":[],"__proto__":{"polluted":true}'),
  JSON.stringify({...backup,management:{...backup.management,templates:[{...instance,values:JSON.parse('{"constructor":{"prototype":{"polluted":true}}}')} ]}})
 ];
 for(const value of attacks)assert.throws(()=>restoreConfigurationBackup(s,value,{restoreEmailDrafts:true}));assert.equal(s.writes.length,0);assert.equal({}.polluted,undefined);assert.throws(()=>parseConfigurationBackup(' '.repeat(MAX_BACKUP_BYTES+1)));
 assert.throws(()=>cloneConfigurationData({method(){}}));const custom=Object.create({inherited:'bad'});custom.good=1;assert.throws(()=>cloneConfigurationData(custom));
});
test('restore rolls back previous management and drafts on a quota failure',()=>{
 const oldState=createManagementState(),newState=updateClubSettings(oldState,'swl',{term:{deadline:'2026-12-01'}}),raw=JSON.stringify(draft);
 const original={[MANAGEMENT_STORAGE_KEY]:JSON.stringify(oldState),[EMAIL_DRAFT_KEYS[0]]:'old-current',[EMAIL_DRAFT_KEYS[1]]:'old-legacy'},s=storage(original);let failOnce=true;const set=s.setItem.bind(s);s.setItem=(key,value)=>{if(key===EMAIL_DRAFT_KEYS[0]&&failOnce){failOnce=false;throw Error('quota');}set(key,value);};
 const backup=createConfigurationBackup(storage({[EMAIL_DRAFT_KEYS[0]]:raw}),newState);assert.throws(()=>restoreConfigurationBackup(s,backup,{restoreEmailDrafts:true}),error=>error.code==='RESTORE_FAILED'&&error.rollbackComplete===true);assert.deepEqual(Object.fromEntries(s.data),original);
});
test('a failed rollback is reported honestly and in-memory state does not claim success',()=>{
 const s=storage(),store=createManagementStore(s),old=store.getState(),newState=updateClubSettings(old,'swl',{term:{deadline:'2026-12-01'}}),backup=createConfigurationBackup(storage({[EMAIL_DRAFT_KEYS[0]]:JSON.stringify(draft)}),newState);
 const set=s.setItem.bind(s);s.setItem=(key,value)=>{if(key===EMAIL_DRAFT_KEYS[0])throw Error('quota');set(key,value);};s.removeItem=()=>{throw Error('blocked');};
 assert.throws(()=>store.importBackup(backup,{restoreEmailDrafts:true}),error=>error.code==='RESTORE_FAILED'&&error.rollbackComplete===false);assert.deepEqual(store.getState(),old);
});
test('explicit term apply preserves message, custom prices, links and policies by default',()=>{
 const central=updateClubSettings(createManagementState(),'swl',{term:{deadline:'2026-12-12'}}).clubs.swl;
 const original={subject:'Custom',body:'Custom body',renewalMessages:{reminder:{subject:'Keep',body:'Keep'}},cards:[{name:'Custom class',fee:'987',paymentUrl:'https://example.com/custom'}],campaign:{refundPolicy:'Custom policy',deadline:'2026-12-20',additionalInfo:'Keep'},customFlag:true};const before=JSON.stringify(original);
 const result=applyClubSettingsToEmailDraft(original,central,{clubId:'swl',includeDeadline:false});assert.equal(result.subject,'Custom');assert.deepEqual(result.cards,original.cards);assert.equal(result.campaign.refundPolicy,'Custom policy');assert.equal(result.campaign.deadline,'2026-12-20');assert.equal(result.campaign.startDate,'2027-01-04');assert.equal(JSON.stringify(original),before);
 const withClasses=applyClubSettingsToEmailDraft(original,central,{clubId:'swl',includeClasses:true});assert.equal(withClasses.cards[0].fee,'220.00');assert.equal(withClasses.campaign.deadline,'2026-12-12');assert.deepEqual(result.renewalMessages,original.renewalMessages);
 const apex=applyClubSettingsToEmailDraft({},createDefaultClubSettings('apex'),{clubId:'apex'});assert.equal(apex.campaign.startDate,'2027-01-07');
});
test('facade round-trips configurations and reports malformed local state instead of silently deleting it',()=>{
 const s=storage({[EMAIL_DRAFT_KEYS[0]]:JSON.stringify(draft)}),store=createManagementStore(s);store.saveTemplate(instance);store.saveClubSettings('fulham',{term:{deadline:'2026-12-15'}});store.selectClub('fulham');const exported=store.exportBackup();const restored=createManagementStore(storage());const result=restored.importBackup(exported);assert.equal(result.state.selectedClub,'fulham');assert.equal(restored.getClubSettings('fulham').term.deadline,'2026-12-15');assert.equal(restored.getState().templates.length,1);
 const bad=storage({[MANAGEMENT_STORAGE_KEY]:'broken'});assert.throws(()=>loadManagementState(bad),/not valid JSON/);assert.equal(bad.getItem(MANAGEMENT_STORAGE_KEY),'broken');assert.equal(bad.writes.length,0);
 const missing=createManagementState();delete missing.clubs.apex;assert.throws(()=>validateManagementState(missing));assert.throws(()=>validateClubSettings({classes:[{id:'same',sessions:[]},{id:'same',sessions:[]}]},'swl'));
});
