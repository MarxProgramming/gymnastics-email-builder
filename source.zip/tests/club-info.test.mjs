import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import { readFile } from 'node:fs/promises';
import { CLUB_INFO_VERSION, getClubInfoDefaults, migrateClubInfo, setAnnualMembershipReminder } from '../dist/club-info.js';
import { validateCampaign } from '../dist/campaigns.js';
import { buildStandalone } from '../scripts/build-standalone.mjs';
globalThis.fetch = async url => new Response(await readFile(url, 'utf8'));
const { CLUBS, generateScript, renderPreview } = await import('../dist/engine.js');
const prefixes = { swl:'Swl',fulham:'Fulham',apex:'Apex',apexdance:'ApexDance' };
const baseCampaign = {termName:'Future term',startDate:'2028-04-03',endDate:'2028-04-30',deadline:'2028-03-20',classes:[{id:'example',name:'Example class',fee:'100',paymentUrl:'https://example.com/pay',sessions:[{weekday:1,startTime:'17:00',endTime:'18:00'}]}]};
const optionsFor = (clubId,mode) => ({mode,subject:'{{term}} for {{child}}',body:'Class details for {{child}}.',campaign:{...baseCampaign,...getClubInfoDefaults(clubId,mode)}});

test('standard content has no historical campaign values and obeys membership/uniform overrides',()=>{
  for(const club of CLUBS)for(const mode of ['renewal','offer']) {
    const defaults=getClubInfoDefaults(club.id,mode);
    for(const key of ['startDate','endDate','deadline','offerExpiryHours','classes','fee','paymentUrl'])assert.ok(!(key in defaults));
    assert.ok(!/£|\b202[0-9]\b|square\.link/.test(JSON.stringify(defaults)));
    assert.equal(defaults.informationUrl,new URL(defaults.informationUrl).origin);
    if(mode==='renewal')assert.ok(defaults.paymentInstructions.includes('{{deadline}}'));
    else {assert.ok(defaults.paymentInstructions.includes('by the acceptance deadline shown above'));assert.ok(!defaults.paymentInstructions.includes('{{deadline}}'));}
    assert.ok(defaults.location && defaults.mapUrl && defaults.whatToBring);
    if(['swl','fulham'].includes(club.id))assert.equal(defaults.membershipNote,'The price includes IGA membership.');
    if(club.id==='fulham')assert.equal(defaults.uniformUrl,'');
    if(club.id==='apexdance'){assert.equal(defaults.uniformUrl,'https://www.movedancewear.com/alegra-girls-shiny-hotpant-unitard-p2750/');assert.equal(defaults.uniformButtonText,'Suggested dancewear (optional)');assert.equal(defaults.membershipNote,'');assert.equal(defaults.membershipUrl,'');assert.match(defaults.whatToBring,/any colour/);}
    if(club.id==='apex')assert.equal(Boolean(defaults.membershipUrl),mode==='offer');
  }
  assert.match(getClubInfoDefaults('apex','offer').membershipNote,/does not already have current/);
  assert.match(getClubInfoDefaults('swl','offer').parentViewing,/first session/);
  assert.ok(!getClubInfoDefaults('swl','renewal').parentViewing.includes('first session'));
  assert.match(getClubInfoDefaults('apexdance','renewal').refundPolicy,/one full term/);
  assert.ok(!getClubInfoDefaults('apexdance','offer').refundPolicy.includes('one full term'));
});

test('one-time migration fills old blank fields while preserving customised copy and campaign data',()=>{
  const original={subject:'My subject',campaign:{...baseCampaign,membershipNote:'My membership wording',refundPolicy:'  ',mapUrl:'https://example.com/venue',additionalInfo:'Special arrangements'},cards:[{name:'custom'}]};
  const before=JSON.stringify(original);const migrated=migrateClubInfo('swl','renewal',original);
  assert.equal(JSON.stringify(original),before,'input is not mutated');
  assert.equal(migrated.subject,original.subject);assert.deepEqual(migrated.cards,original.cards);
  assert.equal(migrated.campaign.membershipNote,'My membership wording');assert.equal(migrated.campaign.mapUrl,'https://example.com/venue');assert.equal(migrated.campaign.additionalInfo,'Special arrangements');
  assert.equal(migrated.campaign.deadline,baseCampaign.deadline);assert.deepEqual(migrated.campaign.classes,baseCampaign.classes);
  assert.ok(migrated.campaign.refundPolicy.trim());assert.equal(migrated.clubInfo.version,CLUB_INFO_VERSION);
  const cleared={...migrated,campaign:{...migrated.campaign,refundPolicy:'',membershipNote:'',mapUrl:''}};
  assert.deepEqual(migrateClubInfo('swl','renewal',JSON.parse(JSON.stringify(cleared))),cleared,'subsequent loads respect deliberate removal');
});

test('defaults and one-time markers stay separate across clubs and modes',()=>{
  const offer=migrateClubInfo('apex','offer',{});
  const renewal=migrateClubInfo('apex','renewal',offer);
  assert.equal(renewal.campaign.membershipNote,'');assert.equal(renewal.campaign.membershipUrl,'');
  const dance=migrateClubInfo('apexdance','offer',offer);
  assert.equal(dance.campaign.membershipNote,'');assert.equal(dance.campaign.uniformUrl,getClubInfoDefaults('apexdance','offer').uniformUrl);assert.notEqual(dance.campaign.uniformUrl,offer.campaign.uniformUrl);assert.ok(dance.campaign.informationUrl.includes('apexdanceclub'));
  assert.ok(offer.campaign.membershipUrl,'previous draft remains intact');
  const edited={...offer,campaign:{...offer.campaign,additionalInfo:'Keep my note',refundPolicy:'Custom arrangement'}};
  assert.equal(migrateClubInfo('fulham','renewal',edited).campaign.refundPolicy,'Custom arrangement');
  const own=getClubInfoDefaults('swl','offer');own.location='Changed';
  assert.notEqual(getClubInfoDefaults('swl','offer').location,'Changed');
  const basic={body:'Basic body',campaign:{location:'Custom'}};
  assert.deepEqual(migrateClubInfo('apex','basic',basic),basic);assert.deepEqual(getClubInfoDefaults('apex','basic'),{});
});

test('Apex annual reminder is opt-in, reversible, persisted and never overwrites custom membership edits',()=>{
  const initial=migrateClubInfo('apex','renewal',{});
  assert.equal(initial.campaign.membershipNote,'');
  const enabled=setAnnualMembershipReminder('apex','renewal',initial,true);
  assert.equal(enabled.annualMembershipReminder,true);assert.match(enabled.campaign.membershipNote,/annual.*is due/);
  assert.equal(enabled.campaign.membershipUrl,'https://mybg.british-gymnastics.org/');
  assert.deepEqual(migrateClubInfo('apex','renewal',JSON.parse(JSON.stringify(enabled))),enabled);
  const disabled=setAnnualMembershipReminder('apex','renewal',enabled,false);
  assert.equal(disabled.annualMembershipReminder,false);assert.equal(disabled.campaign.membershipNote,'');assert.equal(disabled.campaign.membershipUrl,'');
  const custom={...enabled,campaign:{...enabled.campaign,membershipNote:'Custom annual arrangement',membershipUrl:'https://example.com/membership'}};
  const protectedEdit=setAnnualMembershipReminder('apex','renewal',custom,false);
  assert.equal(protectedEdit.campaign.membershipNote,custom.campaign.membershipNote);assert.equal(protectedEdit.campaign.membershipUrl,custom.campaign.membershipUrl);
  assert.deepEqual(setAnnualMembershipReminder('apexdance','renewal',custom,true),custom);
});

for(const club of CLUBS)for(const mode of ['renewal','offer'])test(`${club.name} ${mode}: default details and nearby links have exact preview/export parity`,async()=>{
  const options=optionsFor(club.id,mode);const script=await generateScript(club.id,options);const context=vm.createContext({});vm.runInContext(script,context);
  vm.runInContext('selectedCampaignClass_=EMAIL_CAMPAIGN.campaign.classes[0]',context);
  const actual=context[`build${prefixes[club.id]}Email_`]('Pat','Alex');const preview=await renderPreview(club.id,options,{parent:'Pat',child:'Alex'});
  const b64=script.match(new RegExp(`const ${club.id.toUpperCase()}_LOGO_BASE64 = ["']([^"']+)`))[1];
  assert.equal(preview,actual.htmlBody.replace(`cid:${club.id}Logo`,`data:${club.logoMime};base64,${b64}`));
  assert.ok(actual.plainBody.includes(options.campaign.location));assert.ok(!actual.plainBody.includes('{{deadline}}'));assert.ok(actual.plainBody.includes('20 March 2028'));
  for(const key of ['mapUrl','uniformUrl','membershipUrl','policyUrl','informationUrl'])if(options.campaign[key]){assert.ok(preview.includes('href="'+options.campaign[key].replaceAll('&','&amp;')+'"'));assert.ok(actual.plainBody.includes(options.campaign[key]));}
  const location=preview.indexOf('>Location<'),map=preview.indexOf('>Google Maps<'),viewing=preview.indexOf('>Parent viewing<');
  assert.ok(location<map && map<viewing,'map is adjacent to location before parent viewing');
  if(options.campaign.uniformUrl){const label=options.campaign.uniformButtonText.replaceAll('&','&amp;');assert.ok(preview.indexOf('>What to wear &amp; bring<')<preview.indexOf('>'+label+'<') && preview.indexOf('>'+label+'<')<location);}
  if(options.campaign.membershipUrl)assert.ok(preview.indexOf('>Membership<')<preview.indexOf('>British Gymnastics membership<') && preview.indexOf('>British Gymnastics membership<')<preview.indexOf('>How to accept<'));
  if(club.id==='apex'&&mode==='renewal')assert.ok(!actual.plainBody.includes('British Gymnastics')&&!actual.plainBody.includes('mybg.'));
  if(club.id==='fulham')assert.ok(!preview.includes('>View leotards &amp; uniform<'));
  if(club.id==='apexdance')assert.ok(preview.includes('>Suggested dancewear (optional)<'));
});

test('membership/policy links validate HTTPS and all new text remains escaped data',async()=>{
  for(const key of ['membershipUrl','policyUrl'])assert.throws(()=>validateCampaign('renewal',{...baseCampaign,[key]:'javascript:alert(1)'}),/https/);
  const options=optionsFor('apex','offer');Object.assign(options.campaign,{paymentInstructions:'Literal <script> & ${1+1}',membershipButtonText:'My <BG> & signup',uniformButtonText:'Uniform <link>',policyButtonText:'Rules & <details>'});
  const html=await renderPreview('apex',options);
  for(const text of ['Literal &lt;script&gt; &amp; ${1+1}','My &lt;BG&gt; &amp; signup','Uniform &lt;link&gt;','Rules &amp; &lt;details&gt;'])assert.ok(html.includes(text));
});

test('standalone includes the identical defaults, migration and reminder helpers without network dependencies',async()=>{
  const {engineSource}=await buildStandalone();const context=vm.createContext({URL});vm.runInContext(engineSource+'\nglobalThis.info={getClubInfoDefaults,migrateClubInfo,setAnnualMembershipReminder};',context);
  for(const club of CLUBS)for(const mode of ['renewal','offer'])assert.deepEqual(JSON.parse(JSON.stringify(context.info.migrateClubInfo(club.id,mode,{}))),migrateClubInfo(club.id,mode,{}));
  assert.deepEqual(JSON.parse(JSON.stringify(context.info.setAnnualMembershipReminder('apex','renewal',{},true))),setAnnualMembershipReminder('apex','renewal',{},true));
});

test('all Offer payment instructions read naturally for either a fixed date or hours window',async()=>{
  for(const club of CLUBS)for(const hours of [false,true]) {
    const options=optionsFor(club.id,'offer');
    if(hours){options.campaign.deadline='';options.campaign.offerExpiryHours='48';}
    const html=await renderPreview(club.id,options);
    assert.ok(html.includes('by the acceptance deadline shown above'));
    assert.ok(!html.includes('by 48 hours'));
    assert.ok(html.includes(hours?'48 hours from receiving this email':'20 March 2028'));
    if(club.id==='swl')assert.ok(html.includes('Please reply to accept'));
  }
});
