import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import { readFile } from 'node:fs/promises';
import { CLUB_INFO_VERSION, getClubInfoDefaults, migrateClubInfo, setAnnualMembershipReminder } from '../dist/club-info.js';
import { validateCampaign } from '../dist/campaigns.js';
import { buildStandalone } from '../scripts/build-standalone.mjs';
globalThis.fetch = async url => new Response(await readFile(url, 'utf8'));
const { CLUBS, generateScript, renderPreview } = await import('../dist/engine.js');
const prefixes = { swl:'Swl',fulham:'Fulham',apex:'Apex',apexdance:'ApexDance' };
const baseCampaign = {bankAccountName:'Test Club',bankSortCode:'00-00-00',bankAccountNumber:'00000000',termName:'Future term',startDate:'2028-04-03',endDate:'2028-04-30',deadline:'2028-03-20',classes:[{id:'example',name:'Example class',fee:'100',paymentUrl:'https://example.com/pay',sessions:[{weekday:1,startTime:'17:00',endTime:'18:00'}]}]};
const optionsFor = (clubId,mode) => ({mode,subject:'{{term}} for {{child}}',body:'Class details for {{child}}.',campaign:{...baseCampaign,...getClubInfoDefaults(clubId,mode)}});

test('standard content has no historical campaign values and obeys membership/uniform overrides',()=>{
  for(const club of CLUBS)for(const mode of ['renewal','offer']) {
    const defaults=getClubInfoDefaults(club.id,mode);
    for(const key of ['startDate','endDate','deadline','offerExpiryHours','classes','fee','paymentUrl'])assert.ok(!(key in defaults));
    assert.ok(!/\b202[0-9]\b|square\.link/.test(JSON.stringify(defaults)));
    if(!(club.id==='fulham'||(club.id==='swl'&&mode==='offer')))assert.ok(!JSON.stringify(defaults).includes('£'));
    assert.equal(defaults.informationUrl,new URL(defaults.informationUrl).origin);
    if(mode==='renewal')assert.ok(defaults.paymentInstructions.includes('{{deadline}}'));
    else {assert.ok(defaults.paymentInstructions.includes('by the acceptance deadline shown above'));assert.ok(!defaults.paymentInstructions.includes('{{deadline}}'));}
    assert.ok(defaults.location && defaults.mapUrl && defaults.whatToBring);
    if(club.id==='swl'&&mode==='renewal')assert.equal(defaults.membershipNote,'The price includes IGA membership.');
    if(club.id==='fulham')assert.match(defaults.membershipNote,/£40 annual IGA membership|Annual IGA membership costs £40/);
    if(club.id==='fulham')assert.match(defaults.membershipNote,/September/);
    if(club.id==='swl'&&mode==='offer')assert.equal(defaults.membershipNote,'The total fee shown includes £40 annual IGA membership in addition to the tuition fee.');
    if(club.id==='fulham')assert.equal(defaults.uniformUrl,'');
    if(club.id==='apexdance'){assert.equal(defaults.uniformUrl,'https://www.movedancewear.com/alegra-girls-shiny-hotpant-unitard-p2750/');assert.equal(defaults.uniformButtonText,'Suggested dancewear (optional)');assert.equal(defaults.membershipNote,'');assert.equal(defaults.membershipUrl,'');assert.match(defaults.whatToBring,/any colour/);}
    if(club.id==='apex')assert.equal(Boolean(defaults.membershipUrl),mode==='offer');
  }
  assert.match(getClubInfoDefaults('apex','offer').membershipNote,/does not already have current/);
  for(const club of CLUBS)for(const mode of ['offer','renewal']){assert.match(getClubInfoDefaults(club.id,mode).parentViewing,/usually.*second-to-last class of term/);assert.match(getClubInfoDefaults(club.id,mode).parentViewing,/details nearer the date/);}
  assert.match(getClubInfoDefaults('apexdance','renewal').refundPolicy,/one full term/);
  assert.ok(!getClubInfoDefaults('apexdance','offer').refundPolicy.includes('one full term'));
});

test('one-time migration fills old blank fields while preserving customised copy and campaign data',()=>{
  const original={subject:'My subject',campaign:{...baseCampaign,membershipNote:'My membership wording',refundPolicy:'  ',mapUrl:'https://example.com/venue',additionalInfo:'Special arrangements'},cards:[{name:'custom'}]};
  const before=JSON.stringify(original);const migrated=migrateClubInfo('swl','renewal',original);
  assert.equal(JSON.stringify(original),before,'input is not mutated');
  assert.equal(migrated.subject,original.subject);assert.deepEqual(migrated.cards,original.cards);
  assert.equal(migrated.campaign.membershipNote,'My membership wording');assert.equal(migrated.campaign.mapUrl,'https://example.com/venue');assert.equal(migrated.campaign.additionalInfo,'Special arrangements');
  assert.equal(migrated.campaign.deadline,baseCampaign.deadline);assert.deepEqual(migrated.campaign.classes,baseCampaign.classes);
  assert.ok(migrated.campaign.refundPolicy.trim());assert.equal(migrated.clubInfo.version,CLUB_INFO_VERSION);
  const cleared={...migrated,campaign:{...migrated.campaign,refundPolicy:'',membershipNote:'',mapUrl:''}};
  assert.deepEqual(migrateClubInfo('swl','renewal',JSON.parse(JSON.stringify(cleared))),cleared,'subsequent loads respect deliberate removal');
});

test('defaults and one-time markers stay separate across clubs and modes',()=>{
  const offer=migrateClubInfo('apex','offer',{});
  const renewal=migrateClubInfo('apex','renewal',offer);
  assert.equal(renewal.campaign.membershipNote,'');assert.equal(renewal.campaign.membershipUrl,'');
  const dance=migrateClubInfo('apexdance','offer',offer);
  assert.equal(dance.campaign.membershipNote,'');assert.equal(dance.campaign.uniformUrl,getClubInfoDefaults('apexdance','offer').uniformUrl);assert.notEqual(dance.campaign.uniformUrl,offer.campaign.uniformUrl);assert.ok(dance.campaign.informationUrl.includes('apexdanceclub'));
  assert.ok(offer.campaign.membershipUrl,'previous draft remains intact');
  const edited={...offer,campaign:{...offer.campaign,additionalInfo:'Keep my note',refundPolicy:'Custom arrangement'}};
  assert.equal(migrateClubInfo('fulham','renewal',edited).campaign.refundPolicy,'Custom arrangement');
  const own=getClubInfoDefaults('swl','offer');own.location='Changed';
  assert.notEqual(getClubInfoDefaults('swl','offer').location,'Changed');
  const basic={body:'Basic body',campaign:{location:'Custom'}};
  assert.deepEqual(migrateClubInfo('apex','basic',basic),basic);assert.deepEqual(getClubInfoDefaults('apex','basic'),{});
});

test('Apex annual reminder is opt-in, reversible, persisted and never overwrites custom membership edits',()=>{
  const initial=migrateClubInfo('apex','renewal',{});
  assert.equal(initial.campaign.membershipNote,'');
  const enabled=setAnnualMembershipReminder('apex','renewal',initial,true);
  assert.equal(enabled.annualMembershipReminder,true);assert.match(enabled.campaign.membershipNote,/annual.*is due/);
  assert.equal(enabled.campaign.membershipUrl,'https://mybg.british-gymnastics.org/');
  assert.deepEqual(migrateClubInfo('apex','renewal',JSON.parse(JSON.stringify(enabled))),enabled);
  const disabled=setAnnualMembershipReminder('apex','renewal',enabled,false);
  assert.equal(disabled.annualMembershipReminder,false);assert.equal(disabled.campaign.membershipNote,'');assert.equal(disabled.campaign.membershipUrl,'');
  const custom={...enabled,campaign:{...enabled.campaign,membershipNote:'Custom annual arrangement',membershipUrl:'https://example.com/membership'}};
  const protectedEdit=setAnnualMembershipReminder('apex','renewal',custom,false);
  assert.equal(protectedEdit.campaign.membershipNote,custom.campaign.membershipNote);assert.equal(protectedEdit.campaign.membershipUrl,custom.campaign.membershipUrl);
  assert.deepEqual(setAnnualMembershipReminder('apexdance','renewal',custom,true),custom);
});

for(const club of CLUBS)for(const mode of ['renewal','offer'])test(`${club.name} ${mode}: default details and nearby links have exact preview/export parity`,async()=>{
  const options=optionsFor(club.id,mode);const script=await generateScript(club.id,options);const context=vm.createContext({});vm.runInContext(script,context);
  vm.runInContext('selectedCampaignClass_=EMAIL_CAMPAIGN.campaign.classes[0]',context);
  const actual=context[`build${prefixes[club.id]}Email_`]('Pat','Alex');const preview=await renderPreview(club.id,options,{parent:'Pat',child:'Alex'});
  const b64=script.match(new RegExp(`const ${club.id.toUpperCase()}_LOGO_BASE64 = ["']([^"']+)`))[1];
  assert.equal(preview,actual.htmlBody.replace(`cid:${club.id}Logo`,`data:${club.logoMime};base64,${b64}`));
  assert.equal(actual.plainBody.includes(options.campaign.location), mode === 'offer');assert.ok(!actual.plainBody.includes('{{deadline}}'));assert.ok(actual.plainBody.includes('20 March 2028'));
  for(const key of ['mapUrl','uniformUrl','membershipUrl','policyUrl','informationUrl'])if(options.campaign[key] && !(mode === 'renewal' && key !== 'membershipUrl')){assert.ok(preview.includes('href="'+options.campaign[key].replaceAll('&','&amp;')+'"'));assert.ok(actual.plainBody.includes(options.campaign[key]));}
  const location=preview.indexOf('>Location<'),map=preview.indexOf('>Google Maps<'),viewing=preview.indexOf('>Parent viewing<');
  if (mode === 'renewal') assert.equal(location + map + viewing, -3);
  else { assert.ok(location < map, 'map follows location'); assert.equal(viewing, -1, 'viewing is reserved for renewals'); }
  if(mode === 'offer' && options.campaign.uniformUrl){const label=options.campaign.uniformButtonText.replaceAll('&','&amp;');assert.ok(preview.indexOf('>What to wear &amp; bring<')<preview.indexOf('>'+label+'<') && preview.indexOf('>'+label+'<')<location);}
  if(options.campaign.membershipUrl)assert.ok(preview.indexOf('>Membership<')<preview.indexOf('>British Gymnastics membership<') && preview.indexOf('>British Gymnastics membership<')<preview.indexOf('>How to accept<'));
  if(club.id==='apex'&&mode==='renewal')assert.ok(!actual.plainBody.includes('British Gymnastics')&&!actual.plainBody.includes('mybg.'));
  if(club.id==='fulham')assert.ok(!preview.includes('>View leotards &amp; uniform<'));
  if(club.id==='apexdance')assert.equal(preview.includes('>Suggested dancewear (optional)<'),mode==='offer');
});

test('membership/policy links validate HTTPS and all new text remains escaped data',async()=>{
  for(const key of ['membershipUrl','policyUrl'])assert.throws(()=>validateCampaign('offer',{...baseCampaign,[key]:'javascript:alert(1)'}),/https/);
  const options=optionsFor('apex','offer');Object.assign(options.campaign,{paymentInstructions:'Literal <script> & ${1+1}',membershipButtonText:'My <BG> & signup',uniformButtonText:'Uniform <link>',policyButtonText:'Rules & <details>'});
  const html=await renderPreview('apex',options);
  for(const text of ['Literal &lt;script&gt; &amp; ${1+1}','My &lt;BG&gt; &amp; signup','Uniform &lt;link&gt;','Rules &amp; &lt;details&gt;'])assert.ok(html.includes(text));
});

test('standalone includes the identical defaults, migration and reminder helpers without network dependencies',async()=>{
  const {engineSource}=await buildStandalone();const context=vm.createContext({URL});vm.runInContext(engineSource+'\nglobalThis.info={getClubInfoDefaults,migrateClubInfo,setAnnualMembershipReminder};',context);
  for(const club of CLUBS)for(const mode of ['renewal','offer'])assert.deepEqual(JSON.parse(JSON.stringify(context.info.migrateClubInfo(club.id,mode,{}))),migrateClubInfo(club.id,mode,{}));
  assert.deepEqual(JSON.parse(JSON.stringify(context.info.setAnnualMembershipReminder('apex','renewal',{},true))),setAnnualMembershipReminder('apex','renewal',{},true));
});

test('all Offer payment instructions read naturally for either a fixed date or hours window',async()=>{
  for(const club of CLUBS)for(const hours of [false,true]) {
    const options=optionsFor(club.id,'offer');
    if(hours){options.campaign.deadline='';options.campaign.offerExpiryHours='48';}
    const html=await renderPreview(club.id,options);
    assert.ok(html.includes('by the acceptance deadline shown above'));
    assert.ok(!html.includes('by 48 hours'));
    assert.ok(html.includes(hours?'48 hours from receiving this email':'20 March 2028'));
    if(club.id==='swl')assert.ok(html.includes('Please reply to accept'));
  }
});

const previousViewing = {
  swl: { renewal:'Parents wait outside during regular classes. We will announce any designated watching sessions separately.',offer:'New parents may watch the warm up for the first session, usually the first 5 to 10 minutes, then must wait outside during classes.' },
  fulham: { renewal:'Please contact us before the first session if you need information about parent viewing arrangements.',offer:'Please contact us before the first session if you need information about parent viewing arrangements.' },
  apex: { renewal:'Parents do not normally watch regular classes from the gym. We will announce any designated watching sessions separately.',offer:'Parents do not normally watch regular classes from the gym. We will announce any designated watching sessions separately.' },
  apexdance: { renewal:'Parents do not watch regular sessions from the studio. We will share details of designated watching sessions.',offer:'Parents do not watch regular sessions from the studio. We will share details of designated watching sessions.' }
};
const previousOfferRefunds = {
  swl:'We cannot offer trial sessions. If your child is unhappy or unable to continue, we will refund any remaining classes that are not attended.',
  fulham:'If the club cancels a class because of unforeseen circumstances, a refund will be provided.',
  apex:'During the first term, you may withdraw by giving written notice. We will refund the classes in that term that have not yet been attended. Missed classes for personal reasons are not refunded.',
  apexdance:'During the first term, you may withdraw by emailing management@apexdanceclub.co.uk. Classes in that term that have not yet been attended will be refunded. Missed classes for personal reasons are not refunded.'
};
function versionOneDraft(clubId,mode) {
  const defaults={...getClubInfoDefaults(clubId,mode),parentViewing:previousViewing[clubId][mode]};
  if(mode==='offer')defaults.refundPolicy=previousOfferRefunds[clubId];
  if(clubId==='fulham')defaults.whatToBring='There is no uniform to buy. A comfortable T-shirt with shorts or leggings is suitable; a leotard is optional. Tie long hair back, remove jewellery and bring water.';
  return {subject:'Saved subject',campaign:{...baseCampaign,...defaults},clubInfo:{version:1,clubId,mode,defaults},annualMembershipReminder:false};
}

test('first-term terms apply the SWL and Fulham cancellation fee while preserving Apex policy',()=>{
  for(const id of ['swl','fulham']) {
    const policy=getClubInfoDefaults(id,'offer').refundPolicy;
    assert.match(policy,/do not offer trial sessions/);
    assert.match(policy,/cancel and we will refund all classes you have yet to attend in that first term, minus a £40 cancellation fee/);
    assert.ok(!policy.includes('commitment-free'));
  }
  for(const club of CLUBS.filter(c=>['apex','apexdance'].includes(c.id))){
    const offer=getClubInfoDefaults(club.id,'offer');
    assert.match(offer.refundPolicy,/first term is commitment-free/);
    assert.match(offer.refundPolicy,/not to continue for any reason during the first term/);
    assert.match(offer.refundPolicy,/refund all remaining classes that have not yet been attended/);
    assert.ok(!/written notice|missed classes|personal reasons|cannot offer trial|discretion/i.test(offer.refundPolicy));
  }
  const clothing=getClubInfoDefaults('fulham','offer').whatToBring;
  assert.match(clothing,/recommend.*T-shirt.*shorts or leggings, or a leotard/);
  assert.ok(!clothing.includes('no uniform'));
  for(const word of ['hair','jewellery','water'])assert.ok(clothing.includes(word));
});

test('version 1 saved auto-defaults upgrade to current club/mode wording without changing campaign details',()=>{
  assert.ok(CLUB_INFO_VERSION>1);
  for(const club of CLUBS)for(const mode of ['renewal','offer']){
    const old=versionOneDraft(club.id,mode),snapshot=JSON.stringify(old);
    const upgraded=migrateClubInfo(club.id,mode,old),expected=getClubInfoDefaults(club.id,mode);
    assert.equal(JSON.stringify(old),snapshot,'never mutate the saved input');
    for(const key of ['parentViewing','refundPolicy','whatToBring','paymentInstructions','membershipNote','membershipUrl','location','mapUrl','uniformUrl'])assert.equal(upgraded.campaign[key],expected[key],club.id+' '+mode+' '+key);
    assert.equal(upgraded.subject,old.subject);assert.equal(upgraded.campaign.deadline,old.campaign.deadline);assert.deepEqual(upgraded.campaign.classes,old.campaign.classes);
    assert.equal(upgraded.clubInfo.version,CLUB_INFO_VERSION);assert.deepEqual(upgraded.clubInfo.defaults,expected);
    assert.deepEqual(migrateClubInfo(club.id,mode,JSON.parse(JSON.stringify(upgraded))),upgraded,'upgrade is idempotent');
  }
});

test('version upgrades preserve custom wording and intentionally cleared fields, including whitespace',()=>{
  for(const club of CLUBS)for(const mode of ['renewal','offer']){
    const old=versionOneDraft(club.id,mode);
    Object.assign(old.campaign,{parentViewing:'My private viewing arrangement',refundPolicy:'',whatToBring:'  ',paymentInstructions:'My saved payment wording'});
    const upgraded=migrateClubInfo(club.id,mode,old);
    for(const key of ['parentViewing','refundPolicy','whatToBring','paymentInstructions'])assert.equal(upgraded.campaign[key],old.campaign[key]);
    const editedAgain={...upgraded,campaign:{...upgraded.campaign,parentViewing:''}};
    assert.equal(migrateClubInfo(club.id,mode,editedAgain).campaign.parentViewing,'');
  }
  const incomplete=versionOneDraft('fulham','offer');delete incomplete.campaign.parentViewing;delete incomplete.clubInfo.defaults.parentViewing;
  assert.equal(migrateClubInfo('fulham','offer',incomplete).campaign.parentViewing,getClubInfoDefaults('fulham','offer').parentViewing,'a genuinely missing field can receive its initial default');
});

test('version upgrade retains annual BG reminder choice and never inserts it into ordinary renewal',()=>{
  const off=versionOneDraft('apex','renewal');
  assert.equal(migrateClubInfo('apex','renewal',off).campaign.membershipNote,'');
  const on=setAnnualMembershipReminder('apex','renewal',{},true);
  on.clubInfo.version=1;on.clubInfo.defaults.parentViewing=previousViewing.apex.renewal;on.campaign.parentViewing=previousViewing.apex.renewal;
  const upgraded=migrateClubInfo('apex','renewal',on);
  assert.equal(upgraded.annualMembershipReminder,true);assert.equal(upgraded.campaign.membershipNote,on.campaign.membershipNote);assert.equal(upgraded.campaign.membershipUrl,on.campaign.membershipUrl);
  assert.equal(upgraded.campaign.parentViewing,getClubInfoDefaults('apex','renewal').parentViewing);
});

test('SWL offers upgrade unchanged membership wording to the £40-inclusive total and preserve custom arrangements',()=>{
  const defaults={...getClubInfoDefaults('swl','offer'),membershipNote:'The price includes IGA membership.'};
  const old={campaign:{...baseCampaign,...defaults},clubInfo:{version:2,clubId:'swl',mode:'offer',defaults}};
  assert.equal(migrateClubInfo('swl','offer',old).campaign.membershipNote,getClubInfoDefaults('swl','offer').membershipNote);
  for(const membershipNote of ['Membership already paid',''])assert.equal(migrateClubInfo('swl','offer',{...old,campaign:{...old.campaign,membershipNote}}).campaign.membershipNote,membershipNote);
});
