import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import { readFile } from 'node:fs/promises';
import { buildStandalone } from '../scripts/build-standalone.mjs';
globalThis.fetch = async url => new Response(await readFile(url, 'utf8'));
const { CLUBS, generateScript, renderPreview } = await import('../dist/engine.js');
const { validateCampaign, getClassSchedule } = await import('../dist/campaigns.js');
const prefixes = { swl: 'Swl', fulham: 'Fulham', apex: 'Apex', apexdance: 'ApexDance' };
const campaign = {
  bankAccountName: 'Test Club', bankSortCode: '00-00-00', bankAccountNumber: '00000000',
  termName: 'Example term', startDate: '2028-04-03', endDate: '2028-04-30', excludedDates: ['2028-04-17'], deadline: '2028-03-20',
  classes: [
    { id: 'monday', name: 'Monday beginners', fee: '100', paymentUrl: 'https://example.com/monday', sessions: [{ weekday: 1, startTime: '17:00', endTime: '17:45' }] },
    { id: 'combined', name: 'Combined programme', fee: '320.50', paymentUrl: 'https://example.com/combined', sessions: [{ weekday: 3, startTime: '17:00', endTime: '19:00' }, { weekday: 6, startTime: '14:30', endTime: '17:00' }], feeNote: 'One total fee covers both weekly sessions.' }
  ],
  additionalInfo: 'Please reply with any questions.', membershipNote: '', refundPolicy: '', whatToBring: '', location: '', mapUrl: '', uniformUrl: '', parentViewing: '', informationUrl: 'https://example.com/information'
};
const config = mode => ({ mode, subject: '{{term}}: {{class}} for {{child}}', body: 'Hello {{parent}}.\n\nDetails for {{child}} at {{club}} are below.', previewClassId: 'combined', campaign: mode === 'offer' ? { ...campaign, deadline: '', offerExpiryHours: '72' } : campaign });

function runHarness(source, { answer = '2', cancel = false, changeSelection = false, selection = [[2, 3]], lockAvailable = true } = {}) {
  const rows = [['Childs Name','Email','Parents Name','Email Status','Review'], ['Alex','alex@example.com','Pat','Email sent — earlier',''], ['Taylor','taylor@example.com','Sam','Sending — interrupted','']];
  const events = [], sent = [], alerts = [];
  let activeSelection = selection;
  let currentRow, lockHeld = false;
  const sheet = {
    getLastRow: () => rows.length, getLastColumn: () => 5, getMaxColumns: () => 26,
    isRowHiddenByUser: () => false, isRowHiddenByFilter: () => false,
    getRange(row,col,height=1,width=1) {
      return {
        getDisplayValues: () => Array.from({length:height},(_,r)=>Array.from({length:width},(_,c)=>rows[row-1+r]?.[col-1+c] || '')),
        setValue(value) { assert.ok(lockHeld); rows[row-1][col-1]=value; if(value.startsWith('Sending'))currentRow=row;events.push(['write',row,value]);return this; },
        setBackground() { return this; }
      };
    }
  };
  const ss = { getActiveSheet: () => sheet, getSelection: () => ({getActiveRangeList: () => ({getRanges:()=>activeSelection.map(([first,last])=>({getRow:()=>first,getLastRow:()=>last}))})}), toast: message => events.push(['toast',message]) };
  const ui = { Button: {OK:'OK',CANCEL:'CANCEL'}, ButtonSet: {OK_CANCEL:'OK_CANCEL'},
    prompt(title,choices) { assert.equal(lockHeld,false,'the class prompt must precede lock acquisition'); events.push(['prompt',title,choices]); if(changeSelection)activeSelection=[[3,3]];return {getSelectedButton:()=>cancel?'CANCEL':'OK',getResponseText:()=>answer}; },
    alert(message) { assert.equal(lockHeld,false,'dialogs must not suspend an acquired document lock'); alerts.push(message); }
  };
  const blob={copyBlob(){return this;}};
  const context=vm.createContext({console:{log(){}}, SpreadsheetApp:{getActiveSpreadsheet:()=>ss,getUi:()=>ui,flush(){}},LockService:{getDocumentLock:()=>({tryLock:()=>{events.push(['lock']);lockHeld=lockAvailable;return lockAvailable;},releaseLock:()=>{lockHeld=false;events.push(['unlock']);}})},MailApp:{getRemainingDailyQuota:()=>100,sendEmail:(email,subject,plainBody,options)=>{assert.ok(lockHeld);sent.push({row:currentRow,email,subject,plainBody,...options});}},Utilities:{base64Decode:value=>Buffer.from(value,'base64'),newBlob:()=>blob,formatDate:()=> '01/01/2028 12:00'}});
  vm.runInContext(source,context);
  return { context, rows, sent, events, alerts };
}

for (const club of CLUBS) for (const mode of ['renewal','offer']) {
  test(`${club.name} ${mode}: exact preview/generated HTML parity with full class details`, async () => {
    const options=config(mode);
    const script=await generateScript(club.id,options);
    assert.doesNotThrow(()=>new vm.Script(script));
    assert.ok(!script.includes('GmailApp'));
    const context=vm.createContext({});
    vm.runInContext(script,context);
    vm.runInContext('selectedCampaignClass_ = EMAIL_CAMPAIGN.campaign.classes[1]',context);
    const names={parent:'Pat <&>',child:'Alex "&"'};
    const actual=context[`build${prefixes[club.id]}Email_`](names.parent,names.child);
    const preview=await renderPreview(club.id,options,names);
    const b64=script.match(new RegExp(`const ${club.id.toUpperCase()}_LOGO_BASE64 = ["']([^"']+)`))[1];
    assert.equal(preview,actual.htmlBody.replace(`cid:${club.id}Logo`,`data:${club.logoMime};base64,${b64}`));
    assert.ok(actual.plainBody.includes('Combined programme'));
    assert.ok(actual.plainBody.includes('Total weeks: 4'));
    assert.equal((actual.plainBody.match(/Total term fee: £320.50/g)||[]).length,1);
    assert.ok(!actual.plainBody.includes('Wednesday: 17:00–19:00'));
    assert.ok(!actual.plainBody.includes('Saturday: 14:30–17:00'));
    assert.ok(actual.plainBody.includes('Term dates: 3 April 2028 – 30 April 2028'));
    assert.ok(!actual.plainBody.includes('Term: Example term'));
    assert.ok(!actual.plainBody.includes('8 sessions across'));
    const redDeadline = '<span style="color:#b91c1c;font-weight:700;"><strong>Renew by:</strong> 20 March 2028</span>';
    assert.equal(preview.includes(redDeadline), mode === 'renewal');
    assert.ok(preview.includes('Pat &lt;&amp;&gt;'));
    assert.ok(!preview.includes('__CLUB_CAMPAIGN_BODY_SLOT__'));
    assert.ok(actual.plainBody.includes(mode==='offer'?'72 hours from receiving this email':'20 March 2028'));
  });
  if (!(club.id === 'swl' && mode === 'renewal')) test(`${club.name} ${mode}: class chooser drives sequential selected rows and allows manual resend`,async()=>{
    const script=await generateScript(club.id,config(mode));
    const h=runHarness(script,{selection:[[2,3],[2,2]]});
    h.context[`sendSelected${prefixes[club.id]}Emails`]();
    assert.deepEqual(h.sent.map(mail=>mail.row),[2,3]);
    for(const mail of h.sent){assert.ok(mail.plainBody.includes(club.id === 'fulham' ? 'Bank transfer (BACS)' : 'https://example.com/combined'));assert.ok(!mail.plainBody.includes('https://example.com/monday'));assert.equal(mail.name,club.name);}
    h.context[`sendSelected${prefixes[club.id]}Emails`]();
    assert.equal(h.sent.length,4,'old and new sent statuses do not block a later manual invocation');
    assert.ok(h.events.findIndex(event=>event[0]==='prompt')<h.events.findIndex(event=>event[0]==='lock'));
  });
}

test('class prompt cancellation and invalid choices perform no writes or sends',async()=>{
  const script=await generateScript('apex',config('renewal'));
  for(const params of [{cancel:true},{answer:'1x'},{answer:'1.5'},{answer:'0'},{answer:'3'},{answer:'-1'}]){
    const h=runHarness(script,params);const before=JSON.stringify(h.rows);
    h.context.sendSelectedApexEmails();
    assert.equal(h.sent.length,0);assert.equal(JSON.stringify(h.rows),before);
    assert.ok(!h.events.some(event=>event[0]==='lock'||event[0]==='write'));
  }
});

test('class chooser lists a schedule once and keeps combined session times visible',async()=>{
  const options=config('renewal');
  options.campaign={...options.campaign,classes:[{...campaign.classes[0],name:'Beginners — Monday 17:00–17:45'},campaign.classes[1]]};
  const h=runHarness(await generateScript('apex',options),{cancel:true});
  h.context.sendSelectedApexEmails();
  const choices=h.events.find(event=>event[0]==='prompt')[2];
  assert.equal((choices.match(/Monday 17:00–17:45/g)||[]).length,1);
  assert.ok(choices.includes('Wednesday 17:00–19:00 + Saturday 14:30–17:00'));
});

test('sender keeps original selected row snapshot if selection changes during the prompt',async()=>{
  const h=runHarness(await generateScript('apex',config('offer')),{selection:[[2,2]],changeSelection:true,answer:'1'});
  h.context.sendSelectedApexEmails();
  assert.deepEqual(h.sent.map(mail=>mail.row),[2]);
  assert.ok(h.sent[0].plainBody.includes('https://example.com/monday'));
  assert.ok(h.sent[0].plainBody.includes('No class on: 17 April 2028'));
  assert.ok(h.sent[0].plainBody.includes('Total weeks: 3'));
  assert.ok(h.sent[0].plainBody.includes('Total term fee: £100.00'),'exclusions never prorate the configured fee');
});

test('campaign dry-run chooses a class but leaves cells and emails untouched',async()=>{
  const h=runHarness(await generateScript('apex',config('renewal')));const before=JSON.stringify(h.rows);
  h.context.checkSelectedApexRows();
  assert.equal(h.sent.length,0);assert.equal(JSON.stringify(h.rows),before);assert.ok(h.alerts.at(-1).includes('2 eligible selected rows'));
});

test('campaign cannot send when another invocation holds the document lock',async()=>{
  const h=runHarness(await generateScript('swl',config('offer')),{lockAvailable:false});
  h.context.sendSelectedSwlEmails();assert.equal(h.sent.length,0);assert.ok(!h.events.some(event=>event[0]==='write'));
});

test('campaign validation never supplies historic dates, fees, deadlines or payment links',()=>{
  assert.throws(()=>validateCampaign('renewal',{}));
  for(const field of ['termName','startDate','endDate','deadline'])assert.throws(()=>validateCampaign('renewal',{...campaign,[field]:''}));
  for(const field of ['fee','paymentUrl'])assert.throws(()=>validateCampaign('renewal',{...campaign,classes:[{...campaign.classes[0],[field]:''}]}));
  assert.throws(()=>validateCampaign('offer',{...campaign,offerExpiryHours:48}),'offer cannot have both fixed and rolling deadline');
  assert.throws(()=>validateCampaign('offer',{...campaign,deadline:'',offerExpiryHours:''}));
  for(const key of ['refundPolicy','membershipNote','whatToBring','parentViewing'])assert.equal(validateCampaign('renewal',campaign)[key],'');
});

test('advanced text, names, class labels and optional sections are escaped as data',async()=>{
  const dangerous='` ${globalThis.injected=true} </script><img src=x onerror=alert(1)> & "';
  const options={...config('offer'),subject:'For {{child}} — {{class}}',body:dangerous+' {{parent}}',campaign:{...config('offer').campaign,termName:'<Term>',additionalInfo:dangerous,membershipNote:dangerous,classes:[{...campaign.classes[0],name:dangerous} ]},previewClassId:'monday'};
  const script=await generateScript('apexdance',options);const context=vm.createContext({});vm.runInContext(script,context);vm.runInContext('selectedCampaignClass_ = EMAIL_CAMPAIGN.campaign.classes[0]',context);
  const actual=context.buildApexDanceEmail_('<Parent>','Alex');
  assert.equal(context.injected,undefined);assert.ok(actual.htmlBody.includes('&lt;/script&gt;&lt;img'));assert.ok(!actual.htmlBody.includes('<img src=x'));
  assert.ok(actual.plainBody.includes(dangerous));
});

test('standalone and module app generate identical advanced scripts and previews',async()=>{
  const {engineSource}=await buildStandalone();const context=vm.createContext({URL});vm.runInContext(engineSource+'\nglobalThis.api={generateScript,renderPreview};',context);
  for(const club of CLUBS){const options=config('renewal');assert.equal(await context.api.generateScript(club.id,options),await generateScript(club.id,options));assert.equal(await context.api.renderPreview(club.id,options),await renderPreview(club.id,options));}
});

const reminderMessage={
  subject:'A gentle reminder to renew for {{term}} — {{club}}',
  body:'Just a gentle reminder to renew {{child}}’s place for {{term}}. The class details, renewal deadline and payment link are below.\n\nIf you’ve already renewed, thank you—please ignore this reminder.'
};
for(const club of CLUBS.filter(club => club.id !== 'swl'))test(`${club.name}: Renewal Reminder shares campaign details and chooser while rendering its own copy and resending selected rows`,async()=>{
  const main=config('renewal'),options={...main,renewalVariant:'reminder',...reminderMessage};
  const source=await generateScript(club.id,options);assert.ok(source.includes('// RENEWAL REMINDER'));
  const h=runHarness(source,{selection:[[2,3],[2,2]]});assert.equal(h.sent.length,0,'copying/loading does not send');
  assert.equal(vm.runInContext('EMAIL_CAMPAIGN.renewalVariant',h.context),'reminder');
  assert.deepEqual(JSON.parse(vm.runInContext('JSON.stringify(EMAIL_CAMPAIGN.campaign)',h.context)),validateCampaign('renewal',main.campaign,club.id));
  h.context[`sendSelected${prefixes[club.id]}Emails`]();
  assert.deepEqual(h.sent.map(mail=>mail.row),[2,3]);
  const mail=h.sent[0];assert.ok(mail.subject.includes('A gentle reminder to renew'));assert.ok(mail.plainBody.includes('Just a gentle reminder to renew Alex’s place'));assert.ok(mail.plainBody.includes('please ignore this reminder.'));
  assert.ok(mail.plainBody.includes('Total term fee: £320.50'));assert.ok(mail.plainBody.includes(club.id === 'fulham' ? 'Bank transfer (BACS)' : 'https://example.com/combined'));assert.ok(mail.plainBody.includes('Renew by: 20 March 2028'));
  const preview=await renderPreview(club.id,options,{parent:'Pat',child:'Alex'}),b64=source.match(new RegExp(`const ${club.id.toUpperCase()}_LOGO_BASE64 = ["']([^"']+)`))[1];
  assert.equal(preview,mail.htmlBody.replace(`cid:${club.id}Logo`,`data:${club.logoMime};base64,${b64}`));
  const mainPreview=await renderPreview(club.id,main,{parent:'Pat',child:'Alex'});
  assert.equal(preview.slice(preview.indexOf('<strong>Class:')),mainPreview.slice(mainPreview.indexOf('<strong>Class:')),'class card, payment and club information remain identical');
  h.context[`sendSelected${prefixes[club.id]}Emails`]();assert.equal(h.sent.length,4,'a new manual reminder still sends rows marked Sent');
});

test('Renewal variant defaults to main, rejects invalid renewal choices, and does not change Basic or Offer',async()=>{
  const source=await generateScript('swl',config('renewal')),context=vm.createContext({});vm.runInContext(source,context);
  assert.equal(vm.runInContext('EMAIL_CAMPAIGN.renewalVariant',context),'main');assert.ok(source.includes('// MAIN RENEWAL'));
  for(const renewalVariant of ['other','',false]){
    const options={...config('renewal'),renewalVariant};
    await assert.rejects(()=>generateScript('swl',options),/Choose Main renewal or Reminder/);
    await assert.rejects(()=>renderPreview('swl',options),/Choose Main renewal or Reminder/);
  }
  const basic={subject:'Update',body:'Hello'};assert.equal(await generateScript('swl',{...basic,renewalVariant:'reminder'}),await generateScript('swl',basic));
  assert.equal(await generateScript('swl',{...config('offer'),renewalVariant:'reminder'}),await generateScript('swl',config('offer')));
});

test('offline standalone app preserves Reminder preview and generated-script parity',async()=>{
  const {engineSource}=await buildStandalone(),context=vm.createContext({URL});vm.runInContext(engineSource+'\nglobalThis.api={generateScript,renderPreview};',context);
  for(const club of CLUBS){
    const options={...config('renewal'),renewalVariant:'reminder',...reminderMessage};
    assert.equal(await context.api.generateScript(club.id,options),await generateScript(club.id,options));
    assert.equal(await context.api.renderPreview(club.id,options),await renderPreview(club.id,options));
  }
});

for (const club of CLUBS) test(`${club.name}: renewal viewing week replaces legacy wording and removes location in generated mail`, async () => {
  const options = {...config('renewal'), campaign: {...campaign, parentViewingWeek: '2028-04-24', parentViewing: 'OLD VIEWING WORDING', location: 'OLD VENUE ADDRESS', mapUrl: 'https://example.com/old-map'}};
  const script = await generateScript(club.id, options);
  const context = vm.createContext({}); vm.runInContext(script, context);
  vm.runInContext('selectedCampaignClass_ = EMAIL_CAMPAIGN.campaign.classes[1]', context);
  const mail = context[`build${prefixes[club.id]}Email_`]('Pat', 'Alex');
  assert.match(mail.plainBody, /Week of 24 April 2028/);
  for (const text of ['OLD VIEWING WORDING', 'OLD VENUE ADDRESS', 'https://example.com/old-map', 'Google Maps']) assert.ok(!mail.plainBody.includes(text) && !mail.htmlBody.includes(text));
  const blank = await renderPreview(club.id, {...options, campaign: {...options.campaign, parentViewingWeek: ''}});
  assert.ok(!blank.includes('Parents’ viewing') && !blank.includes('OLD VIEWING WORDING'));
  assert.throws(() => validateCampaign('renewal', {...options.campaign, parentViewingWeek: '2028-02-30'}), /date|viewing/i);
});
