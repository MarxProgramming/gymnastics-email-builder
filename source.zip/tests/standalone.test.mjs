import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import { readFile } from 'node:fs/promises';
import { buildStandalone } from '../scripts/build-standalone.mjs';
globalThis.fetch = async url => new Response(await readFile(url, 'utf8'));
const moduleEngine = await import('../dist/engine.js');

test('standalone app has embedded assets and valid JavaScript', async () => {
  const { html, engineSource, applicationSource } = await buildStandalone();
  assert.ok(!/<script[^>]+src=/.test(html));
  assert.ok(!/<link[^>]+href=["']styles\.css/.test(html));
  assert.equal((html.match(/<script>/g) || []).length, 1);
  assert.equal((html.match(/<\/script>/g) || []).length, 1);
  assert.ok(!engineSource.includes('fetch('));
  assert.ok(!engineSource.includes('import.meta'));
  assert.doesNotThrow(() => new vm.Script(`(function () {${engineSource}\n${applicationSource}\n})();`));
});

test('standalone preview and downloaded scripts match the module app for every club', async () => {
  const { engineSource } = await buildStandalone();
  const context = vm.createContext({ URL, fetch: () => { throw new Error('Offline app must not fetch templates'); } });
  vm.runInContext(engineSource + '\nglobalThis.api = {CLUBS, loadTemplate, generateScript, renderPreview};', context);
  const options = { subject: 'Test for {{child}}', body: 'Hello {{parent}}.\n\nLiteral `quotes`, ${1+1}, </script> and \\ characters.', buttonText: 'View details', buttonUrl: 'https://example.com/?a=1&b=2' };
  const names = { parent: 'Parent & child', child: 'Alex <&>' };
  for (const club of moduleEngine.CLUBS) {
    assert.equal(await context.api.loadTemplate(club.id), await moduleEngine.loadTemplate(club.id));
    assert.equal(await context.api.generateScript(club.id, options), await moduleEngine.generateScript(club.id, options));
    assert.equal(await context.api.renderPreview(club.id, options, names), await moduleEngine.renderPreview(club.id, options, names));
    assert.ok(context.api.CLUBS.find(item => item.id === club.id).logo.startsWith('data:image/'));
  }
});
