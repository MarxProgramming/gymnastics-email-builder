import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import { readFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';

const nativeFetch = globalThis.fetch;
globalThis.fetch = async url => {
  if (String(url).startsWith('file:')) return new Response(await readFile(url, 'utf8'));
  return nativeFetch(url);
};
const { CLUBS, loadTemplate, generateScript, renderPreview, validateContent } = await import('../dist/engine.js');
const options = { subject: 'Club update for {{child}}', body: 'Thank you, {{parent}}.\n\nWe look forward to seeing {{child}} at gymnastics.', buttonText: 'Read more', buttonUrl: 'https://example.com/details?a=1&b=2' };
const prefixes = { swl: 'Swl', fulham: 'Fulham', apex: 'Apex', apexdance: 'ApexDance' };
const normalise = value => String(value).toLowerCase().replace(/['’]/g, '').trim();

function harness(source, { rows, ranges = [[2, rows.length]], quota = 100, hidden = [], filtered = [], locked = false, failRows = [], statusFailure = false, insertFailure = false, now = () => 1000, maxColumns = Math.max(...rows.map(row => row.length)) } = {}) {
  const data = rows.map(row => [...row]);
  const events = [], sent = [], toasts = [], alerts = [];
  let unlocked = false;
  let currentSendingRow;
  const sheet = {
    getLastRow: () => data.length,
    getLastColumn: () => Math.max(0, ...data.map(row => row.reduce((last, value, index) => String(value ?? '') ? index + 1 : last, 0))),
    getMaxColumns: () => maxColumns,
    insertColumnsAfter: (after, count) => { if (insertFailure) throw new Error('Sheet is protected'); assert.equal(after, maxColumns); maxColumns += count; events.push(['insertColumns', after, count]); },
    isRowHiddenByUser: row => hidden.includes(row),
    isRowHiddenByFilter: row => filtered.includes(row),
    getRange(row, column, height = 1, width = 1) {
      return {
        getDisplayValues: () => {
          events.push(['read', row]);
          return Array.from({ length: height }, (_, offset) => Array.from({ length: width }, (_, col) => data[row - 1 + offset]?.[column - 1 + col] ?? ''));
        },
        setValue(value) {
          assert.ok(column <= maxColumns, 'writes must stay within the sheet grid');
          if (statusFailure && /^Email sent|^Sent;/.test(value)) throw new Error('Status write failed');
          data[row - 1][column - 1] = value;
          if (value.startsWith('Sending')) currentSendingRow = row;
          events.push(['status', row, value]);
          return this;
        },
        setBackground: function () { return this; }
      };
    }
  };
  const ss = {
    getActiveSheet: () => sheet,
    getSelection: () => ({ getActiveRangeList: () => ranges === null ? null : ({ getRanges: () => ranges.map(([first, last]) => ({ getRow: () => first, getLastRow: () => last })) }) }),
    toast: (...args) => toasts.push(args)
  };
  const blob = { copyBlob() { return this; } };
  class TestDate extends Date { static now() { return now(); } }
  const context = vm.createContext({
    Date: TestDate,
    console: { log: value => events.push(['log', value]) },
    SpreadsheetApp: { getActiveSpreadsheet: () => ss, flush: () => events.push(['flush']), getUi: () => ({ alert: message => { assert.ok(unlocked, 'result dialogs must be shown after releasing the document lock'); alerts.push(message); } }) },
    LockService: { getDocumentLock: () => ({ tryLock: () => !locked, releaseLock: () => { unlocked = true; } }) },
    Utilities: { base64Decode: value => Buffer.from(value, 'base64'), newBlob: () => blob, formatDate: () => '03/11/2026 12:00' },
    MailApp: { getRemainingDailyQuota: () => quota, sendEmail: (email, subject, plainBody, config) => {
      events.push(['send', currentSendingRow]);
      if (failRows.includes(currentSendingRow)) throw new Error('Simulated mail failure');
      sent.push({ row: currentSendingRow, email, subject, plainBody, ...config });
    } }
  });
  vm.runInContext(source, context);
  return { context, data, sent, events, toasts, alerts, get unlocked() { return unlocked; } };
}

const headers = ['Childs Name', 'Parents Name', 'Email', 'Email Status', 'Review'];
const person = (child, extra = {}) => [child, 'Parent ' + child, 'family@example.com', extra.status || '', extra.review || ''];

for (const club of CLUBS) {
  const prefix = prefixes[club.id];
  test(`${club.name}: preserves the master except content and the send-only mail service`, async () => {
    const source = await loadTemplate(club.id);
    const generated = await generateScript(club.id, options);
    const before = source.indexOf(`function ${club.id}EmailContent_`);
    const marker = '// MENU AND SELECTED-ROW SENDER';
    assert.equal(generated.slice(0, before), source.slice(0, before));
    assert.equal(generated.slice(generated.indexOf(marker)), source.slice(source.indexOf(marker)).replace(
      'GmailApp.sendEmail(person.email,email.subject,email.plainBody,{',
      'MailApp.sendEmail(person.email,email.subject,email.plainBody,{'));
    assert.ok(/MailApp\.sendEmail\(\s*person\.email/.test(generated));
    assert.ok(!generated.includes('GmailApp'));
    assert.ok(!generated.includes('mail.google.com'));
    assert.doesNotThrow(() => new vm.Script(generated));
  });

  test(`${club.name}: preview matches actual generated email, including exact logo`, async () => {
    const generated = await generateScript(club.id, options);
    const context = vm.createContext({});
    vm.runInContext(generated, context);
    const names = { parent: '<Parent & "guardian">', child: 'Taylor <&>' };
    const actual = context[`build${prefix}Email_`](names.parent, names.child);
    const preview = await renderPreview(club.id, options, names);
    const b64 = generated.match(new RegExp(`const ${club.id.toUpperCase()}_LOGO_BASE64 = ["']([^"']+)`))[1];
    assert.equal(preview, actual.htmlBody.replace(`cid:${club.id}Logo`, `data:${club.logoMime};base64,${b64}`));
    assert.ok(preview.includes('Taylor &lt;&amp;&gt;'));
    assert.ok(preview.includes('&lt;Parent &amp; &quot;guardian&quot;&gt;'));
    assert.ok(preview.includes('https://example.com/details?a=1&amp;b=2'));
    assert.ok(actual.plainBody.includes('Taylor <&>'));
  });

  test(`${club.name}: deduplicates selections and marks each row before reading the next`, async () => {
    const h = harness(await generateScript(club.id, options), {
      rows: [headers, person('Alex'), person('Taylor'), person('Finley')],
      ranges: [[3, 4], [1, 3], [3, 3]]
    });
    h.context[`sendSelected${prefix}Emails`]();
    assert.deepEqual(h.sent.map(email => email.row), [2, 3, 4]);
    assert.equal(h.sent[0].name, club.name);
    assert.ok(h.sent[0].inlineImages[`${club.id}Logo`]);
    assert.ok(h.sent[0].plainBody.includes('Alex'));
    assert.equal(h.data[1][3], 'Email sent — 03/11/2026 12:00');
    assert.ok(h.unlocked);
    const sentRow2 = h.events.findIndex(e => e[0] === 'status' && e[1] === 2 && e[2].startsWith('Email sent'));
    const readRow3 = h.events.findIndex(e => e[0] === 'read' && e[1] === 3);
    assert.ok(sentRow2 < readRow3);
    const sendingRow2 = h.events.findIndex(e => e[0] === 'status' && e[1] === 2 && e[2].startsWith('Sending'));
    const sendRow2 = h.events.findIndex(e => e[0] === 'send' && e[1] === 2);
    assert.ok(sendingRow2 < sendRow2);
    h.context[`sendSelected${prefix}Emails`]();
    assert.equal(h.sent.length, 6, 'a new manual invocation sends the same selected rows again');
  });

  test(`${club.name}: ignores sent status but respects review, hidden rows and invalid recipients`, async () => {
    const h = harness(await generateScript(club.id, options), { rows: [headers,
      person('Already sent', { status: 'Email sent' }),
      person('Review', { review: 'Check details' }),
      person('Hidden'), person('Filtered'), ['', 'Parent', 'family@example.com', '', ''],
      ['Child', '', 'family@example.com', '', ''], ['Child', 'Parent', 'bad-email', '', ''],
      person('Eligible')], hidden: [4], filtered: [5] });
    h.context[`sendSelected${prefix}Emails`]();
    assert.deepEqual(h.sent.map(email => email.row), [2, 9]);
    assert.ok(h.toasts.at(-1)[0].includes('Skipped: 6'));
  });

  test(`${club.name}: every existing status is eligible for a new manual send`, async () => {
    const statuses = ['Email sent — earlier', 'Sending — check Sent mail if interrupted', 'Check Sent mail before retrying: earlier error', 'Arbitrary nonblank value'];
    const rows = [headers, ...statuses.map((status, index) => person('Child ' + index, { status }))];
    const h = harness(await generateScript(club.id, options), { rows, ranges: [[2, 5], [3, 4]] });
    h.context[`checkSelected${prefix}Rows`]();
    assert.ok(h.alerts.at(-1).includes('4 eligible selected rows'));
    assert.deepEqual(h.data, rows, 'checking does not erase or alter previous results');
    h.context[`sendSelected${prefix}Emails`]();
    assert.deepEqual(h.sent.map(email => email.row), [2, 3, 4, 5], 'each row is sent once despite overlapping selection and any old status');
    for (const row of h.data.slice(1)) assert.equal(row[3], 'Email sent — 03/11/2026 12:00');
  });

  test(`${club.name}: recognises reordered headings with apostrophes and case differences`, async () => {
    const h = harness(await generateScript(club.id, options), { rows: [
      ['Extra', 'EMAIL', 'Review', "Child’s Name", 'Email Status', " Parent's Name "],
      ['Unrelated', 'family@example.com', '', 'Joseph', '', 'Joseph']
    ] });
    h.context[`sendSelected${prefix}Emails`]();
    assert.equal(h.sent.length, 1);
    assert.ok(h.data[1][4].startsWith('Email sent'));
  });

  test(`${club.name}: dry run neither sends nor modifies rows`, async () => {
    const rows = [headers, person('Alex'), person('Skip', { review: 'Hold' })];
    const h = harness(await generateScript(club.id, options), { rows });
    h.context[`checkSelected${prefix}Rows`]();
    assert.equal(h.sent.length, 0);
    assert.deepEqual(h.data, rows);
    assert.ok(h.toasts.at(-1)[0].includes('1 eligible selected rows; 1 skipped'));
  });

  test(`${club.name}: quota exhaustion leaves the remaining row unsent`, async () => {
    const h = harness(await generateScript(club.id, options), { rows: [headers, person('Alex'), person('Taylor')], quota: 1 });
    h.context[`sendSelected${prefix}Emails`]();
    assert.equal(h.sent.length, 1);
    assert.equal(h.data[2][3], '');
    assert.ok(h.toasts.at(-1)[0].includes('allowance is used up'));
  });

  test(`${club.name}: failed send is marked, retried only on a new manual invocation`, async () => {
    const h = harness(await generateScript(club.id, options), { rows: [headers, person('Alex'), person('Taylor')], failRows: [2] });
    h.context[`sendSelected${prefix}Emails`]();
    assert.deepEqual(h.sent.map(email => email.row), [3]);
    assert.ok(h.data[1][3].startsWith('Check Sent mail before retrying:'));
    assert.equal(h.events.filter(e => e[0] === 'send' && e[1] === 2).length, 1, 'no automatic retry within an invocation');
    h.context[`sendSelected${prefix}Emails`]();
    assert.equal(h.events.filter(e => e[0] === 'send' && e[1] === 2).length, 2);
    assert.deepEqual(h.sent.map(email => email.row), [3, 3]);
  });

  test(`${club.name}: sparse C/D/W register works without Review or Email Status`, async () => {
    const rows = Array.from({ length: 105 }, () => Array(26).fill(''));
    rows[0][0] = 'Autumn register'; rows[0][1] = 'Season';
    rows[0][2] = 'Childs Name'; rows[0][3] = 'Email'; rows[0][5] = 'Capacity';
    for (let column = 6; column < 22; column++) rows[0][column] = 'Attendance ' + (column - 5);
    rows[0][22] = 'Parents Name'; rows[0][23] = 'PHONE1'; rows[0][24] = 'PARENT2'; rows[0][25] = 'PHONE2';
    rows[104][2] = 'Alex Example'; rows[104][3] = 'test@example.com'; rows[104][22] = 'Pat Example'; rows[104][24] = 'Other contact';
    const h = harness(await generateScript(club.id, options), { rows, ranges: [[105, 105]], maxColumns: 26 });
    h.context[`checkSelected${prefix}Rows`]();
    assert.equal(h.sent.length, 0);
    assert.deepEqual(h.data, rows, 'dry run does not add headings, statuses or rows');
    assert.ok(h.alerts.at(-1).includes('Child: C — Childs Name'));
    assert.ok(h.alerts.at(-1).includes('Parent: W — Parents Name'));
    assert.ok(h.alerts.at(-1).includes('Recipient: D — Email'));
    assert.ok(h.alerts.at(-1).includes('currently AA'));
    assert.ok(h.alerts.at(-1).includes('1 eligible selected rows'));
    assert.ok(!h.events.some(event => event[0] === 'insertColumns'));
    h.context[`sendSelected${prefix}Emails`]();
    assert.deepEqual(h.sent.map(email => email.row), [105]);
    assert.equal(h.data[0][26], 'Email Status');
    assert.ok(h.data[104][26].startsWith('Email sent'));
    assert.deepEqual(h.data.map(row => row.slice(0, 26)), rows, 'attendance and other contact columns remain untouched');
    assert.deepEqual(h.events.filter(event => event[0] === 'insertColumns'), [['insertColumns', 26, 1]]);
    h.context[`sendSelected${prefix}Emails`]();
    assert.equal(h.sent.length, 2, 'tracking records results without preventing manual re-sending');
    assert.equal(h.events.filter(event => event[0] === 'insertColumns').length, 1, 'resending reuses the same tracking column');
  });

  test(`${club.name}: finds aliases below title rows and excludes headings from selection`, async () => {
    const h = harness(await generateScript(club.id, options), { rows: [
      ['Class register'], ['Read this first'], [],
      ['Child’s\nFirst Name', 'Parent / Guardian Name', 'Email Address', 'PARENT2'],
      ['Alex', 'Pat', 'family@example.com', 'Other contact']
    ], ranges: [[1, 5]], maxColumns: 10 });
    h.context[`sendSelected${prefix}Emails`]();
    assert.deepEqual(h.sent.map(email => email.row), [5]);
    assert.equal(h.data[3][4], 'Email Status');
    assert.equal(h.events.filter(event => event[0] === 'insertColumns').length, 0, 'uses an existing unused grid column when available');
  });

  test(`${club.name}: duplicate recipient aliases are rejected before any mutation`, async () => {
    const rows = [['Child Name', 'Parent Name', 'Email', 'Email Address'], ['Alex', 'Pat', 'first@example.com', 'second@example.com']];
    const h = harness(await generateScript(club.id, options), { rows });
    h.context[`sendSelected${prefix}Emails`]();
    assert.equal(h.sent.length, 0);
    assert.deepEqual(h.data, rows);
    assert.ok(h.alerts.at(-1).includes('Ambiguous email address headings in row 1: C (Email), D (Email Address)'));
  });
}

test('arbitrary body text cannot become executable JavaScript', async () => {
  const body = 'Literal `quotes`, ${globalThis.injected = true}, </script>, \\ and "quotes".\n\nChild: {{ child }}. Parent: {{PARENT}}. Unicode \u2028 and \u2029.';
  const source = await generateScript('swl', { subject: 'Literal ${1+1} and `quotes`', body, buttonText: '', buttonUrl: '' });
  const context = vm.createContext({});
  vm.runInContext(source, context);
  const content = context.swlEmailContent_('Parent ${1+1}', 'Child $&');
  assert.equal(context.injected, undefined);
  assert.equal(content.subject, 'Literal ${1+1} and `quotes`');
  assert.equal(content.message, body.replace('{{ child }}', () => 'Child $&').replace('{{PARENT}}', () => 'Parent ${1+1}'));
  assert.ok(context.buildSwlEmail_('Parent', 'Child').htmlBody.includes('&lt;/script&gt;'));
});

test('invalid content and unsafe links are rejected before generating a script', async () => {
  for (const patch of [
    { subject: '' }, { subject: 'Hello\nWorld' }, { subject: 'a'.repeat(241) }, { body: '   ' },
    { buttonUrl: '' }, { buttonText: '' }, { buttonUrl: 'javascript:alert(1)' },
    { buttonUrl: 'http://example.com' }, { buttonUrl: 'https://' }, { buttonUrl: 'https://example.com/"x' },
    { buttonUrl: 'https://user:password@example.com' }, { buttonUrl: 'https://example.com/a b' }
  ]) assert.throws(() => validateContent({ ...options, ...patch }));
  await assert.rejects(generateScript('unknown', options));
});

test('omitting the optional button preserves the standard footer website link', async () => {
  const preview = await renderPreview('swl', { ...options, buttonText: '', buttonUrl: '' });
  assert.ok(!preview.includes('Read more'));
  assert.ok(preview.includes('Visit our website'));
});

test('missing or duplicate headings abort without sending', async () => {
  for (const broken of [['Child', ...headers.slice(1)], [...headers, 'Email']]) {
    const h = harness(await generateScript('swl', options), { rows: [broken, person('Joseph')] });
    h.context.sendSelectedSwlEmails();
    assert.equal(h.sent.length, 0);
    assert.ok(/Could not identify|Ambiguous/.test(h.toasts.at(-1)[0]));
    assert.ok(h.unlocked);
  }
});

test('document lock prevents a concurrent sender', async () => {
  const h = harness(await generateScript('swl', options), { rows: [headers, person('Joseph')], locked: true });
  h.context.sendSelectedSwlEmails();
  assert.equal(h.sent.length, 0);
  assert.ok(h.toasts[0][0].includes('Another send is still running'));
});

test('time limit pauses before touching the next row', async () => {
  let calls = 0;
  const h = harness(await generateScript('swl', options), { rows: [headers, person('Joseph'), person('Taylor')], now: () => calls++ < 2 ? 1000 : 242000 });
  h.context.sendSelectedSwlEmails();
  assert.equal(h.sent.length, 1);
  assert.equal(h.data[2][3], '');
  assert.ok(h.toasts.at(-1)[0].includes('Paused at the time limit'));
});

test('failed status recording stops and leaves an interruption marker', async () => {
  const h = harness(await generateScript('swl', options), { rows: [headers, person('Joseph'), person('Taylor')], statusFailure: true });
  h.context.sendSelectedSwlEmails();
  assert.equal(h.sent.length, 1);
  assert.ok(h.data[1][3].startsWith('Sending — check Sent mail'));
  assert.equal(h.data[2][3], '');
  assert.ok(h.toasts.at(-1)[0].includes('could not record the result'));
  h.context.sendSelectedSwlEmails();
  assert.equal(h.events.filter(e => e[0] === 'send' && e[1] === 2).length, 2, 'a subsequent manual invocation ignores the interruption marker');
});

test('SWL and Fulham email designs, footer, helpers and embedded logos remain unchanged', async () => {
  const expected = { swl: '52739e3cc12737b15e4f4c0eea32902255bec141d23403647bea6e9c1a749cad', fulham: '33a9c0eda106c3b1f87a035e132e338fcc9110e7a686bb8a188f8050d89b65de' };
  for (const [id, hash] of Object.entries(expected)) {
    const source = await loadTemplate(id);
    assert.equal(createHash('sha256').update(source.slice(source.indexOf('// EMAIL DESIGN — LEAVE IN PLACE'))).digest('hex'), hash);
  }
});

test('all four variants retain the same canonical sequential sender', async () => {
  function sender(source, club) {
    const prefix = prefixes[club.id];
    const short = { swl: 'SWL', fulham: 'Fulham', apex: 'Apex', apexdance: 'Apex Dance' }[club.id];
    return source.slice(source.indexOf('// MENU AND SELECTED-ROW SENDER'), source.indexOf('// EMAIL DESIGN — LEAVE IN PLACE'))
      .replaceAll(club.name, 'Club Name').replaceAll(`${short} emails`, 'Club emails').replaceAll(`${short} email check`, 'Club email check').replaceAll(`${short} email results`, 'Club email results')
      .replaceAll(prefix, 'Club').replaceAll(`${club.id}Logo`, 'clubLogo').replaceAll('GmailApp.sendEmail', 'MailApp.sendEmail');
  }
  const reference = sender(await loadTemplate('swl'), CLUBS[0]);
  for (const club of CLUBS) assert.equal(sender(await loadTemplate(club.id), club), reference);
});

test('Apex gradient header uses the embedded original white mark with a solid fallback', async () => {
  const source = await loadTemplate('apex');
  const bodyAndFooter = source.slice(source.indexOf('<!-- GREETING AND MESSAGE'), source.indexOf('// ==========================================\n// HELPERS'));
  assert.equal(createHash('sha256').update(bodyAndFooter).digest('hex'), '5578c4d3fede54ede6ebd956dd6de5bd5c497fb6ff5bfc22c7993d73e8fabfb9', 'original Apex body and footer remain unchanged');
  const preview = await renderPreview('apex', options);
  const whiteLogo = await readFile(new URL('../dist/templates/apex-email.png', import.meta.url));
  assert.ok(preview.includes(`data:image/png;base64,${whiteLogo.toString('base64')}`));
  assert.ok(preview.includes('background-color:#236E80;background-image:linear-gradient('));
  assert.ok(preview.includes('bgcolor="#236E80"'));
  assert.ok(preview.includes('APEX GYMNASTICS'));
});

test('Apex Dance uses its own brand, public website and original embedded logo', async () => {
  const preview = await renderPreview('apexdance', options);
  const logo = await readFile(new URL('../dist/templates/apexdance.png', import.meta.url));
  assert.ok(preview.includes(`data:image/png;base64,${logo.toString('base64')}`));
  assert.ok(preview.includes('background-color:#1B0D35;background-image:linear-gradient('));
  assert.ok(preview.includes('border-bottom:2px solid #C8A84B'));
  assert.ok(preview.includes('https://www.apexdanceclub.co.uk'));
  assert.ok(preview.includes('The Apex Dance Club Team'));
  assert.ok(!preview.includes('Apex Gymnastics'));
  assert.ok(!preview.includes('apex-gymnastics.co.uk'));
});

test('multiple header rows, including a duplicated required heading, are rejected', async () => {
  const rows = [headers, person('Alex'), ['Child Name', 'Parent Name', 'Email Address'], person('Taylor')];
  const h = harness(await generateScript('apex', options), { rows });
  h.context.sendSelectedApexEmails();
  assert.equal(h.sent.length, 0);
  assert.deepEqual(h.data, rows);
  assert.ok(h.alerts.at(-1).includes('More than one possible heading row was found: 1, 3'));
});

test('header detection includes row20 but does not scan row21', async () => {
  for (const headerRow of [20, 21]) {
    const rows = Array.from({ length: headerRow + 1 }, () => []);
    rows[headerRow - 1] = ['Child Name', 'Parent Name', 'Email Address'];
    rows[headerRow] = ['Alex', 'Pat', 'family@example.com'];
    const h = harness(await generateScript('apex', options), { rows, ranges: [[1, headerRow + 1]] });
    h.context.checkSelectedApexRows();
    assert.deepEqual(h.data, rows);
    assert.ok(h.alerts.at(-1).includes(headerRow === 20 ? '1 eligible selected rows' : 'within the first 20 rows'));
  }
});

test('status is appended after all used data, even when it extends beyond the headings', async () => {
  const rows = [['Child Name', 'Parent Name', 'Email Address'], ['Alex', 'Pat', 'family@example.com']];
  rows[1][29] = 'Existing notes beyond the header';
  const h = harness(await generateScript('apex', options), { rows, maxColumns: 40 });
  h.context.sendSelectedApexEmails();
  assert.equal(h.data[0][30], 'Email Status');
  assert.equal(h.data[1][29], 'Existing notes beyond the header');
  assert.ok(h.data[1][30].startsWith('Email sent'));
  assert.equal(h.events.filter(event => event[0] === 'insertColumns').length, 0);
});

test('no tracking column is created when quota is exhausted or the selection is ineligible', async () => {
  for (const config of [{ quota: 0 }, { hidden: [2] }]) {
    const rows = [['Child Name', 'Parent Name', 'Email Address'], ['Alex', 'Pat', 'family@example.com']];
    const h = harness(await generateScript('apex', options), { rows, ...config });
    h.context.sendSelectedApexEmails();
    assert.equal(h.sent.length, 0);
    assert.deepEqual(h.data, rows);
    assert.equal(h.events.filter(event => event[0] === 'insertColumns').length, 0);
  }
});

test('protected tracking setup aborts before sending and reports the error', async () => {
  const rows = [['Child Name', 'Parent Name', 'Email Address'], ['Alex', 'Pat', 'family@example.com']];
  const h = harness(await generateScript('apex', options), { rows, insertFailure: true });
  h.context.sendSelectedApexEmails();
  assert.equal(h.sent.length, 0);
  assert.deepEqual(h.data, rows);
  assert.ok(h.alerts.at(-1).includes('Sheet is protected'));
});

test('dry-run dialog reports specific skip reasons and optional Review mapping', async () => {
  const h = harness(await generateScript('apex', options), { rows: [headers, person('Marked', { status: 'Sent' }), person('Review', { review: 'Hold' }), ['', 'Pat', 'family@example.com', '', ''], ['Alex', '', 'family@example.com', '', ''], ['Alex', 'Pat', 'invalid', '', '']] });
  h.context.checkSelectedApexRows();
  const dialog = h.alerts.at(-1);
  for (const reason of ['marked for Review', 'missing child name', 'missing parent name', 'invalid or missing email address']) assert.ok(dialog.includes(reason));
  assert.ok(dialog.includes('1 eligible selected rows'));
  assert.ok(!dialog.includes('already marked in Email Status'));
  assert.ok(dialog.includes('Review: E — Review'));
});
