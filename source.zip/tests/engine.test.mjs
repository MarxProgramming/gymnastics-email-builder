import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import { readFile } from 'node:fs/promises';

const nativeFetch = globalThis.fetch;
globalThis.fetch = async url => {
  if (String(url).startsWith('file:')) return new Response(await readFile(url, 'utf8'));
  return nativeFetch(url);
};
const { CLUBS, loadTemplate, generateScript, renderPreview, validateContent } = await import('../dist/engine.js');
const options = { subject: 'Club update for {{child}}', body: 'Thank you, {{parent}}.\n\nWe look forward to seeing {{child}} at gymnastics.', buttonText: 'Read more', buttonUrl: 'https://example.com/details?a=1&b=2' };
const prefixes = { swl: 'Swl', fulham: 'Fulham', apex: 'Apex' };
const normalise = value => String(value).toLowerCase().replace(/['’]/g, '').trim();

function harness(source, { rows, ranges = [[2, rows.length]], quota = 100, hidden = [], filtered = [], locked = false, failRows = [], statusFailure = false, now = () => 1000 } = {}) {
  const data = rows.map(row => [...row]);
  const events = [], sent = [], toasts = [];
  let unlocked = false;
  const headers = data[0];
  const statusColumn = headers.findIndex(value => normalise(value) === 'email status') + 1;
  let currentSendingRow;
  const sheet = {
    getLastRow: () => data.length,
    getLastColumn: () => headers.length,
    isRowHiddenByUser: row => hidden.includes(row),
    isRowHiddenByFilter: row => filtered.includes(row),
    getRange(row, column, height = 1, width = 1) {
      return {
        getDisplayValues: () => {
          events.push(['read', row]);
          return Array.from({ length: height }, (_, offset) => data[row - 1 + offset].slice(column - 1, column - 1 + width));
        },
        setValue(value) {
          if (statusFailure && column === statusColumn && /^Email sent|^Sent;/.test(value)) throw new Error('Status write failed');
          data[row - 1][column - 1] = value;
          if (column === statusColumn && value.startsWith('Sending')) currentSendingRow = row;
          events.push(['status', row, value]);
          return this;
        },
        setBackground: function () { return this; }
      };
    }
  };
  const ss = {
    getActiveSheet: () => sheet,
    getSelection: () => ({ getActiveRangeList: () => ranges === null ? null : ({ getRanges: () => ranges.map(([first, last]) => ({ getRow: () => first, getLastRow: () => last })) }) }),
    toast: (...args) => toasts.push(args)
  };
  const blob = { copyBlob() { return this; } };
  class TestDate extends Date { static now() { return now(); } }
  const context = vm.createContext({
    Date: TestDate,
    console: { log: value => events.push(['log', value]) },
    SpreadsheetApp: { getActiveSpreadsheet: () => ss, flush: () => events.push(['flush']) },
    LockService: { getDocumentLock: () => ({ tryLock: () => !locked, releaseLock: () => { unlocked = true; } }) },
    Utilities: { base64Decode: value => Buffer.from(value, 'base64'), newBlob: () => blob, formatDate: () => '03/11/2026 12:00' },
    MailApp: { getRemainingDailyQuota: () => quota, sendEmail: (email, subject, plainBody, config) => {
      events.push(['send', currentSendingRow]);
      if (failRows.includes(currentSendingRow)) throw new Error('Simulated mail failure');
      sent.push({ row: currentSendingRow, email, subject, plainBody, ...config });
    } }
  });
  vm.runInContext(source, context);
  return { context, data, sent, events, toasts, get unlocked() { return unlocked; } };
}

const headers = ['Childs Name', 'Parents Name', 'Email', 'Email Status', 'Review'];
const person = (child, extra = {}) => [child, 'Parent ' + child, 'family@example.com', extra.status || '', extra.review || ''];

for (const club of CLUBS) {
  const prefix = prefixes[club.id];
  test(`${club.name}: preserves the master except content and the send-only mail service`, async () => {
    const source = await loadTemplate(club.id);
    const generated = await generateScript(club.id, options);
    const before = source.indexOf(`function ${club.id}EmailContent_`);
    const marker = '// MENU AND SELECTED-ROW SENDER';
    assert.equal(generated.slice(0, before), source.slice(0, before));
    assert.equal(generated.slice(generated.indexOf(marker)), source.slice(source.indexOf(marker)).replace(
      'GmailApp.sendEmail(person.email,email.subject,email.plainBody,{',
      'MailApp.sendEmail(person.email,email.subject,email.plainBody,{'));
    assert.ok(generated.includes('MailApp.sendEmail(person.email,email.subject,email.plainBody,{'));
    assert.ok(!generated.includes('GmailApp'));
    assert.ok(!generated.includes('mail.google.com'));
    assert.doesNotThrow(() => new vm.Script(generated));
  });

  test(`${club.name}: preview matches actual generated email, including exact logo`, async () => {
    const generated = await generateScript(club.id, options);
    const context = vm.createContext({});
    vm.runInContext(generated, context);
    const names = { parent: '<Parent & "guardian">', child: 'Taylor <&>' };
    const actual = context[`build${prefix}Email_`](names.parent, names.child);
    const preview = await renderPreview(club.id, options, names);
    const b64 = generated.match(new RegExp(`const ${club.id.toUpperCase()}_LOGO_BASE64 = ["']([^"']+)`))[1];
    assert.equal(preview, actual.htmlBody.replace(`cid:${club.id}Logo`, `data:image/${club.id === 'apex' ? 'png' : 'jpeg'};base64,${b64}`));
    assert.ok(preview.includes('Taylor &lt;&amp;&gt;'));
    assert.ok(preview.includes('&lt;Parent &amp; &quot;guardian&quot;&gt;'));
    assert.ok(preview.includes('https://example.com/details?a=1&amp;b=2'));
    assert.ok(actual.plainBody.includes('Taylor <&>'));
  });

  test(`${club.name}: deduplicates selections and marks each row before reading the next`, async () => {
    const h = harness(await generateScript(club.id, options), {
      rows: [headers, person('Alex'), person('Taylor'), person('Finley')],
      ranges: [[3, 4], [1, 3], [3, 3]]
    });
    h.context[`sendSelected${prefix}Emails`]();
    assert.deepEqual(h.sent.map(email => email.row), [2, 3, 4]);
    assert.equal(h.sent[0].name, club.name);
    assert.ok(h.sent[0].inlineImages[`${club.id}Logo`]);
    assert.ok(h.sent[0].plainBody.includes('Alex'));
    assert.equal(h.data[1][3], 'Email sent — 03/11/2026 12:00');
    assert.ok(h.unlocked);
    const sentRow2 = h.events.findIndex(e => e[0] === 'status' && e[1] === 2 && e[2].startsWith('Email sent'));
    const readRow3 = h.events.findIndex(e => e[0] === 'read' && e[1] === 3);
    assert.ok(sentRow2 < readRow3);
    const sendingRow2 = h.events.findIndex(e => e[0] === 'status' && e[1] === 2 && e[2].startsWith('Sending'));
    const sendRow2 = h.events.findIndex(e => e[0] === 'send' && e[1] === 2);
    assert.ok(sendingRow2 < sendRow2);
    h.context[`sendSelected${prefix}Emails`]();
    assert.equal(h.sent.length, 3, 'recorded statuses prevent duplicate sends');
  });

  test(`${club.name}: respects statuses, review, hidden rows and invalid recipients`, async () => {
    const h = harness(await generateScript(club.id, options), { rows: [headers,
      person('Already sent', { status: 'Email sent' }),
      person('Review', { review: 'Check details' }),
      person('Hidden'), person('Filtered'), ['', 'Parent', 'family@example.com', '', ''],
      ['Child', '', 'family@example.com', '', ''], ['Child', 'Parent', 'bad-email', '', ''],
      person('Eligible')], hidden: [4], filtered: [5] });
    h.context[`sendSelected${prefix}Emails`]();
    assert.deepEqual(h.sent.map(email => email.row), [9]);
    assert.ok(h.toasts.at(-1)[0].includes('Skipped: 7'));
  });

  test(`${club.name}: recognises reordered headings with apostrophes and case differences`, async () => {
    const h = harness(await generateScript(club.id, options), { rows: [
      ['Extra', 'EMAIL', 'Review', "Child’s Name", 'Email Status', " Parent's Name "],
      ['Unrelated', 'family@example.com', '', 'Joseph', '', 'Joseph']
    ] });
    h.context[`sendSelected${prefix}Emails`]();
    assert.equal(h.sent.length, 1);
    assert.ok(h.data[1][4].startsWith('Email sent'));
  });

  test(`${club.name}: dry run neither sends nor modifies rows`, async () => {
    const rows = [headers, person('Alex'), person('Skip', { review: 'Hold' })];
    const h = harness(await generateScript(club.id, options), { rows });
    h.context[`checkSelected${prefix}Rows`]();
    assert.equal(h.sent.length, 0);
    assert.deepEqual(h.data, rows);
    assert.ok(h.toasts.at(-1)[0].includes('1 eligible selected rows; 1 skipped'));
  });

  test(`${club.name}: quota exhaustion leaves the remaining row unsent`, async () => {
    const h = harness(await generateScript(club.id, options), { rows: [headers, person('Alex'), person('Taylor')], quota: 1 });
    h.context[`sendSelected${prefix}Emails`]();
    assert.equal(h.sent.length, 1);
    assert.equal(h.data[2][3], '');
    assert.ok(h.toasts.at(-1)[0].includes('allowance is used up'));
  });

  test(`${club.name}: failed send is marked for review and not automatically retried`, async () => {
    const h = harness(await generateScript(club.id, options), { rows: [headers, person('Alex'), person('Taylor')], failRows: [2] });
    h.context[`sendSelected${prefix}Emails`]();
    assert.deepEqual(h.sent.map(email => email.row), [3]);
    assert.ok(h.data[1][3].startsWith('Check Sent mail before retrying:'));
    h.context[`sendSelected${prefix}Emails`]();
    assert.equal(h.events.filter(e => e[0] === 'send' && e[1] === 2).length, 1);
  });
}

test('arbitrary body text cannot become executable JavaScript', async () => {
  const body = 'Literal `quotes`, ${globalThis.injected = true}, </script>, \\ and "quotes".\n\nChild: {{ child }}. Parent: {{PARENT}}. Unicode \u2028 and \u2029.';
  const source = await generateScript('swl', { subject: 'Literal ${1+1} and `quotes`', body, buttonText: '', buttonUrl: '' });
  const context = vm.createContext({});
  vm.runInContext(source, context);
  const content = context.swlEmailContent_('Parent ${1+1}', 'Child $&');
  assert.equal(context.injected, undefined);
  assert.equal(content.subject, 'Literal ${1+1} and `quotes`');
  assert.equal(content.message, body.replace('{{ child }}', () => 'Child $&').replace('{{PARENT}}', () => 'Parent ${1+1}'));
  assert.ok(context.buildSwlEmail_('Parent', 'Child').htmlBody.includes('&lt;/script&gt;'));
});

test('invalid content and unsafe links are rejected before generating a script', async () => {
  for (const patch of [
    { subject: '' }, { subject: 'Hello\nWorld' }, { subject: 'a'.repeat(241) }, { body: '   ' },
    { buttonUrl: '' }, { buttonText: '' }, { buttonUrl: 'javascript:alert(1)' },
    { buttonUrl: 'http://example.com' }, { buttonUrl: 'https://' }, { buttonUrl: 'https://example.com/"x' },
    { buttonUrl: 'https://user:password@example.com' }, { buttonUrl: 'https://example.com/a b' }
  ]) assert.throws(() => validateContent({ ...options, ...patch }));
  await assert.rejects(generateScript('unknown', options));
});

test('omitting the optional button preserves the standard footer website link', async () => {
  const preview = await renderPreview('swl', { ...options, buttonText: '', buttonUrl: '' });
  assert.ok(!preview.includes('Read more'));
  assert.ok(preview.includes('Visit our website'));
});

test('missing or duplicate headings abort without sending', async () => {
  for (const broken of [['Child', ...headers.slice(1)], [...headers, 'Email']]) {
    const h = harness(await generateScript('swl', options), { rows: [broken, person('Joseph')] });
    h.context.sendSelectedSwlEmails();
    assert.equal(h.sent.length, 0);
    assert.ok(h.toasts.at(-1)[0].includes('Missing or duplicate heading'));
    assert.ok(h.unlocked);
  }
});

test('document lock prevents a concurrent sender', async () => {
  const h = harness(await generateScript('swl', options), { rows: [headers, person('Joseph')], locked: true });
  h.context.sendSelectedSwlEmails();
  assert.equal(h.sent.length, 0);
  assert.ok(h.toasts[0][0].includes('Another send is still running'));
});

test('time limit pauses before touching the next row', async () => {
  let calls = 0;
  const h = harness(await generateScript('swl', options), { rows: [headers, person('Joseph'), person('Taylor')], now: () => calls++ < 2 ? 1000 : 242000 });
  h.context.sendSelectedSwlEmails();
  assert.equal(h.sent.length, 1);
  assert.equal(h.data[2][3], '');
  assert.ok(h.toasts.at(-1)[0].includes('Paused at the time limit'));
});

test('failed status recording stops and leaves an interruption marker', async () => {
  const h = harness(await generateScript('swl', options), { rows: [headers, person('Joseph'), person('Taylor')], statusFailure: true });
  h.context.sendSelectedSwlEmails();
  assert.equal(h.sent.length, 1);
  assert.ok(h.data[1][3].startsWith('Sending — check Sent mail'));
  assert.equal(h.data[2][3], '');
  assert.ok(h.toasts.at(-1)[0].includes('could not record the result'));
  h.context.sendSelectedSwlEmails();
  assert.equal(h.events.filter(e => e[0] === 'send' && e[1] === 2).length, 1);
});
