import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import { readFile } from 'node:fs/promises';
import { createManagementStore, applyClubSettingsToEmailDraft, createDefaultClubSettings, createConfigurationBackup, EMAIL_DRAFT_KEYS } from '../dist/management-store.js';
import { migrateRegularTimetable } from '../dist/timetables.js';
import { migrateClubInfo } from '../dist/club-info.js';
import { applyTermDefaults } from '../dist/term-defaults.js';

const source = await readFile(new URL('../dist/app.js', import.meta.url), 'utf8');
const marker = '// Shared settings are applied only on an explicit action.';
assert.ok(source.includes(marker), 'Keep a stable boundary around the actual management adapters.');
const fields = source.match(/const campaignFields = \{[\s\S]*?\n\};/)[0];
const adapterSource = fields + '\n' + source.slice(source.indexOf(marker));
const copy = value => JSON.parse(JSON.stringify(value));
function storage(initial = {}) {
 const data = new Map(Object.entries(initial));
 return { getItem: key => data.get(key) ?? null, setItem: (key, value) => data.set(key, String(value)), removeItem: key => data.delete(key) };
}
function migrated(club, mode, draft = {}) {
 return applyTermDefaults(club, mode, migrateClubInfo(club, mode, migrateRegularTimetable(club, mode, draft)));
}
// Exercise the callbacks shipped by app.js. Only the already-existing UI's
// DOM collection/restoration is substituted; all migrations and stores are real.
function harness({ clubId = 'swl', emailMode = 'basic', drafts = {}, raw = {}, storageAvailable = true } = {}) {
 const scope = {
  clubId, emailMode, drafts: copy(drafts),
  accessStorage: storageAvailable ? storage(raw) : null, draftsStorageKey: EMAIL_DRAFT_KEYS[0], legacyStorageKey: EMAIL_DRAFT_KEYS[1],
  CLUBS: ['swl','fulham','apex','apexdance'].map(id => ({id})), WEBSITE_CATALOG: [],
  createManagementStore, applyClubSettingsToEmailDraft, migrateRegularTimetable, migrateClubInfo, applyTermDefaults,
  getTemplateDefaults() {}, generateWebsiteCode() {}, applyCentralSettings() {}, buildPreviewDocument() {},
  initManagementUI(options) { scope.api = options; }, clearPreview() {}, clearErrors() {}
 };
 scope.currentDraft = copy(migrated(clubId, emailMode, scope.drafts[`${clubId}:${emailMode}`] || {}));
 scope.saveDraft = () => {
  scope.drafts[`${scope.clubId}:${scope.emailMode}`] = copy(scope.currentDraft);
  scope.accessStorage?.setItem(EMAIL_DRAFT_KEYS[0], JSON.stringify({version:2, clubId:scope.clubId, mode:scope.emailMode, drafts:scope.drafts}));
 };
 scope.restoreDraft = () => { scope.currentDraft = copy(migrated(scope.clubId, scope.emailMode, scope.drafts[`${scope.clubId}:${scope.emailMode}`] || {})); };
 vm.runInNewContext(adapterSource, scope, { filename: 'actual-management-adapters.js' });
 return scope;
}
function restore(h, raw) {
 const backup = createConfigurationBackup(storage(raw));
 const report = h.api.store.importBackup(backup, {restoreEmailDrafts:true});
 h.api.onBackupRestored(report);
}

test('restoring an empty email backup cannot resurrect previously open drafts', () => {
 const h = harness({clubId:'fulham', emailMode:'renewal', drafts:{'fulham:renewal':{subject:'Discard this old draft'},'swl:offer':{subject:'Old offer'}}});
 restore(h, {});
 assert.deepEqual(Object.keys(h.drafts), ['fulham:basic']);
 assert.equal(h.emailMode, 'basic');
 assert.ok(!h.accessStorage.getItem(EMAIL_DRAFT_KEYS[0]).includes('Discard this old draft'));
 assert.ok(!h.accessStorage.getItem(EMAIL_DRAFT_KEYS[0]).includes('Old offer'));
});

test('restoring legacy-only data selects its club and basic mode and clears old drafts', () => {
 const h = harness({emailMode:'renewal', drafts:{'swl:renewal':{subject:'Old renewal'}}});
 restore(h, {[EMAIL_DRAFT_KEYS[1]]:JSON.stringify({clubId:'apex',subject:'Legacy subject',body:'Legacy body'})});
 assert.equal(h.clubId,'apex'); assert.equal(h.emailMode,'basic');
 assert.deepEqual(Object.keys(h.drafts),['apex:basic']);
 assert.equal(h.currentDraft.subject,'Legacy subject'); assert.equal(h.currentDraft.body,'Legacy body');
});

test('backup restoration works for this visit when browser storage is unavailable', () => {
 const h=harness({storageAvailable:false,drafts:{'swl:basic':{subject:'Old message'}}});
 assert.equal(h.api.store.persistent,false);
 const imported={version:2,clubId:'apexdance',mode:'basic',drafts:{'apexdance:basic':{subject:'Restored dance message',body:'Keep this text'}}};
 restore(h,{[EMAIL_DRAFT_KEYS[0]]:JSON.stringify(imported)});
 assert.equal(h.clubId,'apexdance');assert.equal(h.emailMode,'basic');assert.equal(h.currentDraft.subject,'Restored dance message');
 assert.deepEqual(Object.keys(h.drafts),['apexdance:basic']);
 restore(h,{[EMAIL_DRAFT_KEYS[1]]:JSON.stringify({clubId:'fulham',subject:'Legacy without storage'})});
 assert.equal(h.clubId,'fulham');assert.equal(h.currentDraft.subject,'Legacy without storage');
});

test('v2 restore selects saved context and keeps main/reminder content and other club drafts', () => {
 const renewal = migrated('apex','renewal');
 Object.assign(renewal,{subject:'Keep reminder',body:'Reminder text',renewalVariant:'reminder',renewalMessages:{main:{subject:'Original main',body:'Main text'},reminder:{subject:'Keep reminder',body:'Reminder text'}}});
 renewal.cards[0].fee='123.45'; renewal.cards[0].paymentUrl='https://example.com/custom-payment';
 const imported={version:2,clubId:'apex',mode:'renewal',drafts:{'apex:renewal':renewal,'swl:basic':{subject:'Another club',body:'Keep me'}}};
 const h=harness({drafts:{'fulham:offer':{subject:'Old offer'}}});
 restore(h,{[EMAIL_DRAFT_KEYS[0]]:JSON.stringify(imported)});
 assert.equal(h.clubId,'apex');assert.equal(h.emailMode,'renewal');
 assert.equal(h.currentDraft.renewalVariant,'reminder');assert.deepEqual(h.currentDraft.renewalMessages,renewal.renewalMessages);
 assert.equal(h.currentDraft.cards[0].fee,'123.45');assert.equal(h.currentDraft.cards[0].paymentUrl,'https://example.com/custom-payment');
 assert.deepEqual(copy(h.drafts['swl:basic']),imported.drafts['swl:basic']);assert.equal(h.drafts['fulham:offer'],undefined);
});

test('reading shared settings always uses renewal tuition even while an offer is open', () => {
 const renewal=migrated('swl','renewal'),offer=migrated('swl','offer');
 assert.equal(renewal.cards[0].fee,'220.00');assert.equal(offer.cards[0].fee,'260.00');
 const h=harness({emailMode:'offer',drafts:{'swl:renewal':renewal,'swl:offer':offer}});
 const settings=h.api.onReadEmailSettings('swl');
 assert.equal(settings.classes[0].fee,'220.00');assert.equal(settings.details.membershipFee,40);
 assert.equal(h.emailMode,'offer');assert.equal(h.drafts['swl:offer'].cards[0].fee,'260.00');
 assert.deepEqual(h.drafts['swl:renewal'],renewal);
});

test('reading a custom saved term label is valid and preserves that label', () => {
 const renewal=migrated('swl','renewal');
 Object.assign(renewal,{termChoice:'saved',savedTermLabel:'Special training block'});
 Object.assign(renewal.campaign,{termName:'Special training block',startDate:'2027-04-05',endDate:'2027-06-20'});
 const h=harness({drafts:{'swl:renewal':renewal}});
 const settings=h.api.onReadEmailSettings('swl');
 assert.equal(settings.term.season,'');assert.equal(settings.term.termName,'Special training block');
 h.api.store.saveClubSettings('swl',settings);
 assert.equal(h.api.store.getClubSettings('swl').term.termName,'Special training block');
});

test('explicit term apply changes only the target renewal and preserves optional prices and messages', () => {
 const renewal=migrated('apex','renewal'),offer=migrated('apex','offer');
 Object.assign(renewal,{subject:'Personal subject',body:'Personal message',renewalVariant:'reminder',renewalMessages:{main:{subject:'Main',body:'Main copy'},reminder:{subject:'Personal subject',body:'Personal message'}}});
 renewal.cards[0].fee='777.00'; renewal.cards[0].paymentUrl='https://example.com/keep';
 const basic={subject:'Basic subject',body:'Basic body'};
 const h=harness({drafts:{'swl:basic':basic,'apex:renewal':renewal,'apex:offer':offer}});
 const settings=createDefaultClubSettings('apex');
 Object.assign(settings.term,{season:'Summer',year:2027,startDate:'2027-04-08',endDate:'2027-06-24',deadline:'2027-03-25',excludedDates:[]});
 h.api.onApplyEmailSettings('apex',settings,{includeClasses:false,includeDetails:false});
 assert.equal(h.clubId,'apex');assert.equal(h.emailMode,'renewal');
 assert.equal(h.currentDraft.campaign.startDate,'2027-04-08');assert.equal(h.currentDraft.campaign.termName,'Summer 2027');assert.equal(h.currentDraft.campaign.deadline,'2027-03-25');
 assert.equal(h.currentDraft.cards[0].fee,'777.00');assert.equal(h.currentDraft.cards[0].paymentUrl,'https://example.com/keep');
 assert.deepEqual(h.currentDraft.renewalMessages,renewal.renewalMessages);
 assert.deepEqual(h.drafts['apex:offer'],offer);assert.deepEqual(h.drafts['swl:basic'],basic);
});
