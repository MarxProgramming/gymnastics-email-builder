import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import vm from 'node:vm';
import { WEEKDAYS, sortCampaignClasses, getCampaignClassLabel } from '../dist/campaigns.js';
import { migrateRegularTimetable } from '../dist/timetables.js';

const source = await readFile(new URL('../dist/app.js', import.meta.url), 'utf8');
const compileCode = source.slice(source.indexOf('function hasCardContent('), source.indexOf('function campaignConfig('));
const schedulesStart = source.indexOf('function updateSchedules(');
const schedulesCode = source.slice(schedulesStart, source.indexOf("\n$('class-list').addEventListener", schedulesStart));
const plain = value => JSON.parse(JSON.stringify(value));
function cardsFor(club) {
  return migrateRegularTimetable(club, 'renewal', {}).cards.map((card, index) => ({ ...card, fee: String(100 + index), paymentUrl: `https://example.com/${club}/${index}` }));
}
function ui(cards) {
  const select = {
    value: '', options: [], markup: '',
    set innerHTML(value) {
      this.markup = value;
      this.options = [...value.matchAll(/<option value="([^"]*)">([^<]*)<\/option>/g)].map(match => ({ value: match[1], label: match[2] }));
      this.value = this.options[0]?.value || '';
    },
    get innerHTML() { return this.markup; }
  };
  const fields = { 'preview-class':select, 'preview-class-summary':{}, 'class-count-note':{} };
  const context = vm.createContext({
    classCards:cards, sortCampaignClasses, getCampaignClassLabel,
    dayName:day => day === '' || day == null ? '' : WEEKDAYS[Number(day)] || '',
    safe:value => String(value ?? '').replace(/[&<>"']/g, char => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char])),
    $:id => fields[id], document:{querySelector:()=>null},
    scheduleFor:()=>null, scheduleSummary:()=>''
  });
  vm.runInContext(compileCode + schedulesCode, context);
  context.campaignConfig = () => ({ classes:context.compileClasses() });
  return { context, select, fields };
}

test('Dance UI compiles Friday before Saturday without reordering cards or changing their values', () => {
  const cards = cardsFor('apexdance'); const before = plain(cards);
  const {context} = ui(cards);
  const classes = plain(context.compileClasses());
  assert.deepEqual(classes.map(item => item.name), [
    'Junior Acro — Friday 17:30–18:15',
    'Intermediate Acro — Friday 18:30–19:30',
    'Advanced Acro — Friday 19:30–20:30',
    'Junior Acro — Saturday 09:15–10:00',
    'Intermediate Acro — Saturday 10:00–11:00'
  ]);
  assert.deepEqual(cards,before);
  assert.equal(classes[1].fee,cards[1].fee);
  assert.equal(classes[4].paymentUrl,cards[1].paymentUrl);
  assert.equal(classes[4].id,`${cards[1].id}-${cards[1].sessions[1].id}`);
});

test('SWL UI starts Monday, keeps all 29 choices, and shows Senior once with both sessions', () => {
  const cards = cardsFor('swl'); const {context,select} = ui(cards);
  const classes = plain(context.compileClasses());
  assert.equal(classes.length,29);
  assert.deepEqual(classes.slice(0,5).map(item => item.name),[
    'Beginners — Monday 17:00–17:45',
    'Junior Squad — Monday 17:00–19:00',
    'Intermediate — Monday 17:45–18:45',
    'Junior Advanced Class — Monday 17:45–19:15',
    'Advanced — Monday 18:45–20:15'
  ]);
  assert.match(classes.at(-1).name,/Sunday 11:30/);
  const senior = classes.filter(item => item.name === 'Senior Elite Squad');
  assert.equal(senior.length,1); assert.equal(senior[0].sessions.length,2);
  assert.equal(classes.indexOf(senior[0]),9);
  context.updateSchedules();
  const seniorLabels = select.options.filter(option => option.value === senior[0].id);
  assert.equal(seniorLabels.length,1);
  assert.match(seniorLabels[0].label,/Wednesday 17:00–20:15 \+ Saturday 14:30–17:00/);
  assert.equal((select.options[0].label.match(/Monday/g)||[]).length,1);
});

test('preview selection follows its stable ID when a user edits its time and the list reorders', () => {
  const cards = cardsFor('apexdance'); const {context,select} = ui(cards);
  const chosenId = `${cards[1].id}-${cards[1].sessions[1].id}`;
  context.updateSchedules(chosenId);
  assert.equal(select.value,chosenId);
  cards[1].sessions[1].weekday=1;
  context.updateSchedules();
  assert.equal(select.options[0].value,chosenId);
  assert.equal(select.value,chosenId);
  assert.match(select.options[0].label,/Monday 10:00–11:00/);
  assert.equal(cards[1].sessions[1].weekday,1);
});

test('partial custom cards sort after valid classes and unchecked cards remain excluded', () => {
  const cards = cardsFor('fulham');
  cards[1].enabled=false;
  cards.unshift({id:'ccustom',name:'New class',fee:'',paymentUrl:'',feeNote:'',combined:false,enabled:true,sessions:[{id:'ccustoms1',weekday:'',startTime:'',endTime:''}]});
  const before = plain(cards); const {context} = ui(cards);
  const classes = plain(context.compileClasses());
  assert.equal(classes.length,3);
  assert.equal(classes.at(-1).id,'ccustom-ccustoms1');
  assert.equal(classes.at(-1).sessions[0].weekday,null);
  assert.ok(!classes.some(item => item.name.startsWith('Intermediate')));
  assert.deepEqual(cards,before);
});
