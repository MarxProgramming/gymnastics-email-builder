import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import vm from 'node:vm';
import { applyTermDefaults } from '../dist/term-defaults.js';
import { setAnnualMembershipReminder } from '../dist/club-info.js';

const source = await readFile(new URL('../dist/app.js', import.meta.url), 'utf8');
function functionsBetween(first, next) {
  const start = source.indexOf(`function ${first}(`);
  return source.slice(start, source.indexOf(`function ${next}(`, start));
}
const uiCode = functionsBetween('renewalMessageState','readCampaignFields') + functionsBetween('collectDraft','saveDraft') + functionsBetween('getConfig','savedTermSettings');
const plain = value => JSON.parse(JSON.stringify(value));
function ui(draft = {}, {club='swl', mode='renewal'} = {}) {
  const fields = Object.fromEntries(['subject','body','button-text','button-url','term-season','deadline-kind','preview-class'].map(id=>[id,{value:''}]));
  fields['add-button']={checked:false}; fields['renewal-variant-field']={hidden:false,disabled:false};
  const radios=['main','reminder'].map(value=>({value,checked:false}));
  const campaign={termName:'Spring 2027',startDate:'2027-01-04',endDate:'2027-03-21',deadline:'2026-12-20',additionalInfo:'My shared note',...draft.campaign};
  const cards=draft.cards || [{id:'c1',name:'My class',fee:'246',paymentUrl:'https://example.com/pay',sessions:[]}];
  const events=[];
  const context=vm.createContext({
    emailMode:mode,clubId:club,renewalVariant:'main',renewalMessages:{},
    classCards:cards,currentClubInfo:draft.clubInfo || null,currentTermDefaults:draft.termDefaults || null,
    annualMembershipReminder:false,UI_SETTINGS_VERSION:1,savedTermLabel:'',currentTimetableVersion:1,excludedDates:new Set(['2027-02-15']),
    $:id=>fields[id],document:{querySelectorAll:()=>radios},
    readCampaignFields:()=>({...campaign}),campaignConfig:()=>({...campaign,classes:cards}),
    clearPreview:()=>events.push('clearPreview'),clearErrors:()=>events.push('clearErrors')
  });
  vm.runInContext(uiCode,context);
  const restored=context.renewalMessageState(draft);
  context.renewalVariant=restored.variant; context.renewalMessages=restored.messages;
  fields.subject.value=restored.messages[restored.variant].subject;
  fields.body.value=restored.messages[restored.variant].body;
  context.updateDraft=()=>{events.push('save');context.saved=context.collectDraft();};
  return {context,fields,campaign,cards,events,radios};
}

test('an existing customised Renewal migrates into Main while Reminder gets the gentle default', () => {
  const {context}=ui({subject:'My existing subject',body:'My existing opening'});
  assert.equal(context.renewalVariant,'main');
  assert.deepEqual(plain(context.renewalMessages.main),{subject:'My existing subject',body:'My existing opening'});
  assert.equal(context.renewalMessages.reminder.subject,'A gentle reminder to renew for {{term}} — {{club}}');
  assert.match(context.renewalMessages.reminder.body,/If you’ve already renewed, thank you—please ignore this reminder\./);
});

test('Main and Reminder keep independent edits and intentional blanks through toggles and a save/reload', () => {
  const {context,fields,events}=ui({subject:'Old main',body:'Old body'});
  fields.subject.value='Updated main'; fields.body.value='Updated main body';
  context.changeRenewalVariant('reminder');
  assert.deepEqual(events,['clearPreview','clearErrors','save']);
  fields.subject.value='My reminder'; fields.body.value='';
  context.changeRenewalVariant('main');
  assert.equal(fields.subject.value,'Updated main'); assert.equal(fields.body.value,'Updated main body');
  fields.subject.value='';
  context.changeRenewalVariant('reminder');
  assert.equal(fields.subject.value,'My reminder'); assert.equal(fields.body.value,'');
  const reloaded=ui(plain(context.collectDraft()));
  assert.equal(reloaded.context.renewalVariant,'reminder');
  assert.equal(reloaded.fields.body.value,'');
  reloaded.context.changeRenewalVariant('main');
  assert.equal(reloaded.fields.subject.value,'');
  assert.equal(reloaded.fields.body.value,'Updated main body');
});

test('toggling preserves shared term, deadline, cancellations, classes, fees, links and notes', () => {
  const {context,campaign,cards}=ui();
  campaign.deadline='2026-12-22'; campaign.additionalInfo='Shared edited note'; cards[0].fee='300';
  const before=plain(context.collectDraft());
  context.changeRenewalVariant('reminder');
  campaign.deadline='2026-12-23'; cards[0].paymentUrl='https://example.com/new-link';
  context.changeRenewalVariant('main');
  const after=plain(context.collectDraft());
  assert.equal(after.campaign.deadline,'2026-12-23');
  assert.equal(after.campaign.additionalInfo,'Shared edited note');
  assert.equal(after.cards[0].fee,'300');
  assert.equal(after.cards[0].paymentUrl,'https://example.com/new-link');
  assert.deepEqual(after.excludedDates,before.excludedDates);
  assert.equal(after.campaign.startDate,before.campaign.startDate);
});

test('Reminder state remains separate for each club and is absent from Basic and Offer options/drafts', () => {
  const swl=ui({}, {club:'swl'}); swl.context.changeRenewalVariant('reminder'); swl.fields.subject.value='SWL reminder';
  const saved=plain(swl.context.collectDraft());
  for(const club of ['fulham','apex','apexdance']) {
    const other=ui({}, {club});
    assert.equal(other.context.renewalVariant,'main');
    assert.notEqual(other.context.renewalMessages.reminder.subject,'SWL reminder');
  }
  assert.equal(ui(saved).fields.subject.value,'SWL reminder');
  for(const mode of ['basic','offer']) {
    const other=ui({}, {mode});
    other.context.changeRenewalVariant('reminder');
    assert.equal(other.events.length,0);
    assert.ok(!('renewalVariant' in other.context.collectDraft()));
    assert.ok(!('renewalMessages' in other.context.collectDraft()));
    assert.ok(!('renewalVariant' in other.context.getConfig()));
  }
});

test('variant is part of preview/export identity even when Main and Reminder use identical wording', () => {
  const message={subject:'Same subject',body:'Same message'};
  const {context}=ui({renewalMessages:{main:message,reminder:message}});
  const original=context.fingerprint();
  assert.equal(context.getConfig().renewalVariant,'main');
  context.changeRenewalVariant('reminder');
  assert.equal(context.getConfig().renewalVariant,'reminder');
  assert.notEqual(context.fingerprint(),original);
});

test('loading Spring defaults and changing annual membership preserve both messages and selected variant', () => {
  const {context}=ui({subject:'Custom main',body:''},{club:'apex'});
  context.changeRenewalVariant('reminder');
  const saved=plain(context.collectDraft());
  const refreshed=applyTermDefaults('apex','renewal',saved,{force:true});
  const withMembership=setAnnualMembershipReminder('apex','renewal',refreshed,true);
  const reloaded=ui(plain(withMembership),{club:'apex'});
  assert.equal(reloaded.context.renewalVariant,'reminder');
  assert.deepEqual(plain(reloaded.context.renewalMessages),saved.renewalMessages);
  assert.equal(withMembership.campaign.deadline,saved.campaign.deadline);
});
