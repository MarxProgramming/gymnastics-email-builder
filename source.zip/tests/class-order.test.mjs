import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import { readFile } from 'node:fs/promises';
import { WEEKDAYS, sortCampaignClasses, getCampaignClassLabel, validateCampaign } from '../dist/campaigns.js';
import { applyTermDefaults } from '../dist/term-defaults.js';
globalThis.fetch=async url=>new Response(await readFile(url,'utf8'));
const {CLUBS,generateScript,renderPreview}=await import('../dist/engine.js');
const prefixes={swl:'Swl',fulham:'Fulham',apex:'Apex',apexdance:'ApexDance'};
const session=(weekday,startTime,endTime='19:00')=>({weekday,startTime,endTime});
function regularClasses(club){
  const draft=applyTermDefaults(club,'renewal',{});
  const classes=draft.cards.flatMap(card=>{
    const common={name:card.name,fee:card.fee,paymentUrl:card.paymentUrl||'https://example.com/'+card.id};
    if(card.combined)return [{...common,id:card.id,sessions:card.sessions}];
    return card.sessions.map((weekly,index)=>({...common,id:card.id+'-'+index,name:card.name+' — '+WEEKDAYS[weekly.weekday]+' '+weekly.startTime+'–'+weekly.endTime,sessions:[weekly]}));
  });
  return {classes,campaign:{...draft.campaign,deadline:'2026-12-15',classes}};
}
function independentKey(cls){return cls.sessions.map(item=>String((item.weekday+6)%7)+'|'+item.startTime).sort()[0];}

test('Monday-first ordering uses the earliest combined session and preserves all same-start ties without mutating data',()=>{
  const sunday={id:'sunday',sessions:[session(0,'09:00')]};
  const mondayLong={id:'monday-long',sessions:[session(1,'17:00','19:00')]};
  const mondayShort={id:'monday-short',sessions:[session(1,'17:00','17:45')]};
  const combined={id:'elite',sessions:[session(6,'14:30','17:00'),session(3,'17:00','20:15')]};
  const classes=[sunday,combined,mondayLong,mondayShort,{id:'early',sessions:[session(1,'16:00')]}],before=JSON.stringify(classes);
  const sorted=sortCampaignClasses(classes);
  assert.deepEqual(sorted.map(item=>item.id),['early','monday-long','monday-short','elite','sunday']);
  assert.equal(JSON.stringify(classes),before);assert.equal(sorted[3],combined);assert.equal(combined.sessions[0].weekday,6,'session input order remains intact');
});

test('partial drafts sort after complete options without treating blank or null weekdays as Sunday',()=>{
  const classes=[{id:'null',name:'Incomplete',sessions:[session(null,'09:00')]},{id:'blank',sessions:[session('','10:00')]},{id:'no-time',sessions:[session(1,'')]},{id:'none',sessions:[]},{id:'sunday',sessions:[session(0,'09:00')]},{id:'monday',sessions:[session(1,'17:00')]}];
  assert.deepEqual(sortCampaignClasses(classes).map(item=>item.id),['monday','sunday','null','blank','no-time','none']);
  assert.doesNotThrow(()=>classes.map(getCampaignClassLabel));
  assert.ok(!getCampaignClassLabel(classes[0]).includes('Sunday'));
});

test('shared labels show single-session times once and both Senior Elite sessions in weekly order',()=>{
  const single={name:'Beginners — Monday 17:00–17:45',sessions:[session(1,'17:00','17:45')]};
  assert.equal(getCampaignClassLabel(single),single.name);
  const elite={name:'Senior Elite Squad',sessions:[session(6,'14:30','17:00'),session(3,'17:00','20:15')]};
  assert.equal(getCampaignClassLabel(elite),'Senior Elite Squad — 2 sessions/week: Wednesday 17:00–20:15 + Saturday 14:30–17:00');
  assert.equal(getCampaignClassLabel({name:'Example',sessions:[session(4,'18:00','19:00')]}),'Example — Thursday 18:00–19:00');
});

for(const club of CLUBS)test(`${club.name}: chronological chooser numbering keeps every class, fee, link and email schedule paired`,async()=>{
  const {classes,campaign}=regularClasses(club.id),before=JSON.stringify(campaign);
  const expected=classes.map((cls,index)=>({cls,index})).sort((a,b)=>independentKey(a.cls).localeCompare(independentKey(b.cls))||a.index-b.index).map(item=>item.cls);
  const validated=validateCampaign('renewal',campaign);assert.deepEqual(validated.classes.map(item=>item.id),expected.map(item=>item.id));assert.equal(JSON.stringify(campaign),before);
  const counts={swl:29,fulham:3,apex:6,apexdance:5};assert.equal(expected.length,counts[club.id]);
  const groups=expected.reduce((result,cls)=>{const day=Number(independentKey(cls)[0]);result[day]=(result[day]||0)+1;return result;},{});
  if(club.id==='swl')assert.deepEqual(groups,{0:5,1:4,2:1,3:4,4:5,5:6,6:4});
  if(club.id==='apexdance')assert.deepEqual(groups,{4:3,5:2});
  const options={mode:club.id==='swl'?'offer':'renewal',subject:'Spring class',body:'Your class details.',campaign};
  const source=await generateScript(club.id,options);let answer='1',lastPrompt='';const built=[];
  const sheet={};const ss={getActiveSheet:()=>sheet,getSelection:()=>({getActiveRangeList:()=>({getRanges:()=>[{getRow:()=>2,getLastRow:()=>2}]})})};
  const context=vm.createContext({SpreadsheetApp:{getActiveSpreadsheet:()=>ss,getUi:()=>({Button:{OK:'OK'},ButtonSet:{OK_CANCEL:'OK_CANCEL'},prompt:(title,choices)=>{lastPrompt=choices;return {getSelectedButton:()=>'OK',getResponseText:()=>answer};},alert:message=>assert.fail(message)})}});
  vm.runInContext(source,context);
  context['process'+prefixes[club.id]+'Emails_']=()=>{
    const selected=vm.runInContext('selectedCampaignClass_',context);
    built.push({id:selected.id,fee:selected.fee,url:selected.paymentUrl,email:context['build'+prefixes[club.id]+'Email_']('Pat','Alex')});
  };
  const b64=source.match(new RegExp(`const ${club.id.toUpperCase()}_LOGO_BASE64 = ["']([^"']+)`))[1];
  for(let index=0;index<expected.length;index++){
    answer=String(index+1);context['sendSelected'+prefixes[club.id]+'Emails']();
    const result=built[index],cls=expected[index];assert.equal(result.id,cls.id);assert.equal(result.fee,Number(cls.fee));assert.equal(result.url,cls.paymentUrl);
    for(const weekly of cls.sessions)assert.ok(result.email.plainBody.includes(WEEKDAYS[weekly.weekday]+' '+weekly.startTime+'–'+weekly.endTime));
    const preview=await renderPreview(club.id,{...options,previewClassId:cls.id},{parent:'Pat',child:'Alex'});assert.equal(preview,result.email.htmlBody.replace('cid:'+club.id+'Logo','data:'+club.logoMime+';base64,'+b64));
    assert.ok(result.email.plainBody.includes(cls.paymentUrl));
  }
  const choiceLines=lastPrompt.split('\n').filter(line=>/^\d+\./.test(line));assert.equal(choiceLines.length,expected.length);
  for(let index=0;index<expected.length;index++)for(const weekly of expected[index].sessions){const text=WEEKDAYS[weekly.weekday]+' '+weekly.startTime+'–'+weekly.endTime;assert.equal(choiceLines[index].split(text).length-1,1,'a class time appears once in its choice');}
  if(club.id==='swl'){
    const eliteIndex=expected.findIndex(item=>item.name==='Senior Elite Squad');assert.equal(eliteIndex,9);
    assert.equal(choiceLines.filter(line=>line.includes('Senior Elite Squad')).length,1);
    assert.match(choiceLines[eliteIndex],/2 sessions\/week: Wednesday 17:00–20:15 \+ Saturday 14:30–17:00 — £803\.00 \(covers both sessions\)/);
    assert.ok(built[eliteIndex].email.plainBody.includes('Total term fee: £803.00 (covers both sessions)'));
    assert.equal(built[eliteIndex].email.plainBody.split('Total term fee:').length-1,1);
  }
});
