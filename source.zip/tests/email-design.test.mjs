import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import vm from 'node:vm';
globalThis.fetch = async url => new Response(await readFile(url, 'utf8'));
const { CLUBS, generateScript, renderPreview, getClubEmailDesign } = await import('../dist/engine.js');
const prefixes = { swl:'Swl',fulham:'Fulham',apex:'Apex',apexdance:'ApexDance' };
const basic = { subject:'Design comparison',body:'Shared body paragraph.\n\nA second paragraph.',buttonText:'Test button',buttonUrl:'https://example.com/pay' };
const campaign = {
  termName:'Example term',startDate:'2028-01-03',endDate:'2028-01-31',deadline:'2027-12-20',
  classes:[{id:'example',name:'Example class',fee:'125',paymentUrl:'https://example.com/pay',sessions:[{weekday:1,startTime:'17:00',endTime:'18:00'}]}],
  paymentButtonText:'Test button',informationUrl:'https://example.com/info',informationButtonText:'Information',mapUrl:'https://example.com/map',uniformUrl:'https://example.com/uniform',additionalInfo:'Additional information paragraph.'
};
function buttonBlock(html,url) {
  const anchor = html.indexOf('<a href="'+url+'"');
  assert.ok(anchor>=0);
  const start=html.lastIndexOf('<table',anchor),end=html.indexOf('</table>',anchor)+8;
  return html.slice(start,end);
}
function normaliseButton(block,url,label) { return block.replaceAll(url,'URL').replaceAll('>'+label+'<','>LABEL<'); }

for(const club of CLUBS) {
  test(`${club.name}: Basic, Renewal and Offer share exact outer layout, logo, paragraphs and buttons`,async()=>{
    const base=await renderPreview(club.id,basic);
    const bodyParagraph=base.match(/<p style="[^"]+">Shared body paragraph\.<\/p>/)[0];
    const basePrefix=base.slice(0,base.indexOf(bodyParagraph));
    const signoffStart=base.lastIndexOf('<p',base.indexOf('Kind regards,'));
    const baseSuffix=base.slice(signoffStart);
    const baseLogo=base.match(/<img\b[^>]*>/)[0];
    const baseStyle=bodyParagraph.match(/style="([^"]+)"/)[1];
    const baseButton=normaliseButton(buttonBlock(base,basic.buttonUrl),basic.buttonUrl,basic.buttonText);
    for(const mode of ['basic','renewal','offer']) {
      const options=mode==='basic'?basic:{mode,subject:basic.subject,body:basic.body,previewClassId:'example',campaign};
      const html=await renderPreview(club.id,options);
      assert.equal(html.slice(0,html.indexOf(bodyParagraph)),basePrefix,mode+' retains the same head, header, logo, card opening and greeting');
      assert.equal(html.slice(html.lastIndexOf('<p',html.indexOf('Kind regards,'))),baseSuffix,mode+' retains the exact sign-off and footer');
      assert.equal(html.match(/<img\b[^>]*>/)[0],baseLogo);
      assert.ok(html.includes('<p style="'+baseStyle+'">A second paragraph.</p>'));
      assert.equal(normaliseButton(buttonBlock(html,basic.buttonUrl),basic.buttonUrl,basic.buttonText),baseButton);
      if(mode!=='basic') {
        assert.ok(html.includes('<p style="'+baseStyle+'">Additional information paragraph.</p>'));
        assert.ok(html.includes('<p style="'+baseStyle+'"><strong>Class:</strong> Example class — Monday 17:00–18:00</p>'));
        for(const [url,label] of [[campaign.informationUrl,'Information'],...(mode === 'offer' ? [[campaign.mapUrl,'Google Maps']] : []),[campaign.uniformUrl,'View leotards &amp; uniform']]) assert.equal(normaliseButton(buttonBlock(html,url),url,label),baseButton,'all optional buttons reuse the exact Basic component');
        const footer=base.match(/<td\b(?=[^>]*class="footer-pad")[^>]*>/)[0];
        const background=footer.match(/bgcolor="([^"]+)"/)[1];
        const border=footer.match(/border-top:1px solid ([^;]+);/)[1];
        const design=getClubEmailDesign(club.id);
        assert.equal(design.panelBackground,background);assert.equal(design.panelBorder,border);
        assert.ok(html.includes('border:1px solid '+club.accent+';border-radius:'));
        assert.ok(!html.includes('border-left:4px solid'));
        assert.ok(html.includes('background:'+background+';'));
      }
      const script=await generateScript(club.id,options);const context=vm.createContext({});vm.runInContext(script,context);
      if(mode!=='basic')vm.runInContext('selectedCampaignClass_=EMAIL_CAMPAIGN.campaign.classes[0]',context);
      const actual=context[`build${prefixes[club.id]}Email_`]('Joseph','Joseph');
      const b64=script.match(new RegExp(`const ${club.id.toUpperCase()}_LOGO_BASE64 = ["']([^"']+)`))[1];
      assert.equal(html,actual.htmlBody.replace(`cid:${club.id}Logo`,`data:${club.logoMime};base64,${b64}`));
    }
  });
}

test('component marker text in user input remains literal and cannot rewrite adjacent components',async()=>{
  const options={mode:'renewal',subject:'Marker text',body:'Literal __EMAIL_HEADING__ and __EMAIL_BUTTON_URL__.',campaign:{...campaign,paymentButtonText:'__EMAIL_PARAGRAPH__',additionalInfo:'__EMAIL_BUTTON_TEXT__'}};
  const html=await renderPreview('swl',options);
  assert.ok(html.includes('Literal __EMAIL_HEADING__ and __EMAIL_BUTTON_URL__.'));
  assert.ok(html.includes('>__EMAIL_PARAGRAPH__</a>'));
  assert.ok(html.includes('>__EMAIL_BUTTON_TEXT__</p>'));
});
