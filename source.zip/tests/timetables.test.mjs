import test from 'node:test';
import assert from 'node:assert/strict';
import { TIMETABLE_VERSION, REGULAR_TIMETABLES, TIMETABLE_SOURCES, migrateRegularTimetable } from '../dist/timetables.js';
const s = (weekday, startTime, endTime, id = 'csession') => ({ id, weekday, startTime, endTime });
const card = (name, sessions, other = {}) => ({ id: 'csaved', name, fee: '123.45', paymentUrl: 'https://example.com/pay', feeNote: 'Saved note', combined: false, sessions, ...other });
const choices = cards => cards.reduce((sum, item) => sum + (item.combined ? 1 : item.sessions.length), 0);

for (const [club, types, groups] of [['swl',7,29],['apex',4,6],['apexdance',3,5],['fulham',3,3]]) {
  for (const mode of ['renewal','offer']) test(`${club} ${mode} starts with all current regular classes, blank commercial details and unique IDs`, () => {
    const draft = migrateRegularTimetable(club, mode, {});
    assert.equal(draft.timetableVersion, TIMETABLE_VERSION);
    assert.equal(draft.cards.length, types);
    assert.equal(choices(draft.cards), groups);
    assert.equal(new Set(draft.cards.map(item => item.id)).size, types);
    const sessionIds = draft.cards.flatMap(item => item.sessions.map(session => session.id));
    assert.equal(new Set(sessionIds).size, sessionIds.length);
    assert.ok(draft.cards.every(item => item.enabled && item.fee === '' && item.paymentUrl === '' && item.feeNote === ''));
    assert.equal(draft.campaign, undefined);
    assert.match(TIMETABLE_SOURCES[club], /^https:\/\//);
  });
}
test('current SWL roster adds Junior Advanced and removes Thursday from Junior Squad', () => {
  const cards = migrateRegularTimetable('swl','renewal',{}).cards;
  assert.deepEqual(cards.find(item => item.name === 'Junior Advanced Class').sessions.map(({weekday,startTime,endTime}) => ({weekday,startTime,endTime})), [s(1,'17:45','19:15'),s(4,'17:00','18:30')].map(({id,...rest}) => rest));
  assert.deepEqual(cards.find(item => item.name === 'Junior Squad').sessions.map(item => item.weekday), [1,2,5,6]);
  const senior = cards.find(item => item.name === 'Senior Elite Squad');
  assert.equal(senior.combined, true); assert.deepEqual(senior.sessions.map(item => item.weekday), [3,6]);
});
test('current Apex roster includes the second Beginners group and the current two-hour class name', () => {
  const cards = migrateRegularTimetable('apex','offer',{}).cards;
  assert.deepEqual(cards.find(item => item.name === 'Beginners').sessions.map(item => item.startTime), ['16:15','17:15']);
  assert.ok(cards.some(item => item.name === 'Two-Hour Advanced'));
  assert.ok(cards.every(item => item.name !== 'Floor & Vault Squad'));
});
test('the untouched blank starting card is replaced with regular classes', () => {
  const draft = { subject: 'My subject', cards: [card('',[s('','','')],{fee:'',paymentUrl:'',feeNote:''})] };
  const output = migrateRegularTimetable('apex','renewal',draft);
  assert.equal(output.cards.length,4); assert.equal(output.subject,'My subject');
  assert.equal(output.cards.some(item => item.id === 'csaved'),false);
});
test('an exact old Apex Beginners default upgrades its timetable and retains fee, link, notes and existing session ID', () => {
  const saved = card('Beginners',[s(4,'16:15','17:00','cfirst')],{enabled:false});
  const output = migrateRegularTimetable('apex','renewal',{cards:[saved]});
  const updated = output.cards.find(item => item.id === saved.id);
  assert.deepEqual(updated.sessions.map(item => item.startTime),['16:15','17:15']);
  assert.equal(updated.sessions[0].id,'cfirst'); assert.equal(updated.fee,'123.45');
  assert.equal(updated.paymentUrl,saved.paymentUrl); assert.equal(updated.feeNote,saved.feeNote); assert.equal(updated.enabled,false);
  assert.equal(output.cards.filter(item => item.regularKey === 'apex:beginners').length,1);
});
test('an exact old SWL Junior Squad default is updated without replacing its saved commercial details', () => {
  const saved = card('Junior Squad',[s(1,'17:00','19:00','cmon'),s(2,'17:00','19:00','ctue'),s(4,'17:00','19:00','cthu'),s(5,'17:15','19:15','cfri'),s(6,'09:45','11:45','csat')]);
  const output = migrateRegularTimetable('swl','offer',{cards:[saved]});
  const updated = output.cards.find(item => item.id === saved.id);
  assert.deepEqual(updated.sessions.map(item => item.weekday),[1,2,5,6]);
  assert.equal(updated.fee,saved.fee); assert.equal(updated.paymentUrl,saved.paymentUrl);
  assert.equal(output.cards.length,7);
});
test('legacy Apex Floor & Vault exactly matching the old default is renamed without a duplicate or fee loss', () => {
  const saved = card('Floor & Vault Squad',[s(4,'18:15','20:15')]);
  const output = migrateRegularTimetable('apex','offer',{cards:[saved]});
  assert.equal(output.cards.length,4);
  const updated = output.cards.find(item => item.id === saved.id);
  assert.equal(updated.name,'Two-Hour Advanced'); assert.equal(updated.fee,saved.fee); assert.equal(updated.paymentUrl,saved.paymentUrl);
  assert.equal(output.cards.filter(item => item.regularKey === 'apex:twohouradvanced').length,1);
});
test('a modified timetable on a recognized regular class is preserved, not overwritten or duplicated', () => {
  const saved = card('Beginners',[s(4,'16:20','17:05')]);
  const output = migrateRegularTimetable('apex','renewal',{cards:[saved]});
  const kept = output.cards.find(item => item.id === saved.id);
  assert.deepEqual(kept.sessions,saved.sessions); assert.equal(kept.name,saved.name);
  assert.equal(output.cards.filter(item => item.regularKey === 'apex:beginners').length,1);
});
test('a custom name using the same times remains a separate custom class', () => {
  const saved = card('My Thursday squad',[s(4,'18:15','20:15')]);
  const output = migrateRegularTimetable('apex','offer',{cards:[saved]});
  assert.equal(output.cards.length,5);
  const kept = output.cards.find(item => item.id === saved.id);
  assert.equal(kept.name,saved.name); assert.deepEqual(kept.sessions,saved.sessions); assert.equal(kept.regularKey,undefined);
  assert.ok(output.cards.some(item => item.name === 'Two-Hour Advanced'));
});
test('backfill happens once: later unchecks, removals and edits are preserved', () => {
  const first = migrateRegularTimetable('swl','renewal',{});
  first.cards = first.cards.slice(1); first.cards[0].enabled = false; first.cards[0].fee = '88';
  const again = migrateRegularTimetable('swl','renewal',first);
  assert.equal(again,first); assert.equal(again.cards.length,6); assert.equal(again.cards[0].enabled,false); assert.equal(again.cards[0].fee,'88');
});
test('migration leaves Basic and unknown clubs untouched', () => {
  const saved = { cards: [card('Custom',[s(2,'12:00','13:00')])], body: 'Keep me' };
  assert.equal(migrateRegularTimetable('swl','basic',saved),saved);
  assert.equal(migrateRegularTimetable('unknown','offer',saved),saved);
});
test('draft migration does not mutate input and renewal/offer rosters are independent', () => {
  const original = { cards: [card('Beginners',[s(4,'16:15','17:00')])], campaign: {deadline:'2027-01-01'}, excludedDates:['2027-01-15'] };
  const snapshot = JSON.stringify(original);
  const output = migrateRegularTimetable('apex','renewal',original);
  output.cards[0].sessions[0].startTime = '01:00'; output.cards[0].fee = '999';
  assert.equal(JSON.stringify(original),snapshot);
  const offer = migrateRegularTimetable('apex','offer',{});
  assert.equal(offer.cards[0].sessions[0].startTime,'16:15'); assert.equal(offer.cards[0].fee,'');
  assert.equal(REGULAR_TIMETABLES.apex[0].sessions[0].startTime,'16:15');
});


test('custom alias labels are matched for deduplication but are not silently renamed or upgraded', () => {
  const saved = card('F&V',[s(4,'18:15','20:15')]);
  const output = migrateRegularTimetable('apex','offer',{cards:[saved]});
  assert.equal(output.cards.length,4);
  const kept = output.cards.find(item => item.id === saved.id);
  assert.equal(kept.name,'F&V'); assert.deepEqual(kept.sessions,saved.sessions);
  assert.equal(kept.fee,saved.fee); assert.equal(kept.paymentUrl,saved.paymentUrl);
});
