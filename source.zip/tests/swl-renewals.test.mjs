import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import {readFile} from 'node:fs/promises';
import {applyTermDefaults} from '../dist/term-defaults.js';
import {SWL_RENEWAL_CODES,swlRenewalCodeMap} from '../dist/swl-renewals.js';
globalThis.fetch=async url=>new Response(await readFile(url,'utf8'));
const {generateScript,renderPreview}=await import('../dist/engine.js');
const draft=applyTermDefaults('swl','renewal',{});
const classes=draft.cards.flatMap(c=>{
 const base={regularKey:c.regularKey,fee:c.fee,paymentUrl:c.paymentUrl,name:c.name};
 return c.combined?[{...base,id:c.id,sessions:c.sessions}]:c.sessions.map(s=>({...base,id:s.id,sessions:[s]}));
});
const config={mode:'renewal',subject:'Renew {{class}} for {{child}}',body:'Please renew for {{term}}.',campaign:{...draft.campaign,deadline:'2026-12-15',classes}};
const source=await generateScript('swl',config);
function harness({codes=['MONB1','SUNINT2'],cancel=false,mutate,selection,customRows,script=source,quota=100,locked=false}={}) {
 const rows=customRows||[['Notes','Renewal class','Email','Childs Name','Parents Name','Email Status','Review'],...codes.map((code,i)=>['',code,`p${i}@example.com`,`Child ${i}`,`Parent ${i}`,'Email sent — earlier',''])];
 let ranges=selection||[[2,rows.length]],held=false;const sent=[],writes=[],dialogs=[],menus=[],events=[];
 const sheet={getLastRow:()=>rows.length,getLastColumn:()=>rows[0].length,getMaxColumns:()=>30,isRowHiddenByUser:r=>false,isRowHiddenByFilter:r=>false,getRange:(r,c,h=1,w=1)=>({getDisplayValues:()=>Array.from({length:h},(_,i)=>Array.from({length:w},(_,j)=>rows[r-1+i]?.[c-1+j]||'')),setValue(v){assert.ok(held);rows[r-1][c-1]=v;writes.push([r,c,v]);return this;},setBackground(){return this;}})};
 const ss={getActiveSheet:()=>sheet,getSelection:()=>({getActiveRangeList:()=>({getRanges:()=>ranges.map(([first,last])=>({getRow:()=>first,getLastRow:()=>last}))})}),toast:()=>{}};
 const ui={Button:{OK:'OK',CANCEL:'CANCEL'},ButtonSet:{OK:'OK',OK_CANCEL:'OK_CANCEL'},createMenu:name=>({addItem(label,callback){menus.push({label,callback});return this},addToUi(){}}),prompt:()=>assert.fail('No manual class chooser for SWL renewals'),alert(...args){assert.equal(held,false);dialogs.push(args);if(args[2]==='OK_CANCEL'){events.push('confirm');if(mutate)mutate({rows,sheet,setSelection:v=>ranges=v});return cancel?'CANCEL':'OK';}}};
 const blob={copyBlob(){return this}};
 const ctx=vm.createContext({console:{log(){}},SpreadsheetApp:{getActiveSpreadsheet:()=>ss,getUi:()=>ui,flush(){}},LockService:{getDocumentLock:()=>({tryLock:()=>{events.push('lock');held=!locked;return held},releaseLock:()=>held=false})},Utilities:{newBlob:()=>blob,base64Decode:s=>Buffer.from(s,'base64'),formatDate:()=> 'test'},MailApp:{getRemainingDailyQuota:()=>quota,sendEmail:(email,subject,plainBody,opts)=>{assert.ok(held);sent.push({email,subject,plainBody,...opts})}}});vm.runInContext(script,ctx);
 return {ctx,rows,sheet,sent,writes,dialogs,menus,events};
}
test('all 30 supplied codes map to exact standard groups, with both Senior codes sharing one programme',()=>{
 const map=swlRenewalCodeMap(classes);assert.equal(Object.keys(map).length,30);
 for(const [code,ids] of Object.entries(map))assert.equal(ids.length,1,code);
 assert.equal(map.WEDSES1[0],map.SATSES1[0]);assert.notEqual(map.SATFV1[0],map.SATFV2[0]);assert.notEqual(map.SUNINT1[0],map.SUNINT2[0]);
 for(const [code,time] of [['SUNINT1','09:30'],['SUNINT2','10:30'],['SATFV1','09:30'],['SATFV2','12:15']])assert.equal(classes.find(c=>c.id===map[code][0]).sessions[0].startTime,time);
 const removed=classes.filter(c=>c.id!==map.SUNINT1[0]);assert.deepEqual(swlRenewalCodeMap(removed).SUNINT1,[]);assert.deepEqual(swlRenewalCodeMap(removed).SUNINT2,map.SUNINT2);
});
test('onOpen only adds menus; mixed rows are reviewed before lock and sent with their own prices, URLs and HTML',async()=>{
 const codes=Object.keys(SWL_RENEWAL_CODES),h=harness({codes,selection:[[2,31],[2,3]]});h.ctx.onOpen();assert.deepEqual(h.menus.map(m=>m.label),['Review renewal classes & send','Check renewal classes (no email)']);assert.equal(h.dialogs.length,0);h.ctx.sendSelectedSwlEmails();
 assert.equal(h.sent.length,30);assert.deepEqual(h.events.slice(0,2),['confirm','lock']);
 const map=swlRenewalCodeMap(classes),review=h.dialogs[0][1];assert.match(review,/Are these matches correct/);assert.match(review,/Wednesday 17:00–20:15 \+ Saturday 14:30–17:00/);
 for(let i=0;i<codes.length;i++){
  const cls=classes.find(c=>c.id===map[codes[i]][0]);assert.match(review,new RegExp(codes[i]));assert.ok(h.sent[i].plainBody.includes(cls.paymentUrl));assert.ok(h.sent[i].plainBody.includes('£'+Number(cls.fee).toFixed(2)));
  const preview=await renderPreview('swl',{...config,previewClassId:cls.id},{parent:`Parent ${i}`,child:`Child ${i}`});
  assert.equal(h.sent[i].htmlBody.replace('cid:swlLogo',preview.match(/data:image\/jpeg;base64,[A-Za-z0-9+/=]+/)[0]),preview);
 }
 h.ctx.sendSelectedSwlEmails();assert.equal(h.sent.length,60,'manual resend remains enabled');
});
test('cancel and check-only have no writes, mail or lock; normalize code case and surrounding spaces',()=>{
 for(const cancel of [true,false]){const h=harness({codes:[' monb1 ','SUNINT2'],cancel});const before=JSON.stringify(h.rows);if(cancel)h.ctx.sendSelectedSwlEmails();else h.ctx.checkSelectedSwlRows();assert.equal(h.sent.length,0);assert.equal(h.writes.length,0);assert.equal(JSON.stringify(h.rows),before);assert.ok(!h.events.includes('lock'));assert.match(h.dialogs[0][1],/2 eligible selected rows/);}
});
test('blank, unknown, omitted or ambiguous codes block the whole selection before approval',async()=>{
 for(const code of ['', 'MONB9','__proto__']){const h=harness({codes:['MONB1',code]});h.ctx.sendSelectedSwlEmails();assert.equal(h.sent.length,0);assert.equal(h.writes.length,0);assert.ok(!h.events.length);assert.match(h.dialogs[0][0],/Row 3:/);}
 const map=swlRenewalCodeMap(classes);
 for(const altered of [classes.filter(c=>c.id!==map.SUNINT2[0]),[...classes,{...classes.find(c=>c.id===map.SUNINT2[0]),id:'duplicate'}]]){
  const script=await generateScript('swl',{...config,campaign:{...config.campaign,classes:altered}});const h=harness({codes:['SUNINT2'],script});h.ctx.sendSelectedSwlEmails();assert.equal(h.sent.length,0);assert.equal(h.writes.length,0);assert.match(h.dialogs[0][0],/matching included class|more than one/);
 }
});
test('missing or duplicate Renewal class heading prevents sending',()=>{
 for(const heading of ['Wrong heading','Renewal class']){const h=harness();if(heading==='Wrong heading')h.rows[0][1]=heading;else h.rows[0][0]=heading;h.ctx.sendSelectedSwlEmails();assert.equal(h.sent.length,0);assert.equal(h.writes.length,0);assert.match(h.dialogs[0][0],/exactly one Renewal class/);}
});
test('recipient/code/eligibility changes during confirmation block sending; selection change alone keeps original rows',()=>{
 for(const mutate of [({rows})=>rows[1][1]='TUEB1',({rows})=>rows[1][2]='different@example.com',({rows})=>rows[1][3]='Different child',({rows})=>rows[1][6]='Review']){const h=harness({mutate});h.ctx.sendSelectedSwlEmails();assert.equal(h.sent.length,0);assert.equal(h.writes.length,0);assert.match(h.dialogs.at(-1)[0],/changed after confirmation/);}
 const h=harness({selection:[[2,2]],mutate:({setSelection})=>setSelection([[3,3]])});h.ctx.sendSelectedSwlEmails();assert.deepEqual(h.sent.map(m=>m.email),['p0@example.com']);
});
test('Review and hidden rows are listed as skipped; optional status is appended without touching attendance',()=>{
 const h=harness({codes:['MONB1','BAD','BAD']});h.rows[2][6]='Review';h.sheet.isRowHiddenByUser=r=>r===4;h.ctx.sendSelectedSwlEmails();assert.equal(h.sent.length,1);assert.match(h.dialogs[0][1],/2 skipped/);
 const rows=[['renewal CLASS','Parents Name','Childs Name','Email','Attendance'],['MONB1','Parent','Child','p@example.com','present']];const noStatus=harness({customRows:rows});noStatus.ctx.sendSelectedSwlEmails();assert.equal(noStatus.sent.length,1);assert.equal(rows[0][5],'Email Status');assert.equal(rows[1][4],'present');
});
test('reminders use code matching and fresh confirmation; quota and locks still prevent sends',async()=>{
 const script=await generateScript('swl',{...config,renewalVariant:'reminder',subject:'Gentle reminder for {{class}}'});const h=harness({script});h.ctx.sendSelectedSwlEmails();assert.equal(h.sent.length,2);assert.match(h.dialogs[0][0],/reminders/);assert.match(h.sent[0].subject,/Gentle reminder/);
 for(const options of [{quota:0},{locked:true}]){const h=harness(options);h.ctx.sendSelectedSwlEmails();assert.equal(h.sent.length,0);assert.equal(h.writes.length,0);}
});

const {generateCompanionScript,wrapRenewalCompanion,CLUBS}=await import('../dist/engine.js');
test('renewal companions coexist with legacy globals and preserve the basic composer opening function',async()=>{
 const h=harness();const opening=h.ctx.onOpen;
 const calls=[];h.ctx.basicComposer=()=>calls.push('basic');vm.runInContext('function onOpen(){basicComposer();}',h.ctx);const basicOpening=h.ctx.onOpen;
 for(const club of CLUBS)for(const variant of ['main','reminder']){
  const code=await generateCompanionScript(club.id,{...config,renewalVariant:variant});assert.doesNotMatch(code,/^function onOpen\(/m);
  vm.runInContext(code,h.ctx);assert.equal(h.ctx.onOpen,basicOpening);
  const prefix={swl:'Swl',fulham:'Fulham',apex:'Apex',apexdance:'ApexDance'}[club.id];const stem='geb'+prefix+'Renewal'+(variant==='main'?'Main':'Reminder');
  assert.equal(code.match(/^function (\w+)/m)[1],stem+'Menu');h.ctx[stem+'Menu']();
  for(const item of h.menus.slice(-2))assert.equal(typeof h.ctx[item.callback],'function');
 }
 h.ctx.onOpen();assert.deepEqual(calls,['basic']);assert.equal(h.sent.length,0);assert.equal(h.writes.length,0);assert.equal(h.dialogs.length,0);
});
test('the actual SWL companion callbacks send all 30 code-selected emails and retain resend behaviour',async()=>{
 const script=await generateCompanionScript('swl',config),codes=Object.keys(SWL_RENEWAL_CODES),h=harness({script,codes});
 h.ctx.gebSwlRenewalMainMenu();assert.deepEqual(h.menus.map(m=>m.callback),['gebSwlRenewalMainSend','gebSwlRenewalMainCheck']);h.ctx.gebSwlRenewalMainSend();assert.equal(h.sent.length,30);
 const map=swlRenewalCodeMap(classes);
 for(let i=0;i<codes.length;i++)assert.ok(h.sent[i].plainBody.includes(classes.find(c=>c.id===map[codes[i]][0]).paymentUrl));
 h.ctx.gebSwlRenewalMainSend();assert.equal(h.sent.length,60);
});
test('isolated main and reminder keep their own subjects and confirmation, and checks/cancel send nothing',async()=>{
 const main=await generateCompanionScript('swl',config),reminder=await generateCompanionScript('swl',{...config,renewalVariant:'reminder',subject:'Reminder {{child}}'});
 const h=harness({script:main+'\n'+reminder});h.ctx.gebSwlRenewalMainCheck();assert.equal(h.sent.length,0);assert.equal(h.writes.length,0);
 h.ctx.gebSwlRenewalMainSend();h.ctx.gebSwlRenewalReminderSend();assert.equal(h.sent.length,4);assert.match(h.sent[0].subject,/^Renew /);assert.match(h.sent[2].subject,/^Reminder /);
 const cancel=harness({script:main,cancel:true});cancel.ctx.gebSwlRenewalMainSend();assert.equal(cancel.sent.length,0);assert.equal(cancel.writes.length,0);
});
test('companion wrapper preserves literal content and does not change basic or offer generation',async()=>{
 const literal=await generateScript('swl',{...config,body:'Literal EMAIL_CAMPAIGN onOpen escapeSwlHtml_.'});const wrapped=wrapRenewalCompanion(literal,'swl');assert.ok(wrapped.includes('Literal EMAIL_CAMPAIGN onOpen escapeSwlHtml_.'));
 for(const mode of ['basic','offer']){const opts={...config,mode};assert.equal(await generateCompanionScript('swl',opts),await generateScript('swl',opts));}
});
test('the browser copy/download path uses companion generation',async()=>{
 const app=await readFile(new URL('../dist/app.js',import.meta.url),'utf8');assert.match(app,/generateCompanionScript\(requestedClub, config\)/);assert.doesNotMatch(app,/generateScript\(requestedClub, config\)/);
 const {buildStandalone}=await import('../scripts/build-standalone.mjs');const {engineSource}=await buildStandalone();const ctx=vm.createContext({URL});vm.runInContext(engineSource+'\nglobalThis.companion=generateCompanionScript;',ctx);
 for(const club of CLUBS)for(const renewalVariant of ['main','reminder']){const opts={...config,renewalVariant};assert.equal(await ctx.companion(club.id,opts),await generateCompanionScript(club.id,opts));}
});
