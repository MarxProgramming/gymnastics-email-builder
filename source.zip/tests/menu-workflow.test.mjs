import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import { readFile } from 'node:fs/promises';
globalThis.fetch=async url=>new Response(await readFile(url,'utf8'));
const {CLUBS,generateScript}=await import('../dist/engine.js');
const prefixes={swl:'Swl',fulham:'Fulham',apex:'Apex',apexdance:'ApexDance'};
const menuNames={swl:'SWL emails',fulham:'Fulham emails',apex:'Apex emails',apexdance:'Apex Dance emails'};
const campaign={bankAccountName:'Test Club',bankSortCode:'00-00-00',bankAccountNumber:'00000000',termName:'Spring 2028',startDate:'2028-01-03',endDate:'2028-01-30',deadline:'2027-12-15',classes:[
  {id:'first',name:'First class',fee:'100',paymentUrl:'https://example.com/first',sessions:[{weekday:1,startTime:'17:00',endTime:'18:00'}]},
  {id:'second',name:'Second class',fee:'150',paymentUrl:'https://example.com/second',sessions:[{weekday:4,startTime:'18:00',endTime:'19:00'}]}
]};
const config=mode=>({mode,subject:'Test {{child}}',body:'Your class details.',...(mode==='basic'?{}:{campaign})});
function menuHarness(source,{answer='2',cancel=false,noSelection=false}={}){
  const menus=new Map(),prompts=[],alerts=[],invocations=[];
  const selectedSheet={name:'Chosen sheet'};
  const ranges=[{getRow:()=>3,getLastRow:()=>5}];
  let allowSelection=false;
  const ui={Button:{OK:'OK',CANCEL:'CANCEL'},ButtonSet:{OK_CANCEL:'OK_CANCEL'},
    createMenu(name){const items=[];return {addItem(label,callback){items.push({label,callback});return this;},addToUi(){menus.set(name,items);}};},
    prompt(title,choices){assert.ok(allowSelection,'opening the sheet must never ask for a class');prompts.push({title,choices});return {getSelectedButton:()=>cancel?'CANCEL':'OK',getResponseText:()=>answer};},
    alert(message){alerts.push(message);}
  };
  const ss={getActiveSheet:()=>selectedSheet,getSelection:()=>({getActiveRangeList:()=>noSelection?null:{getRanges:()=>ranges}}),toast:message=>alerts.push(message)};
  // No MailApp, LockService, Utilities or ScriptApp is available during startup.
  // A simple onOpen must be able to register menus without those authorisations.
  const context=vm.createContext({SpreadsheetApp:{getUi:()=>ui,getActiveSpreadsheet:()=>{assert.ok(allowSelection);return ss;}}});
  vm.runInContext(source,context);
  return {context,menus,prompts,alerts,invocations,selectedSheet,enableMenuActions(){allowSelection=true;}};
}

for(const club of CLUBS)for(const mode of (club.id === 'swl' ? ['basic','offer'] : ['basic','renewal','offer'])){
  test(`${club.name} ${mode}: onOpen is first, installs the menu without setup, and its callbacks choose the class only after a click`,async()=>{
    const source=await generateScript(club.id,config(mode));
    assert.equal(source.match(/^function\s+([A-Za-z0-9_]+)\s*\(/m)[1],'onOpen','editor Run must initially target the menu, not getClassSchedule or another internal helper');
    assert.equal((source.match(/^function onOpen\(/gm)||[]).length,1);
    const h=menuHarness(source);h.context.onOpen();h.context.onOpen();
    assert.equal(h.menus.size,1);assert.equal(h.prompts.length,0);assert.equal(h.alerts.length,0);
    const items=h.menus.get(menuNames[club.id]);assert.equal(items.length,2);
    assert.deepEqual(items.map(item=>item.label),mode==='basic'?['Send selected emails','Check selected rows (no email)']:['Choose class & send selected rows','Choose class & check rows (no email)']);
    for(const item of items)assert.equal(typeof h.context[item.callback],'function');
    h.context['process'+prefixes[club.id]+'Emails_']=(dryRun,captured)=>{
      h.invocations.push({dryRun,captured,classId:mode==='basic'?null:vm.runInContext('selectedCampaignClass_.id',h.context)});
    };
    h.enableMenuActions();h.context[items[0].callback]();h.context[items[1].callback]();
    assert.deepEqual(h.invocations.map(item=>item.dryRun),[false,true]);
    if(mode==='basic')assert.equal(h.prompts.length,0);
    else {
      assert.equal(h.prompts.length,2);
      for(const call of h.invocations){assert.equal(call.classId,'second');assert.equal(call.captured.sheet,h.selectedSheet);assert.equal(JSON.stringify(call.captured.ranges),JSON.stringify([{first:3,last:5}]));}
      assert.equal(vm.runInContext('selectedCampaignClass_',h.context),null,'the next menu click must choose a class afresh');
      assert.match(h.prompts[0].choices,/First class.*Monday.*£100\.00/);assert.match(h.prompts[0].choices,/Second class.*Thursday.*£150\.00/);
    }
  });
}

test('opening then cancelling or entering an invalid class never reaches the sender',async()=>{
  const source=await generateScript('swl',config('offer'));
  for(const scenario of [{cancel:true},{answer:'2x'},{answer:'0'},{answer:'3'},{noSelection:true}]){
    const h=menuHarness(source,scenario);h.context.onOpen();h.context.processSwlEmails_=()=>assert.fail('sender must not run');h.enableMenuActions();
    h.context[h.menus.get('SWL emails')[0].callback]();assert.equal(vm.runInContext('selectedCampaignClass_',h.context),null);
  }
});
